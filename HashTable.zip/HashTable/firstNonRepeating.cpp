#include <iostream>
#include <vector>
#include <algorithm>
#include <string>

using namespace std;

const int INIT_SIZE = 13;
const double MAX_LOAD = 0.5;
const double MIN_LOAD = 0.25;

bool isPrime(int n);
int nextPrime(int n);
int prevPrime(int n);

template <typename K, typename V>
class HashMain{
public:
    int size;
    int count;
    int collisions;
    int lastHits;
    int konFunction;

    int koytaInsertAfterResize;
    int koytaDeleteAfterResize;
    int sizeAtLastResize;

    HashMain(int s, int konFunction){
        size = s;
        count = 0;
        collisions = 0;
        lastHits = 0;
        koytaDeleteAfterResize=0;
        koytaInsertAfterResize=0;
        this->konFunction=konFunction;
        sizeAtLastResize=0;
    }
    virtual ~HashMain(){}

    int hashFunction(K key){
        int val = (int)key; 
        if (val < 0) val = -val;
        return (val * 31) % size;
    }

    int hashFunction2(K key){
        int val = (int)key;
        if (val < 0) val = -val;
        int hash = (val * 17) % size;
        return (hash % (size - 1) + 1);
    }

    double loadFactor(){
        return (double)count/size;
    }

    virtual void insert(K, V)=0;
    virtual void remove(K)=0;
    virtual bool search(K)=0;
    virtual int getCount(K)=0; // NEW method to retrieve frequency
    virtual void reHash(int newSize)=0;
};

template <typename K, typename V>
class DoubleHashTable:public HashMain<K, V>{
public:
    vector<pair<K, V>> table;
    vector<int> used;

    DoubleHashTable(int s, int k) : HashMain<K, V>(s, k){
        table.resize(s);
        used.resize(s, 0);
    }

    // NEW METHOD: Returns the value (frequency) for a given key
    int getCount(K key) {
        int h1 = (this->konFunction == 1) ? this->hashFunction(key) : this->hashFunction2(key);
        int h2 = (this->konFunction == 1) ? this->hashFunction2(key) : this->hashFunction(key);
        if(h2 == 0) h2 = 1;

        for(int i = 0; i < this->size; i++){
            int idx = (h1+i*h2)%this->size;
            if(used[idx] == 0) return 0; // Not found
            if(used[idx] == 1 && table[idx].first == key) {
                return table[idx].second; // Return the count
            }
        }
        return 0;
    }

    void reHash(int newSize){
        vector<pair<K, V>> oldTable = table;
        vector<int> oldUsed = used;
        int oldSize = this->size;

        table.clear();
        used.clear();
        this->size = newSize;
        table.resize(newSize);
        used.resize(newSize, 0);

        this->sizeAtLastResize=this->count;
        this->count = 0;
        this->koytaDeleteAfterResize=0;
        this->koytaInsertAfterResize=0;

        for(int i = 0; i < oldSize; i++){
            if(oldUsed[i]==1){
                this->insert(oldTable[i].first, oldTable[i].second);
            }
        }
    }    

    void insert(K key, V value){
        int lastThreshold;
        if(this->sizeAtLastResize==0){
            lastThreshold=this->count/2;
        }else{
            lastThreshold=this->sizeAtLastResize/2;
        }
        if(this->loadFactor() > MAX_LOAD && this->koytaInsertAfterResize >= lastThreshold){
            reHash(nextPrime(this->size*2));
        }

        int h1 = (this->konFunction == 1) ? this->hashFunction(key) : this->hashFunction2(key);
        int h2 = (this->konFunction == 1) ? this->hashFunction2(key) : this->hashFunction(key);
        if(h2 == 0) h2 = 1;

        int firstDel = -1;

        for(int i = 0; i < this->size; i++){
            int idx = (h1+i*h2)%this->size;
            
            // Frequency Logic: If key exists, increment count
            if(used[idx] == 1 && table[idx].first == key){
                table[idx].second += value; 
                return; 
            }

            if(used[idx]==0){
                if(firstDel != -1){
                    idx = firstDel;
                }
                table[idx] = {key, value};
                used[idx] = 1;
                this->count++;
                this->koytaInsertAfterResize++;
                return;
            }
            if(used[idx]==2 && firstDel == -1){
                firstDel = idx;
            }
        }
    }

    bool search(K key){
        int h1 = (this->konFunction == 1) ? this->hashFunction(key) : this->hashFunction2(key);
        int h2 = (this->konFunction == 1) ? this->hashFunction2(key) : this->hashFunction(key);
        if(h2 == 0) h2 = 1;

        for(int i = 0; i < this->size; i++){
            int idx = (h1+i*h2)%this->size;
            if(used[idx]==0) return false;
            if(used[idx]==1 && table[idx].first == key) return true;
        }
        return false;
    }

    void remove(K key){
        int h1 = (this->konFunction == 1) ? this->hashFunction(key) : this->hashFunction2(key);
        int h2 = (this->konFunction == 1) ? this->hashFunction2(key) : this->hashFunction(key);
        if(h2 == 0) h2 = 1;

        for(int i = 0; i < this->size; i++){
            int idx = (h1+i*h2)%this->size;
            if(used[idx]==0) return;
            if(used[idx]==1 && table[idx].first==key){
                used[idx] = 2;
                this->count--;
                this->koytaDeleteAfterResize++;
                return;
            }
        }
    }
};

// ... (Other classes removed for brevity) ...

bool isPrime(int n){
    if(n<=1) return false;
    for(int i = 2; i < n; i++){
        if(n%i==0) return false;
    }
    return true;
}

int nextPrime(int n){
    while(!isPrime(n)) n++;
    return n;
}

int prevPrime(int n){
    n--;
    while(n>2 && !isPrime(n)) n--;
    return n;
}

int main() {
    string str;
    cout << "Enter a string: ";
    // Use getline to capture full sentence if needed
    getline(cin, str); 

    DoubleHashTable<char, int>* ht = new DoubleHashTable<char, int>(INIT_SIZE, 1);
    
    // PASS 1: Build Frequency Map
    // Insert every character. The 'insert' function handles the counting.
    for(char c : str){
        ht->insert(c, 1);
    }

    // PASS 2: Find First Non-Repeating
    // Iterate through the ORIGINAL string to preserve order
    bool found = false;
    for(char c : str) {
        // Use the new getCount method to check frequency
        if(ht->getCount(c) == 1) {
            cout << "First non-repeating character: " << c << endl;
            found = true;
            break; // Stop as soon as we find the first one
        }
    }

    if(!found) {
        cout << "No non-repeating character found." << endl;
    }

    delete ht;
    return 0;
}