// Inside DoubleHashTable::insert
if(used[idx] == 1 && table[idx].first == key) {
    // Append the new value with a comma separator
    table[idx].second = table[idx].second + ", " + value; 
    return;
}


int main() {
    int n;
    cout << "Enter number of words: ";
    cin >> n;
    
    // Key = Sorted String, Value = List of Original Strings
    DoubleHashTable<string, string>* ht = new DoubleHashTable<string, string>(INIT_SIZE, 1);
    
    cout << "Enter words: " << endl;
    for(int i = 0; i < n; i++){
        string original;
        cin >> original;
        
        string sorted = original;
        sort(sorted.begin(), sorted.end()); // "tea" -> "aet"
        
        ht->insert(sorted, original);
    }

    cout << "--- Anagram Groups ---" << endl;
    for(int i = 0; i < ht->size; i++) {
        if(ht->used[i] == 1) {
            // Print the list of words stored in Value
            cout << "{ " << ht->table[i].second << " }" << endl;
        }
    }

    delete ht;
    return 0;
}