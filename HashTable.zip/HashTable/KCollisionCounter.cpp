#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>
#include <list>
#include <unordered_set>
#include <ctime>
#include <cmath>

using namespace std;
const int INF = 1e9;

const int INIT_SIZE = 13;
const double MAX_LOAD = 0.5;
const double MIN_LOAD = 0.25;

bool isPrime(int n);
int nextPrime(int n);
int prevPrime(int n);

template <typename K, typename V>
class HashMain{
public:
    int size;
    int count;
    int collisions;
    int lastHits;
    int konFunction;

    int koytaInsertAfterResize;
    int koytaDeleteAfterResize;
    int sizeAtLastResize;

    HashMain(int s, int konFunction){
        size = s;
        count = 0;
        collisions = 0;
        lastHits = 0;
        koytaDeleteAfterResize=0;
        koytaInsertAfterResize=0;
        this->konFunction=konFunction;
        sizeAtLastResize=0;
    }
    virtual ~HashMain(){}

    int hashFunction(K key){
        // Generic handling for int/char/string logic 
        // (Simplified for this demonstration to compile with int or string)
        int hash = 0;
        int p = 31;
        // This trick works if K is string. If K is int, you might need a specialization
        // For now, assuming K is string as per original code, or handled carefully.
        // If K is int, user must update this. I will assume string for general compatibility.
        /* NOTE: If using INT keys, change to: return abs((int)key) % size;
        */
        // Using a generic approach for string iterators:
        for(auto c : key){ 
            hash = (hash*p + (int)c)%size;
        }
        return hash;
    }
    int hashFunction2(K key){
        int hash = 0;
        int p = 17;
        for(auto c : key){
            hash = (hash*p + (int)c)%size;
        }
        return (hash%(size-1) +1) ;
    }

    double loadFactor(){
        return (double)count/size;
    }

    virtual void insert(K, V)=0;
    virtual void remove(K)=0;
    virtual bool search(K)=0;
    virtual void reHash(int newSize)=0;
    
    // NEW ABSTRACT METHOD
    virtual int countSlotsWithKCollisions(int k) = 0;
};

template <typename K, typename V>
class DoubleHashTable:public HashMain<K, V>{
public:
    vector<pair<K, V>> table;
    vector<int> used;
    
    // NEW: Vector to track collisions per slot
    vector<int> slotCollisionCounts;

    DoubleHashTable(int s, int k) : HashMain<K, V>(s, k){
        table.resize(s);
        used.resize(s, 0);
        slotCollisionCounts.resize(s, 0); // Initialize with 0
    }

    // NEW METHOD IMPLEMENTATION
    int countSlotsWithKCollisions(int k) {
        int matchCount = 0;
        for(int i = 0; i < this->size; i++) {
            if (slotCollisionCounts[i] == k) {
                matchCount++;
            }
        }
        return matchCount;
    }

    void reHash(int newSize){
        vector<pair<K, V>> oldTable = table;
        vector<int> oldUsed = used;
        int oldSize = this->size;

        table.clear();
        used.clear();
        slotCollisionCounts.clear(); // Clear stats

        this->size = newSize;
        table.resize(newSize);
        used.resize(newSize, 0);
        slotCollisionCounts.resize(newSize, 0); // Resize new stats

        this->sizeAtLastResize=this->count;
        this->count = 0;
        this->collisions = 0; // Reset global collisions too usually
        this->koytaDeleteAfterResize=0;
        this->koytaInsertAfterResize=0;

        for(int i = 0; i < oldSize; i++){
            if(oldUsed[i]==1){
                this->insert(oldTable[i].first, oldTable[i].second);
            }
        }
    }    

    void insert(K key, V value){
        int lastThreshold;
        if(this->sizeAtLastResize==0){
            lastThreshold=this->count/2;
        }else{
            lastThreshold=this->sizeAtLastResize/2;
        }
        if(this->loadFactor() > MAX_LOAD && this->koytaInsertAfterResize >= lastThreshold){
            reHash(nextPrime(this->size*2));
        }

        int h1 = (this->konFunction == 1) ? this->hashFunction(key) : this->hashFunction2(key);
        int h2 = (this->konFunction == 1) ? this->hashFunction2(key) : this->hashFunction(key);
        if(h2 == 0) h2 = 1;

        int firstDel = -1;

        for(int i = 0; i < this->size; i++){
            int idx = (h1+i*h2)%this->size;
            
            // --- MODIFIED LOGIC FOR K-COLLISION ---
            if(used[idx] == 1){
                this->collisions++;
                slotCollisionCounts[idx]++; // Increment collision count for this specific slot
            }
            // ------------------------------------

            if(used[idx]==0){
                if(firstDel != -1){
                    idx = firstDel;
                }
                table[idx] = {key, value};
                used[idx] = 1;
                this->count++;
                this->koytaInsertAfterResize++;
                return;
            }
            if(used[idx]==2 && firstDel == -1){
                firstDel = idx;
            }
            if(used[idx]==1 && table[idx].first == key){
                return;
            }
        }
    }

    bool search(K key){
        this->lastHits = 0;
        int h1 = (this->konFunction == 1) ? this->hashFunction(key) : this->hashFunction2(key);
        int h2 = (this->konFunction == 1) ? this->hashFunction2(key) : this->hashFunction(key);
        if(h2 == 0) h2 = 1;

        for(int i = 0; i < this->size; i++){
            int idx = (h1+i*h2)%this->size;
            this->lastHits++;
            if(used[idx]==0) return false;
            if(used[idx]==1 && table[idx].first == key) return true;
        }
        return false;
    }

    void remove(K key){
        int h1 = (this->konFunction == 1) ? this->hashFunction(key) : this->hashFunction2(key);
        int h2 = (this->konFunction == 1) ? this->hashFunction2(key) : this->hashFunction(key);
        if(h2 == 0) h2 = 1;

        for(int i = 0; i < this->size; i++){
            int idx = (h1+i*h2)%this->size;
            if(used[idx]==0) return;
            if(used[idx]==1 && table[idx].first==key){
                used[idx] = 2;
                this->count--;
                this->koytaDeleteAfterResize++;
                int lastThreshold = (this->sizeAtLastResize == 0) ? this->count/2 : this->sizeAtLastResize/2;
                if(this->loadFactor() < MIN_LOAD && this->size > INIT_SIZE && this->koytaDeleteAfterResize>=lastThreshold){
                    reHash(prevPrime(this->size/2));
                }
                return;
            }
        }
    }
};

template <typename K, typename V>
class CustomProbeHashTable : public HashMain<K, V>{
public:
    vector<pair<K, V>> table;
    vector<int> used;
    vector<int> slotCollisionCounts; // NEW
    int C1 = 1;
    int C2 = 3;

    CustomProbeHashTable(int s, int k):HashMain<K, V>(s, k){
        table.resize(s);
        used.resize(s, 0);
        slotCollisionCounts.resize(s, 0);
    }

    // NEW METHOD IMPLEMENTATION
    int countSlotsWithKCollisions(int k) {
        int matchCount = 0;
        for(int i = 0; i < this->size; i++) {
            if (slotCollisionCounts[i] == k) matchCount++;
        }
        return matchCount;
    }

    void reHash(int newSize){
        vector<pair<K, V>> oldTable = table;
        vector<int> oldUsed = used;
        int oldSize = this->size;

        table.clear(); used.clear(); slotCollisionCounts.clear();
        this->size = newSize;
        table.resize(newSize);
        used.resize(newSize, 0);
        slotCollisionCounts.resize(newSize, 0);
        
        this->sizeAtLastResize = this->count;
        this->count = 0;
        this->collisions = 0;
        this->koytaInsertAfterResize = 0;
        this->koytaDeleteAfterResize = 0;

        for(int i=0; i<oldSize; i++){
            if(oldUsed[i] == 1){
                this->insert(oldTable[i].first, oldTable[i].second);
            }
        }
    }

    void insert(K key, V val){
        int lastThreshold;
        if(this->sizeAtLastResize==0){
            lastThreshold=this->count/2;
        }else{
            lastThreshold=this->sizeAtLastResize/2;
        }

        if(this->loadFactor() > MAX_LOAD && this->koytaInsertAfterResize>= lastThreshold){
            reHash(nextPrime(this->size*2));
        }
        int h1 = (this->konFunction == 1) ? this->hashFunction(key) : this->hashFunction2(key);
        int h2 = (this->konFunction == 1) ? this->hashFunction2(key) : this->hashFunction(key);
        if(h2 == 0) h2 = 1;

        for(int i = 0; i < this->size; i++){
            int idx = (h1+C1*i*h2 + C2*i*i)%this->size;

            // --- MODIFIED LOGIC ---
            if(used[idx] == 1){
                this->collisions++;
                slotCollisionCounts[idx]++;
            }
            // ----------------------

            if(used[idx] == 0){
                table[idx]={key, val};
                used[idx] = 1;
                this->count++;
                this->koytaInsertAfterResize++;
                return;
            }
            if(used[idx] == 1 && table[idx].first == key) return;
        }
    }
    
    bool search(K key){
        this->lastHits = 0;
        int h1 = (this->konFunction == 1) ? this->hashFunction(key) : this->hashFunction2(key);
        int h2 = (this->konFunction == 1) ? this->hashFunction2(key) : this->hashFunction(key);
        if(h2 == 0) h2 = 1;

        for(int i = 0; i < this->size; i++){
            int idx = (h1+C1*i*h2+C2*i*i)%this->size;
            this->lastHits++;
            if(used[idx]==0) return false;
            if(used[idx]==1 && table[idx].first == key) return true;
        }
        return false;
    }

    void remove(K key){
        int h1 = (this->konFunction == 1) ? this->hashFunction(key) : this->hashFunction2(key);
        int h2 = (this->konFunction == 1) ? this->hashFunction2(key) : this->hashFunction(key);
        if(h2 == 0) h2 = 1;

        for(int i = 0; i < this->size; i++){
            int idx = (h1+C1*i*h2+C2*i*i)%this->size;
            if(used[idx]==0) return;
            if(used[idx]==1 && table[idx].first==key){
                used[idx] = 2;
                this->count--;
                this->koytaDeleteAfterResize++;
                int threshold = (this->sizeAtLastResize == 0) ? this->count/2 : this->sizeAtLastResize/2;
                if(this->loadFactor() < MIN_LOAD && this->size > INIT_SIZE && this->koytaDeleteAfterResize >= threshold){
                    reHash(prevPrime(this->size/2));
                }
                return;
            }
        }
    }
};

template <typename K, typename V>
class ChainingHashTable : public HashMain<K, V>{
public:
    vector<list<pair<K, V>>> table;
    vector<int> slotCollisionCounts; // NEW

    ChainingHashTable(int s, int k):HashMain<K, V>(s, k){
        table.resize(s);
        slotCollisionCounts.resize(s, 0);
    }

    // NEW METHOD IMPLEMENTATION
    int countSlotsWithKCollisions(int k) {
        int matchCount = 0;
        for(int i = 0; i < this->size; i++) {
            if (slotCollisionCounts[i] == k) matchCount++;
        }
        return matchCount;
    }

    void reHash(int newSize) {
        vector<list<pair<K, V>>> oldTable = table;
        
        this->size = newSize;
        table.clear();
        table.resize(newSize);
        slotCollisionCounts.clear();
        slotCollisionCounts.resize(newSize, 0);
        
        this->sizeAtLastResize = this->count;
        this->count = 0;
        this->collisions = 0;
        this->koytaInsertAfterResize = 0;
        this->koytaDeleteAfterResize = 0;

        for(auto &lst : oldTable){
            for(auto &p : lst){
                this->insert(p.first, p.second);
            }
        }
    }

    void insert(K key, V value){
        int lastThreshold;
        if(this->sizeAtLastResize==0){
            lastThreshold=this->count/2;
        }else{
            lastThreshold=this->sizeAtLastResize/2;
        }
        if(this->loadFactor() > MAX_LOAD && this->koytaInsertAfterResize >= lastThreshold){
            reHash(nextPrime(this->size*2));          
        }
        int idx = (this->konFunction == 1) ? this->hashFunction(key) : this->hashFunction2(key);

        for(auto &p : table[idx]){
            if(p.first == key) return;
        }
        
        // --- MODIFIED LOGIC ---
        if(!table[idx].empty()){
            this->collisions++;
            slotCollisionCounts[idx]++;
        }
        // ----------------------

        table[idx].push_back({key, value});
        this->count++;
        this->koytaInsertAfterResize++;
    }
    
    bool search(K key){
        this->lastHits=0;
        int idx = (this->konFunction == 1) ? this->hashFunction(key) : this->hashFunction2(key);
        for(auto &x : table[idx]){
            this->lastHits++;
            if(x.first==key) return true;
        }
        return false;
    }

    void remove(K key){
        int idx = (this->konFunction == 1) ? this->hashFunction(key) : this->hashFunction2(key);
        for(auto it=table[idx].begin();it!=table[idx].end();it++){
            if(it->first==key){
                table[idx].erase(it);
                this->count--;
                this->koytaDeleteAfterResize++;
                int threshold = (this->sizeAtLastResize == 0) ? this->count/2 : this->sizeAtLastResize/2;
                if(this->loadFactor() < MIN_LOAD && this->size > INIT_SIZE && this->koytaDeleteAfterResize >= threshold){
                    reHash(prevPrime(this->size/2));
                }
                return;
            }
        }
    }
};

bool isPrime(int n){
    if(n<=1) return false;
    for(int i = 2; i < n; i++){
        if(n%i==0) return false;
    }
    return true;
}

int nextPrime(int n){
    while(!isPrime(n)) n++;
    return n;
}

int prevPrime(int n){
    n--;
    while(n>2 && !isPrime(n)) n--;
    return n;
}

string WordGenerator(int n){
    string s = "";
    for(int i = 0; i < n; i++){
        char c = 'a' + rand()%26;
        s.push_back(c);
    }
    return s;
}

int main() {
    srand(time(0));
    
    // Test with Double Hash Table
    cout << "--- Double Hash Table Test ---" << endl;
    DoubleHashTable<string, int>* ht = new DoubleHashTable<string, int>(INIT_SIZE, 1);
    
    // Insert some strings intentionally to cause potential collisions
    // "apple" "banana" "orange" "grape" "melon"
    vector<string> words = {"apple", "banana", "orange", "grape", "melon", "kiwi", "pear", "peach", "plum", "berry"};
    
    cout << "Inserting 10 words..." << endl;
    for(int i=0; i<words.size(); i++) {
        ht->insert(words[i], i+1);
    }

    cout << "Total Global Collisions: " << ht->collisions << endl;
    
    // Report K-Collision stats
    cout << "Slots with 0 collisions: " << ht->countSlotsWithKCollisions(0) << endl;
    cout << "Slots with 1 collision:  " << ht->countSlotsWithKCollisions(1) << endl;
    cout << "Slots with 2 collisions: " << ht->countSlotsWithKCollisions(2) << endl;
    cout << "Slots with >2 collisions: ";
    int more = 0;
    for(int k=3; k<100; k++) more += ht->countSlotsWithKCollisions(k);
    cout << more << endl;

    delete ht;
    return 0;
}