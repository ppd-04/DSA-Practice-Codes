#include <iostream>
#include <vector>
#include <algorithm>
#include <cmath> // for abs()

using namespace std;

const int INIT_SIZE = 13;
const double MAX_LOAD = 0.5;
const double MIN_LOAD = 0.25;

bool isPrime(int n);
int nextPrime(int n);
int prevPrime(int n);

template <typename K, typename V>
class HashMain{
public:
    int size;
    int count;
    int collisions;
    int lastHits;
    int konFunction;

    int koytaInsertAfterResize;
    int koytaDeleteAfterResize;
    int sizeAtLastResize;

    HashMain(int s, int konFunction){
        size = s;
        count = 0;
        collisions = 0;
        lastHits = 0;
        koytaDeleteAfterResize=0;
        koytaInsertAfterResize=0;
        this->konFunction=konFunction;
        sizeAtLastResize=0;
    }
    virtual ~HashMain(){}

    // CHANGED: Logic updated to handle integers for this specific problem
    int hashFunction(K key){
        // Simple modulo hash for integers
        // abs() ensures we handle negative numbers if input has them
        return abs((int)key) % size; 
    }

    // CHANGED: Logic updated to handle integers for this specific problem
    int hashFunction2(K key){
        // Secondary hash must strictly return non-zero step
        int val = abs((int)key);
        return (val % (size - 1)) + 1;
    }

    double loadFactor(){
        return (double)count/size;
    }

    virtual void insert(K, V)=0;
    virtual void remove(K)=0;
    virtual bool search(K)=0;
    virtual void reHash(int newSize)=0;
    // Removed printProbeSequence as it is not needed for C1+C2
};

template <typename K, typename V>
class DoubleHashTable:public HashMain<K, V>{
public:
    vector<pair<K, V>> table;
    vector<int> used;

    DoubleHashTable(int s, int k) : HashMain<K, V>(s, k){
        table.resize(s);
        used.resize(s, 0);
    }

    void reHash(int newSize){
        vector<pair<K, V>> oldTable = table;
        vector<int> oldUsed = used;
        int oldSize = this->size;

        table.clear();
        used.clear();
        this->size = newSize;
        table.resize(newSize);
        used.resize(newSize, 0);

        this->sizeAtLastResize=this->count;
        this->count = 0;
        this->koytaDeleteAfterResize=0;
        this->koytaInsertAfterResize=0;

        for(int i = 0; i < oldSize; i++){
            if(oldUsed[i]==1){
                int h1 = (this->konFunction == 1) ? this->hashFunction(oldTable[i].first) : this->hashFunction2(oldTable[i].first);
                int h2 = (this->konFunction == 1) ? this->hashFunction2(oldTable[i].first) : this->hashFunction(oldTable[i].first);
                if(h2 == 0) h2 = 1;

                for(int j=0; j<this->size; j++){
                    int idx = (h1 + j*h2)%this->size;
                    if(used[idx] == 0){
                        table[idx] = oldTable[i];
                        used[idx] = 1;
                        this->count++;
                        break;
                    }
                }
            }
        }
    }    

    void insert(K key, V value){
        int lastThreshold;
        if(this->sizeAtLastResize==0){
            lastThreshold=this->count/2;
        }else{
            lastThreshold=this->sizeAtLastResize/2;
        }
        if(this->loadFactor() > MAX_LOAD && this->koytaInsertAfterResize >= lastThreshold){
            reHash(nextPrime(this->size*2));
        }

        int h1 = (this->konFunction == 1) ? this->hashFunction(key) : this->hashFunction2(key);
        int h2 = (this->konFunction == 1) ? this->hashFunction2(key) : this->hashFunction(key);
        if(h2 == 0) h2 = 1;

        int firstDel = -1;

        for(int i = 0; i < this->size; i++){
            int idx = (h1+i*h2)%this->size;
            
            if(used[idx]==0){
                if(firstDel != -1){
                    idx = firstDel;
                }
                table[idx] = {key, value};
                used[idx] = 1;
                this->count++;
                this->koytaInsertAfterResize++;
                return;
            }
            if(used[idx]==2 && firstDel == -1){
                firstDel = idx;
            }
            if(used[idx]==1 && table[idx].first == key){
                return;
            }
        }
    }

    bool search(K key){
        int h1 = (this->konFunction == 1) ? this->hashFunction(key) : this->hashFunction2(key);
        int h2 = (this->konFunction == 1) ? this->hashFunction2(key) : this->hashFunction(key);
        if(h2 == 0) h2 = 1;

        for(int i = 0; i < this->size; i++){
            int idx = (h1+i*h2)%this->size;
            if(used[idx]==0){
                return false;
            }
            if(used[idx]==1 && table[idx].first == key){
                return true;
            }
        }
        return false;
    }

    void remove(K key){
        int h1 = (this->konFunction == 1) ? this->hashFunction(key) : this->hashFunction2(key);
        int h2 = (this->konFunction == 1) ? this->hashFunction2(key) : this->hashFunction(key);
        if(h2 == 0) h2 = 1;

        for(int i = 0; i < this->size; i++){
            int idx = (h1+i*h2)%this->size;
            if(used[idx]==0){
                return; 
            }
            if(used[idx]==1 && table[idx].first==key){
                used[idx] = 2;
                this->count--;
                this->koytaDeleteAfterResize++;

                int lastThreshold;
                if(this->sizeAtLastResize==0){
                    lastThreshold=this->count/2;
                }else{
                    lastThreshold=this->sizeAtLastResize/2;
                }
                
                if(this->loadFactor() < MIN_LOAD && this->size > INIT_SIZE && this->koytaDeleteAfterResize>=lastThreshold){
                    reHash(prevPrime(this->size/2));
                }
                return;
            }
        }
    }
};

// ... (Other classes Chaining/CustomProbe removed for brevity as DoubleHash is sufficient for this task) ...
// NOTE: I am using DoubleHashTable only to solve this, as using multiple tables complicates the simple set logic.

bool isPrime(int n){
    if(n<=1) return false;
    for(int i = 2; i < n; i++){
        if(n%i==0) return false;
    }
    return true;
}

int nextPrime(int n){
    while(!isPrime(n)) n++;
    return n;
}

int prevPrime(int n){
    n--;
    while(n>2 && !isPrime(n)) n--;
    return n;
}

int main() {
    // 1. Read Inputs
    int nA, nB;
    
    cin >> nA;
    vector<int> A(nA);
    for(int i=0; i<nA; i++) cin >> A[i];

    cin >> nB;
    vector<int> B(nB);
    for(int i=0; i<nB; i++) cin >> B[i];

    // We will use DoubleHashTable for all operations. 
    // We create a fresh table for each operation to keep logic clean.

    // ---------------------------------------------------------
    // OPERATION 1: INTERSECTION (A n B)
    // ---------------------------------------------------------
    vector<int> intersectionVec;
    DoubleHashTable<int, int>* htInter = new DoubleHashTable<int, int>(INIT_SIZE, 1);
    
    // Insert A
    for(int x : A) htInter->insert(x, 1);
    
    // Check B against A
    for(int x : B) {
        if(htInter->search(x)) {
            intersectionVec.push_back(x);
            // Remove to prevent duplicates in output if B has duplicates
            htInter->remove(x); 
        }
    }
    
    // Print Intersection
    cout << "Intersection: ";
    // sort(intersectionVec.begin(), intersectionVec.end()); // Sorting for clean output (optional)
    for(int x : intersectionVec) cout << x << " ";
    cout << endl;
    delete htInter;

    // ---------------------------------------------------------
    // OPERATION 2: UNION (A U B)
    // ---------------------------------------------------------
    vector<int> unionVec;
    DoubleHashTable<int, int>* htUnion = new DoubleHashTable<int, int>(INIT_SIZE, 1);

    // Insert A
    for(int x : A) htUnion->insert(x, 1);
    // Insert B (Hash table handles duplicates automatically)
    for(int x : B) htUnion->insert(x, 1);

    // Traverse table to collect all unique elements
    for(int i = 0; i < htUnion->size; i++) {
        if(htUnion->used[i] == 1) {
            unionVec.push_back(htUnion->table[i].first);
        }
    }

    // Print Union
    cout << "Union: ";
    sort(unionVec.begin(), unionVec.end());
    for(int x : unionVec) cout << x << " ";
    cout << endl;
    delete htUnion;

    // ---------------------------------------------------------
    // OPERATION 3: DIFFERENCE (A - B)
    // ---------------------------------------------------------
    vector<int> diffVec;
    DoubleHashTable<int, int>* htDiff = new DoubleHashTable<int, int>(INIT_SIZE, 1);

    // Insert A
    for(int x : A) htDiff->insert(x, 1);
    
    // Remove B elements
    for(int x : B) htDiff->remove(x);

    // Collect remaining elements
    for(int i = 0; i < htDiff->size; i++) {
        if(htDiff->used[i] == 1) {
            diffVec.push_back(htDiff->table[i].first);
        }
    }

    // Print Difference
    cout << "Diff (A-B): ";
    sort(diffVec.begin(), diffVec.end());
    for(int x : diffVec) cout << x << " ";
    cout << endl;
    delete htDiff;

    return 0;
}