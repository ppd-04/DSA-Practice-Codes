#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>
#include<list>
#include<unordered_set>
#include <ctime>

using namespace std;
const int INF = 1e9;


const int INIT_SIZE = 13;
const double MAX_LOAD = 0.5;
const double MIN_LOAD = 0.25;


bool isPrime(int n);
int nextPrime(int n);
int prevPrime(int n);

template <typename K, typename V>
class HashMain{
public:
    int size;
    int count;
    int collisions;
    int lastHits;
    int konFunction;

    int koytaInsertAfterResize;
    int koytaDeleteAfterResize;
    int sizeAtLastResize;

    HashMain(int s, int konFunction){
        size = s;
        count = 0;
        collisions = 0;
        lastHits = 0;
        koytaDeleteAfterResize=0;
        koytaInsertAfterResize=0;
        this->konFunction=konFunction;
        sizeAtLastResize=0;
    }
    virtual ~HashMain(){}


    int hashFunction(K key){
        int hash = 0;
        int p = 31;

        for(char c : key){
            hash = (hash*p+c)%size;
        }
        return hash;
    }
    int hashFunction2(K key){
        int hash = 0;
        int p = 17;
        for(char c : key){
            hash = (hash*p+c)%size;
        }
        return (hash%(size-1) +1) ;
    }

    double loadFactor(){
        return (double)count/size;
    }

    virtual void insert(K, V)=0;
    virtual void remove(K)=0;
    virtual bool search(K)=0;
    virtual void reHash(int newSize)=0;

};

template <typename K, typename V>
class DoubleHashTable:public HashMain<K, V>{
public:
    vector<pair<K, V>> table;
    vector<int> used;
    // int koytaInsertAfterResize;
    // int koytaDeleteAfterResize;

    DoubleHashTable(int s, int k) : HashMain<K, V>(s, k){
        table.resize(s);
        used.resize(s, 0);
        // koytaDeleteAfterResize=0;
        // koytaInsertAfterResize= 0;
    }

    void reHash(int newSize){
        // hashingOrNot = true;
        vector<pair<K, V>> oldTable = table;
        vector<int> oldUsed = used;
        int oldSize = HashMain<K, V>::size;

        table.clear();
        used.clear();
        HashMain<K, V>::size = newSize;
        table.resize(newSize);
        used.resize(newSize, 0);

        HashMain<K, V>::sizeAtLastResize=HashMain<K, V>::count;
        HashMain<K, V>::count = 0;
        // collisions=0;
        HashMain<K, V>::koytaDeleteAfterResize=0;
        HashMain<K, V>::koytaInsertAfterResize=0;

        for(int i = 0; i < oldSize; i++){
            if(oldUsed[i]==1){
                int h1 = (HashMain<K, V>::konFunction == 1) ? HashMain<K, V>::hashFunction(oldTable[i].first) : HashMain<K, V>::hashFunction2(oldTable[i].first);
                int h2 = (HashMain<K, V>::konFunction == 1) ? HashMain<K, V>::hashFunction2(oldTable[i].first) : HashMain<K, V>::hashFunction(oldTable[i].first);
                if(h2 == 0) h2 = 1;

                for(int j=0; j<HashMain<K, V>::size; j++){
                    int idx = (h1 + j*h2)%HashMain<K, V>::size;

                    if(used[idx] == 1){
                        HashMain<K, V>::collisions++;
                    }
                    if(used[idx] == 0){
                        table[idx] = oldTable[i];
                        used[idx] = 1;
                        HashMain<K, V>::count++;
                        // if(j>0) collisions++;
                        break;
                    }
                }
            }
        }
    }    

    void insert(K key, V value){
        int lastThreshold;
        if(HashMain<K, V>::sizeAtLastResize==0){
            lastThreshold=HashMain<K, V>::count/2;
        }else{
            lastThreshold=HashMain<K, V>::sizeAtLastResize/2;
        }
        if(HashMain<K, V>::loadFactor() > MAX_LOAD && HashMain<K, V>::koytaInsertAfterResize >= lastThreshold){
            reHash(nextPrime(HashMain<K, V>::size*2));
            // koytaInsertAfterResize = 0;
            // koytaDeleteAfterResize = 0;
            
        }

        int h1 = (HashMain<K, V>::konFunction == 1) ? HashMain<K, V>::hashFunction(key) : HashMain<K, V>::hashFunction2(key);
        int h2 = (HashMain<K, V>::konFunction == 1) ? HashMain<K, V>::hashFunction2(key) : HashMain<K, V>::hashFunction(key);
        if(h2 == 0) h2 = 1;

        // int idx = hashFunction(key);
        int firstDel = -1;


        for(int i = 0; i < HashMain<K, V>::size; i++){
            int idx = (h1+i*h2)%HashMain<K, V>::size;
            //changing
            if(used[idx] == 1){
                HashMain<K, V>::collisions++;
            }
            if(used[idx]==0){
                if(firstDel != -1){
                    idx = firstDel;
                }
                table[idx] = {key, value};
                used[idx] = 1;
                HashMain<K, V>::count++;
                HashMain<K, V>::koytaInsertAfterResize++;
                // if(i > 0) collisions++;
                //changing
                // if(used[idx] == 1){
                //     collisions++;
                // }

                // cout << "Inserted " << key << endl;
                return;
            }
            if(used[idx]==2 && firstDel == -1){
                firstDel = idx;
            }
            if(used[idx]==1 && table[idx].first == key){
                return;
            }
        }
    }

    bool search(K key){
        // int idx = hashFunction(key);
        HashMain<K, V>::lastHits = 0;
        int h1 = (HashMain<K, V>::konFunction == 1) ? HashMain<K, V>::hashFunction(key) : HashMain<K, V>::hashFunction2(key);
        int h2 = (HashMain<K, V>::konFunction == 1) ? HashMain<K, V>::hashFunction2(key) : HashMain<K, V>::hashFunction(key);
        if(h2 == 0) h2 = 1;

        for(int i = 0; i < HashMain<K, V>::size; i++){
            int idx = (h1+i*h2)%HashMain<K, V>::size;
            HashMain<K, V>::lastHits++;
            if(used[idx]==0){
                return false;
            }
            if(used[idx]==1 && table[idx].first == key){
                // cout << "Found " << key << endl;
                return true;
            }
        }
        return false;
    }

    void remove(K key){
        // int idx = hashFunction(key);
        int h1 = (HashMain<K, V>::konFunction == 1) ? HashMain<K, V>::hashFunction(key) : HashMain<K, V>::hashFunction2(key);
        int h2 = (HashMain<K, V>::konFunction == 1) ? HashMain<K, V>::hashFunction2(key) : HashMain<K, V>::hashFunction(key);
        if(h2 == 0) h2 = 1;

        for(int i = 0; i < HashMain<K, V>::size; i++){
            int idx = (h1+i*h2)%HashMain<K, V>::size;
            if(used[idx]==0){
                return; // naikisu
            }
            if(used[idx]==1 && table[idx].first==key){
                used[idx] = 2;
                HashMain<K, V>::count--;
                HashMain<K, V>::koytaDeleteAfterResize++;


                int lastThreshold;

                if(HashMain<K, V>::sizeAtLastResize==0){
                    lastThreshold=HashMain<K, V>::count/2;
                }else{
                    lastThreshold=HashMain<K, V>::sizeAtLastResize/2;
                }
                
                if(HashMain<K, V>::loadFactor() < MIN_LOAD && HashMain<K, V>::size > INIT_SIZE && HashMain<K, V>::koytaDeleteAfterResize>=lastThreshold){
                    reHash(prevPrime(HashMain<K, V>::size/2));
                    // koytaDeleteAfterResize = 0;
                    // koytaInsertAfterResize = 0;
                }
                return;
            }
        }
        // cout << "Key not Found" << endl;
    }
    
};

template <typename K, typename V>
class CustomProbeHashTable : public HashMain<K, V>{
public:
    vector<pair<K, V>> table;
    vector<int> used;
    int C1 = 1;
    int C2 = 3;

    CustomProbeHashTable(int s, int k):HashMain<K, V>(s, k){
        table.resize(s);
        used.resize(s, 0);
    }


    void reHash(int newSize){
        vector<pair<K, V>> oldTable = table;
        vector<int> oldUsed = used;
        int oldSize = HashMain<K, V>::size;

        table.clear(); used.clear();
        HashMain<K, V>::size = newSize;
        table.resize(newSize);
        used.resize(newSize, 0);
        
        HashMain<K, V>::sizeAtLastResize = HashMain<K, V>::count;
        HashMain<K, V>::count = 0;
        // collisions = 0;
        HashMain<K, V>::koytaInsertAfterResize = 0;
        HashMain<K, V>::koytaDeleteAfterResize = 0;

        for(int i=0; i<oldSize; i++){
            if(oldUsed[i] == 1){
                int h1 = (HashMain<K, V>::konFunction == 1) ? HashMain<K, V>::hashFunction(oldTable[i].first) : HashMain<K, V>::hashFunction2(oldTable[i].first);
                int h2 = (HashMain<K, V>::konFunction == 1) ? HashMain<K, V>::hashFunction2(oldTable[i].first) : HashMain<K, V>::hashFunction(oldTable[i].first);
                if(h2 == 0) h2 = 1;

                for(int j=0; j<HashMain<K, V>::size; j++){
                    int chkchk = C1 * j * h2 + C2 * j * j;
                    int idx = (h1 + chkchk) % HashMain<K, V>::size;

                    if(used[idx] == 1){
                        HashMain<K, V>::collisions++;
                    }

                    if(used[idx] == 0){
                        table[idx] = oldTable[i];
                        used[idx] = 1;
                        HashMain<K, V>::count++;
                        // if(j>0) collisions++;
                        break;
                    }
                }
            }
        }
    }

    void insert(K key, V val){


        int lastThreshold;
        if(HashMain<K, V>::sizeAtLastResize==0){
            lastThreshold=HashMain<K, V>::count/2;
        }else{
            lastThreshold=HashMain<K, V>::sizeAtLastResize/2;
        }

        if(HashMain<K, V>::loadFactor() > MAX_LOAD && HashMain<K, V>::koytaInsertAfterResize>= lastThreshold){
            reHash(nextPrime(HashMain<K, V>::size*2));
        }
        int h1 = (HashMain<K, V>::konFunction == 1) ? HashMain<K, V>::hashFunction(key) : HashMain<K, V>::hashFunction2(key);
        int h2 = (HashMain<K, V>::konFunction == 1) ? HashMain<K, V>::hashFunction2(key) : HashMain<K, V>::hashFunction(key);
        if(h2 == 0) h2 = 1;

        for(int i = 0; i < HashMain<K, V>::size; i++){
            // int chkchk = C1*i*h2+C2*i*i;
            int idx = (h1+C1*i*h2 + C2*i*i)%HashMain<K, V>::size;

            if(used[idx] == 1){
                HashMain<K, V>::collisions++;
            }
            if(used[idx] == 0){
                table[idx]={key, val};
                used[idx] = 1;
                HashMain<K, V>::count++;
                HashMain<K, V>::koytaInsertAfterResize++;
                // if(i > 0) collisions++;
                // if(used[idx] == 1){
                //     collisions++;
                // }
                return;

            }

            if(used[idx] == 1 && table[idx].first == key) return;
        }
    }
    bool search(K key){
        // int idx = hashFunction(key);
        HashMain<K, V>::lastHits = 0;
        int h1 = (HashMain<K, V>::konFunction == 1) ? HashMain<K, V>::hashFunction(key) : HashMain<K, V>::hashFunction2(key);
        int h2 = (HashMain<K, V>::konFunction == 1) ? HashMain<K, V>::hashFunction2(key) : HashMain<K, V>::hashFunction(key);
        if(h2 == 0) h2 = 1;

        for(int i = 0; i < HashMain<K, V>::size; i++){
            int idx = (h1+C1*i*h2+C2*i*i)%HashMain<K, V>::size;
            HashMain<K, V>::lastHits++;
            if(used[idx]==0){
                return false;
            }
            if(used[idx]==1 && table[idx].first == key){
                // cout << "Found " << key << endl;
                return true;
            }
        }
        return false;
    }

    void remove(K key){
        // int idx = hashFunction(key);
        int h1 = (HashMain<K, V>::konFunction == 1) ? HashMain<K, V>::hashFunction(key) : HashMain<K, V>::hashFunction2(key);
        int h2 = (HashMain<K, V>::konFunction == 1) ? HashMain<K, V>::hashFunction2(key) : HashMain<K, V>::hashFunction(key);
        if(h2 == 0) h2 = 1;

        for(int i = 0; i < HashMain<K, V>::size; i++){
            int idx = (h1+C1*i*h2+C2*i*i)%HashMain<K, V>::size;
            if(used[idx]==0){
                return; // naikisu
            }
            if(used[idx]==1 && table[idx].first==key){
                used[idx] = 2;
                HashMain<K, V>::count--;
                HashMain<K, V>::koytaDeleteAfterResize++;
                // if(loadFactor() < MIN_LOAD && size > INIT_SIZE && koyTaDeleteAfterResize>=count/2){
                //     reHash(prevPrime(size/2));
                //     koyTaDeleteAfterResize = 0;
                //     koyTaInsertAfterResize = 0;
                // }
                return;

                int lastThreshold;
                if(HashMain<K, V>::sizeAtLastResize == 0){
                    lastThreshold = HashMain<K, V>::count/2;
                }else{
                    lastThreshold = HashMain<K, V>::sizeAtLastResize/2;
                }
                if(HashMain<K, V>::loadFactor() < MIN_LOAD && HashMain<K, V>::size > INIT_SIZE && HashMain<K, V>::koytaDeleteAfterResize >= lastThreshold){
                    reHash(prevPrime(HashMain<K, V>::size/2));
                }
                return;
            }
        }
        // cout << "Key not Found" << endl;
    }
};

template <typename K, typename V>
class ChainingHashTable : public HashMain<K, V>{
public:
    vector<list<pair<K, V>>> table;
    ChainingHashTable(int s, int k):HashMain<K, V>(s, k){
        table.resize(s);
    }



    void reHash(int newSize) {
        vector<list<pair<K, V>>> oldTable = table;
        
        HashMain<K, V>::size = newSize;
        table.clear();
        table.resize(newSize);
        
        HashMain<K, V>::sizeAtLastResize = HashMain<K, V>::count;
        HashMain<K, V>::count = 0;
        // collisions = 0;
        HashMain<K, V>::koytaInsertAfterResize = 0;
        HashMain<K, V>::koytaDeleteAfterResize = 0;

        for(auto &lst : oldTable){
            for(auto &p : lst){
                int idx = (HashMain<K, V>::konFunction == 1) ? HashMain<K, V>::hashFunction(p.first) : HashMain<K, V>::hashFunction2(p.first);
                if(!table[idx].empty()) HashMain<K, V>::collisions++;
                table[idx].push_back(p);
                HashMain<K, V>::count++;
            }
        }
    }

    void insert(K key, V value){
        int lastThreshold;
        if(HashMain<K, V>::sizeAtLastResize==0){
            lastThreshold=HashMain<K, V>::count/2;
        }else{
            lastThreshold=HashMain<K, V>::sizeAtLastResize/2;
        }
        if(HashMain<K, V>::loadFactor() > MAX_LOAD && HashMain<K, V>::koytaInsertAfterResize >= lastThreshold){
            reHash(nextPrime(HashMain<K, V>::size*2));          
        }
        int idx = (HashMain<K, V>::konFunction == 1) ? HashMain<K, V>::hashFunction(key) : HashMain<K, V>::hashFunction2(key);

        for(auto &p : table[idx]){
            if(p.first == key) return;
        }
        if(!table[idx].empty()){
            HashMain<K, V>::collisions++;
        }
        table[idx].push_back({key, value});
        HashMain<K, V>::count++;
        HashMain<K, V>::koytaInsertAfterResize++;
    }
    bool search(K key){
        HashMain<K, V>::lastHits=0;
        int idx = (HashMain<K, V>::konFunction == 1) ? HashMain<K, V>::hashFunction(key) : HashMain<K, V>::hashFunction2(key);
        for(auto &x : table[idx]){
            HashMain<K, V>::lastHits++;
            if(x.first==key){
                return true;
            }
        }
        return false;
    }

    void remove(K key){
        int idx = (HashMain<K, V>::konFunction == 1) ? HashMain<K, V>::hashFunction(key) : HashMain<K, V>::hashFunction2(key);
        for(auto it=table[idx].begin();it!=table[idx].end();it++){

            if(it->first==key){

                table[idx].erase(it);
                HashMain<K, V>::count--;
                HashMain<K, V>::koytaDeleteAfterResize++;
                int threshold = (HashMain<K, V>::sizeAtLastResize == 0) ? HashMain<K, V>::count/2 : HashMain<K, V>::sizeAtLastResize/2;
                if(HashMain<K, V>::loadFactor() < MIN_LOAD && HashMain<K, V>::size > INIT_SIZE && HashMain<K, V>::koytaDeleteAfterResize >= threshold){
                    reHash(prevPrime(HashMain<K, V>::size/2));
                }
                return;
            }
        }
    }

};

bool isPrime(int n){
    if(n<=1) return false;
    for(int i = 2; i < n; i++){
        if(n%i==0){
            return false;
        }
    }
    return true;
}

int nextPrime(int n){
    // n++;
    while(!isPrime(n)){
        n++;
    }
    return n;
}

int prevPrime(int n){
    n--;
    while(n>2 && !isPrime(n)){
        n--;
    }
    return n;
}

string WordGenerator(int n){
    string s = "";
    for(int i = 0; i < n; i++){
        char c = 'a' + rand()%26;
        s.push_back(c);
    }
    return s;
}

int main() {
    srand(time(0));
    const int TOTAL = 10000;
    const int SEARCH_COUNT = 1000;
    const int WORDLEN = 10;

    cout << "Generating words..." << endl;

    vector<string> allWords;
    unordered_set<string> uniqueGen;
    while(allWords.size() < TOTAL){
        string w = WordGenerator(WORDLEN);
        if(uniqueGen.find(w) == uniqueGen.end()){
            uniqueGen.insert(w);
            allWords.push_back(w);
        }
    }
    vector<string> searchWords;
    for(int i = 0; i < SEARCH_COUNT; i++){
        searchWords.push_back(allWords[rand() % TOTAL]);
    }


    int c_col1 = 0, d_col1 = 0, cp_col1 = 0;
    int c_col2 = 0, d_col2 = 0, cp_col2 = 0;
    double c_hits1 = 0, d_hits1 = 0, cp_hits1 = 0;
    double c_hits2 = 0, d_hits2 = 0, cp_hits2 = 0;

    for(int method = 0; method < 3;method++) {
        for(int hashMode = 1; hashMode <= 2; hashMode++) {
            // mainly 2 tar jonno emn
            HashMain<string, int>* ht = nullptr;

            if(method == 0) ht = new ChainingHashTable<string, int>(INIT_SIZE, hashMode);
            else if(method == 1) ht = new DoubleHashTable<string, int>(INIT_SIZE, hashMode);
            else ht = new CustomProbeHashTable<string, int>(INIT_SIZE, hashMode);
            for(int i = 0; i < TOTAL; i++) {
                ht->insert(allWords[i], i + 1);
            }
            // duitar collision ekshathe
            int collisions = ht->collisions;

            
            long long totalHits = 0;
            for(int i = 0; i < SEARCH_COUNT; i++) {
                ht->search(searchWords[i]);
                totalHits += ht->lastHits;
            }

            
            double avgHits = (double)totalHits / SEARCH_COUNT;


            if (method == 0) { 
                if (hashMode == 1) { c_col1 = collisions; c_hits1 = avgHits; }
                else{
                     c_col2 = collisions; c_hits2 = avgHits; 
                    }
            }
            else if (method == 1) { 
                if (hashMode == 1) { d_col1 = collisions; d_hits1 = avgHits; }
                else {
                     d_col2 = collisions; d_hits2 = avgHits; 
                    }
            }
            else { 
                if (hashMode == 1) {cp_col1 = collisions; cp_hits1 = avgHits; }
                else{
                     cp_col2 = collisions; cp_hits2 = avgHits; 
                    }
            }

            delete ht;
        }
    }


    cout << endl;
    cout << "----------------------------------------------------------------" << endl;
    cout << "Method\t\tHash1(Col)\tHash1(Hits)\tHash2(Col)\tHash2(Hits)" << endl;
    cout << "----------------------------------------------------------------" << endl;
    
    cout << "Chaining\t" << c_col1 << "\t\t" << c_hits1 << "\t\t" << c_col2 << "\t\t" << c_hits2 << endl;
    cout << "Double Hash\t" << d_col1 << "\t\t" << d_hits1 << "\t\t" << d_col2 << "\t\t" << d_hits2 << endl;
    cout << "Custom Probe\t" << cp_col1 << "\t\t" << cp_hits1 << "\t\t" << cp_col2 << "\t\t" << cp_hits2 << endl;
    
    cout << "----------------------------------------------------------------" << endl;

    return 0;
}