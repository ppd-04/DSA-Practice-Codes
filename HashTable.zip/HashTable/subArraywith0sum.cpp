// ---------------------------------------------------------
// PROBLEM 2: SUBARRAY WITH 0 SUM
// ---------------------------------------------------------
int main() {
    int n;
    cout << "Enter number of elements: ";
    cin >> n;
    vector<int> arr(n);
    cout << "Enter elements: ";
    for(int i = 0; i < n; i++) cin >> arr[i];

    DoubleHashTable<int, int>* ht = new DoubleHashTable<int, int>(INIT_SIZE, 1);
    
    int current_sum = 0;
    bool found = false;

    // IMPORTANT: Insert 0 initially to handle cases where subarray starts from index 0
    ht->insert(0, 1); 

    for(int i = 0; i < n; i++) {
        current_sum += arr[i];

        if(ht->search(current_sum)) {
            cout << "Found a subarray with 0 sum!" << endl;
            found = true;
            break;
        }
        
        ht->insert(current_sum, 1);
    }

    if(!found) cout << "No subarray with 0 sum found." << endl;

    delete ht;
    return 0;
}