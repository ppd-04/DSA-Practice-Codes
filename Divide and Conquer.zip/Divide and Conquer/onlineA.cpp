#include<iostream>
using namespace std;
int countInvertedPair(string str,int low,int high)
{
    if(low>=high)
        return 0;
    int mid = (low+high)/2;
    return countInvertedPair(str,low,mid) + countInvertedPair(str,mid+1,high) + (str[mid]>str[mid+1]);
}
int main()
{
    string str;
    cin >> str;
    cout << countInvertedPair(str,0,str.size()-1) << endl;
}