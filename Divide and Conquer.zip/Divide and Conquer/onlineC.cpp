#include <iostream>
using namespace std;
int merge(int arr[], int low, int mid, int high)
{
    int i = low, j = mid + 1, count = 0;
    int temp[high - low + 1];
    int k = 0;
    while (i <= mid && j <= high)
    {
        if (arr[j] < arr[i])
        {
            temp[k++] = arr[j++];
            count += mid - i + 1;
        }
        else
        {
            temp[k++] = arr[i++];
        }
    }
    while (i <= mid)
        temp[k++] = arr[i++];
    while (j <= high)
        temp[k++] = arr[j++];
    i = low;
    k = 0;
    while (i <= high)
        arr[i++] = temp[k++];
    return count;
}
int countInversion(int arr[], int low, int high)
{
    if (low >= high)
    {
        return 0;
    }
    int mid = (low + high) / 2;
    int count = countInversion(arr, low, mid);
    count += countInversion(arr, mid + 1, high);
    count += merge(arr, low, mid, high);
    return count;
}
int main()
{
    int n;
    cin >> n;
    int arr[n];
    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }
    cout << countInversion(arr, 0, n - 1) << endl;
    return 0;
}