#include<bits/stdc++.h>
using namespace std;

int countOnes(vector<int> arr){
    int low = 0;
    int high = arr.size()-1;
    int ans;

    while(low <= high){
        int mid = (low+high)/2;

        if(arr[mid] == 1){
            ans = mid;
            low = mid + 1;
        }
        else{
            high = high - 1;
        }
    }
    return ans+1;
}

// int countOnes(vector<int> arr){
//     int low = 0;
//     int high = arr.size() -1;
//     int ans;
//     while(low <= high){
//         int mid = (low + high)/2;

//         if(arr[mid] == 1){
//             ans = mid;
//             low = mid + 1;
//         }
//         else{
//             high = mid - 1;
//         }
//     }
//     return ans+1;
// }



int main(){
    vector<int> arr = { 1, 1, 1, 1, 0, 0, 0 };
    cout << countOnes(arr);
    return 0;
}