#include <bits/stdc++.h>
using namespace std;

// Tile number to be filled
int t = 0;

// Function to place tiles in the sub-grids
void place_tile(int x1, int y1, int x2, int y2, int x3, int y3,
     vector<vector<int>> &grid){
         
    t++;
    grid[x1][y1] = t;
    grid[x2][y2] = t;
    grid[x3][y3] = t;
}

// Recursive function to fill the grid
void solve(int sz, int r, int c, vector<vector<int>> &grid){
    
    // Base case: when the grid size is 2x2
    if (sz == 2){
        
        t++;
        for (int i = 0; i < sz; i++)
            for (int j = 0; j < sz; j++)
                if (grid[r + i][c + j] == 0)
                    grid[r + i][c + j] = t;
        return;
    }

    // To store the missing cell's coordinates
    int mr, mc;

    // Find the missing cell within the current sub-grid
    for (int i = r; i < r + sz; i++)
        for (int j = c; j < c + sz; j++)
            if (grid[i][j] != 0)
                mr = i, mc = j;

    // Place tiles based on the quadrant where the missing cell is located
    // First quadrant
    if (mr < r + sz / 2 && mc < c + sz / 2)
        place_tile(r + sz / 2, c + sz / 2 - 1, r + sz / 2, c + sz / 2, 
                   r + sz / 2 - 1, c + sz / 2, grid);
    // Second quadrant
    else if (mr >= r + sz / 2 && mc < c + sz / 2)
        place_tile(r + sz / 2 - 1, c + sz / 2, r + sz / 2, c + sz / 2, 
                   r + sz / 2 - 1, c + sz / 2 - 1, grid);
    // Third quadrant
    else if (mr < r + sz / 2 && mc >= c + sz / 2)
        place_tile(r + sz / 2, c + sz / 2 - 1, r + sz / 2, c + sz / 2, 
                   r + sz / 2 - 1, c + sz / 2 - 1, grid);
    // Fourth quadrant
    else
        place_tile(r + sz / 2 - 1, c + sz / 2, r + sz / 2, c + sz / 2 - 1,
                   r + sz / 2 - 1, c + sz / 2 - 1, grid);

    // Recursively solve for the 4 sub-grids
    // Top-right
    solve(sz / 2, r, c + sz / 2, grid);
    // Top-left
    solve(sz / 2, r, c, grid);
    // Bottom-left
    solve(sz / 2, r + sz / 2, c, grid);
    // Bottom-right
    solve(sz / 2, r + sz / 2, c + sz / 2, grid);
}
vector<vector<int>> tiling(int n, pair<int, int> missing_cell){
    
    vector<vector<int>> grid(n, vector<int>(n, 0));
    grid[missing_cell.first][missing_cell.second]= -1;
    
    solve(n, 0, 0, grid);
    return grid; 
} 

int main(){
    int n = 4;
    pair<int,int> missing_cell = {0,1};
    vector<vector<int>> grid = tiling(n, missing_cell);

    for (const auto &row : grid)
    {
        for (int cell : row)
            cout << cell << " ";
        cout << endl;
    }

    return 0;
}