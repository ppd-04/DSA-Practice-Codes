#include<bits/stdc++.h>
using namespace std;

// TC O (mlogn)

void findFreq(vector<int>& arr){
    int n = arr.size();
    int i = 0;
    while(i < n){
        int val = arr[i];
        int low = i;
        int high = arr.size()-1;
        
        int ans = i;
        while(low <= high){ 
            int mid = (low+high)/2;

            if(arr[mid] == arr[i]){
                ans = mid;
                low = mid + 1;
            }
            else if(arr[mid] > arr[i]){
                high = mid - 1;
            }
        }
        int cnt = ans - i + 1;
        cout << arr[i] << " " << cnt << endl;
        i = ans + 1;
    }
}

int main(){
    vector<int> arr = {1, 1, 1, 2, 3, 3, 5, 5, 8, 8, 8, 9, 9, 10};
    findFreq(arr);
    return 0;
}