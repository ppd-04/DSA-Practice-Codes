#include<bits/stdc++.h>
using namespace std;

int binarySearchSqrt(int n, int low, int high){
    int mid = (high + low)/2;
    
    if(low <= high){
        
        if(mid*mid == n){
            return mid;
        }
        if(mid * mid > n){
            return binarySearchSqrt(n, low, mid-1);
        }
        else if(mid * mid < n){
            return binarySearchSqrt(n, mid+1, high);
        }
    }
    return mid;


}

int main(){
    int n;
    cin >> n;
    int low = 1;
    int high = n;
    int ans = binarySearchSqrt(n, low, high);
    cout << "SQRT is: " << ans << endl;
    return 0;

}