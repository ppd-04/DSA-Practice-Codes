#include<iostream>
using namespace std;
int countUnique(int arr[], int low, int high)
{
    if(low>=high)
        return 1;
    int mid = (low+high)/2;
    return countUnique(arr,low,mid) + countUnique(arr,mid+1,high) + ((arr[mid]==arr[mid+1]) ? -1 : 0);
}
int main()
{
    int n;
    cin >> n;
    int arr[n];
    for(int i=0;i<n;i++)
    {
        cin >> arr[i];
    }
    cout << countUnique(arr,0,n-1) << endl;
}
