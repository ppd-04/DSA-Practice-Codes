#include<bits/stdc++.h>
using namespace std;


int main(){
    int arr[10] = {1,4,6,8,12,14,19,23,40,50};

    int low = 0;
    int high = 9;
    int mid;
    int target;
    cin >> target;

    while(low <= high){
        mid = (high+low)/2;
        if(arr[mid] == target){
            cout << "Found at index " << mid << endl;
            return 0;
        }
        if(arr[mid] > target){
            high = mid-1;
        }else if(arr[mid] < target){
            low = mid + 1;
        }
        
    }
    cout << "Not found" << endl;
    return 0;
}