#include<bits/stdc++.h>
using namespace std;

int findFirst(vector<int> arr, int x){
    int low = 0;
    int high = arr.size()-1;
    int first = -1;
    while(low <= high){
        int mid = (low+high)/2;

        if(arr[mid] == x){
            first = mid;
            high = mid-1;
        }
        else if(arr[mid] > x){
            high = mid - 1;
        }
        else if(arr[mid] < x){
            low = mid + 1;
        }
    }
    
    return first;
}

int findLast(vector<int> arr, int x){
    int low = 0;
    int high = arr.size()-1;
    int last = -1;
    while(low <= high){
        int mid = (low+high)/2;

        if(arr[mid] == x){
            last = mid;
            low = mid + 1; 

        }
        else if(arr[mid] > x){
            high = mid -1;
        }
        else if(arr[mid] < x){
            low = mid + 1;
        }
    }
    return last;

}

vector<int> find(vector<int> arr, int x){
    int first = findFirst(arr, x);
    int last = findLast(arr, x);
    vector<int> ans = {first, last};
    return ans;
}

int main(){
    vector<int> arr = {1, 3, 5, 5, 5, 5, 67, 123, 125};
    int x;
    cin >> x;
    vector<int> ans = find(arr, x);
    for(int i = 0; i < ans.size(); i++){
        cout << ans[i] << endl;
    }
    return 0;


}