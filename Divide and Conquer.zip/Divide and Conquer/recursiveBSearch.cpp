#include<bits/stdc++.h>
using namespace std;

int binarySearch(vector<int> arr, int target, int high, int low){
    if(high >= low){
        int mid = (high + low)/2;
        
        if(arr[mid] == target){
            return mid;
        }
        if(arr[mid] > target){
            return binarySearch(arr, target, mid-1, low);
        }
        else if(arr[mid] < target){
            return binarySearch(arr, target, high, mid+1);
        }

    }
    return -1;
}

int main(){
    vector<int> arr = {1,4,6,8,12,14,19,23,40,50};
    int target;
    cin >> target;
    int low = 0;
    int high = arr.size()-1;
    int ans = binarySearch(arr, target, high, low);
    if(ans != -1){
        cout << "Found at index " << ans << endl;
    }
    else{
        cout << "Not found" << endl;
    }
    return 0;


}