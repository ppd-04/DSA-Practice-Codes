#include <bits/stdc++.h>
using namespace std;

// normal approach

// int f(int idx, int n, vector<int> &price){
//     if(idx == 0){
//         return n * price[0];
//     }
//     int notTake = f(idx-1, n, price);

//     int take = INT16_MIN;

//     int rodLength = idx + 1;
//     if(rodLength <= n){
//         take = price[idx] + f(idx, n-rodLength, price);
//     }
//     return max(take, notTake);

// }

// int rodCutting(vector<int>&price, int n){
//     return f(n-1, n, price);
// }

// dp

int f(int idx, int n, vector<int> &price, vector<vector<int>> &dp)
{
    if (idx == 0)
    {
        return n * price[0];
    }

    if (dp[idx][n] != -1)
        return dp[idx][n];
    int notTake = f(idx - 1, n, price, dp);

    int take = INT16_MIN;

    int rodLength = idx + 1;
    if (rodLength <= n)
    {
        take = price[idx] + f(idx, n - rodLength, price, dp);
    }
    return dp[idx][n] = max(take, notTake);
}

int rodCutting(vector<int> &price, int n)
{
    vector<vector<int>> dp(n, vector<int>(n + 1, -1));
    return f(n - 1, n, price, dp);
}

int main()
{
    int len = 10;
    vector<int> price = {1, 5, 8, 9, 10, 17, 17, 20, 24, 30};
    int ans = rodCutting(price, len);
    cout << ans << endl;
    return 0;
}

// #include<bits/stdc++.h>
// using namespace std;

// int f(int idx, int n, vector<int> &price, vector<vector<int>> &dp){
//     if(idx == 0){
//         return n * price[0];
//     }
//     if(dp[idx][n] != -1) return dp[idx][n];

//     int notTake = f(idx-1, n, price, dp);
//     int Take = INT_MIN;

//     int rodLen = idx + 1;
//     if(rodLen <= n){
//         Take = price[idx] + f(idx, n - rodLen, price, dp);
//     }
//     return dp[idx][n] = max(notTake, Take);
// }

// int rodCutting(vector<int> price, int n){
//     vector<vector<int>> dp(n, vector<int> (n+1, -1));
//     return f(n-1, n, price, dp);
// }

// int main(){
//     int len = 10;
//     vector<int> price = {1,5,8,9,10,17,17,20,24,30};
//     int ans = rodCutting(price, len);
//     cout << ans << endl;
//     return 0;
// }