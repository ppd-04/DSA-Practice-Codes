#include<iostream>
#include<vector>
#include<algorithm>
using namespace std;

int func(vector<vector<int>>&dp, vector<int> &val, vector<int>&wt, int w, int n){
    if(n == 0 || w == 0){
        return 0;
    }

    if(dp[n][w] != -1){
        return dp[n][w];
    }
    int take = 0;
    int notTake =  func(dp, val, wt, w, n-1);        
    if(wt[n-1] <= w){
        take = val[n-1] + func(dp, val, wt, w-wt[n-1], n-1);
        // notTake = func(dp, val, wt, w, n-1);        
    }
    return dp[n][w] = max(take, notTake);

}

int knapsack(int w, vector<int> &val, vector<int> &wt){
    int n = val.size();
    vector<vector<int>> dp(n+1, vector<int> (w+1, -1));
    return func(dp, val, wt, w, n);
}



int main(){
    vector<int> val = {1, 2, 3};
    vector<int> wt = {4, 5, 1};
    int W = 4;

    cout << knapsack(W, val, wt) << endl;
    return 0;
}