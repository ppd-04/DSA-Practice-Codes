#include <iostream>
#include<vector>
#include<algorithm>
using namespace std;

// class Job{
// public:
//     int startTime;
//     int finishTime;
//     int value;

//     Job() = default;
//     Job(int startTime, int finishTime, int value){
//         this->startTime = startTime;
//         this->finishTime = finishTime;
//         this->value = value;
//     }
// };
//     bool compareFinish(Job a, Job b){
//         return a.finishTime < b.finishTime;
//     }

//     int lastConflict(const vector<Job>& jobs, int i){
//         int low = 0;
//         int high = i-1;
//         while(low <= high){
//             int mid = (low + high)/2;
//             if(jobs[mid].finishTime <= jobs[i].startTime){
//                 if(mid+1 <= high && jobs[mid+1].finishTime <= jobs[i].startTime){
//                     low = mid+1;
//                 }else{
//                     return mid;
//                 }
//             }else{
//                 high = mid -1;
//             }
//         }
//         return -1;
//     }

//     int fun(vector<Job> &jobs, vector<int>&dp, int i){
//         if(i == 0) return jobs[i].value;
//         if(dp[i] != -1) return dp[i];

//         int include = jobs[i].value;
//         int l = lastConflict(jobs, i);

//         if(l != -1){
//             include += fun(jobs, dp, l);
//         }
//         int exclude = fun(jobs, dp, i-1);

//         return dp[i] = max(include, exclude);
//     }
//     int schedule(vector<Job>&jobs){
//         sort(jobs.begin(), jobs.end(), compareFinish);
//         int n = jobs.size();
//         vector<int> dp(n, -1);
//         return fun(jobs, dp, n-1);
//     }

class Job{
public:
    int start;
    int finish;
    int value;

    Job() = default;
    Job(int start, int finish, int value){
        this->start = start;
        this->finish = finish;
        this->value = value;
    }

};

bool compareJob(Job a, Job b){
    return a.finish < b.finish;
}

int lastNonConflict(vector<Job> &jobs, int i){
    int low = 0;
    int high = i-1;

    while(low <= high){
        int mid = (high+low)/2;

        if(jobs[mid].finish <= jobs[i].start){
            if(jobs[mid+1].finish <= jobs[i].start){
                low = mid+1;
            }else{
                return mid;
            }
        }else{
            high = mid-1;
        }
    }
    return -1;
}

int fun(vector<Job> &jobs, vector<int>&dp, int n){
    if(n == 0) return jobs[0].value;

    if(dp[n] != -1){
        return dp[n];
    }
    int include = jobs[n].value;
    int l = lastNonConflict(jobs, n);
    if(l != -1){
        include += fun(jobs, dp, l);
    }
    int exclude = fun(jobs, dp, n-1);

    return max(include, exclude);

}

int schedule(vector<Job>&jobs){
    sort(jobs.begin(), jobs.end(), compareJob);
    int n = jobs.size();
    vector<int> dp(n, -1);
    return fun(jobs, dp, n-1);
}

int main() {
    int n;
    cin >> n;
    vector<Job> jobs(n);
    for(int i = 0; i < n; i++){
        cin >> jobs[i].start >> jobs[i].finish >> jobs[i].value;
    }
    cout << schedule(jobs) << endl;

    return 0;
}

