#include <iostream>
#include<vector>
#include<algorithm>
using namespace std;

int minDistanceMemo(vector<vector<int>>&dp, string& s1, string& s2, int m, int n){
    if(m == 0){
        return n;
    }
    if(n == 0){
        return m;
    }

    if(dp[m][n] != -1) return dp[m][n];

    if(s1[m-1] == s2[n-1]){
        dp[m][n] = minDistanceMemo(dp, s1, s2, m-1, n-1);
    }
    else{
        int insertChk = minDistanceMemo(dp, s1, s2, m, n-1);
        int deleteChk = minDistanceMemo(dp, s1, s2, m-1, n);
        int replaceChk = minDistanceMemo(dp, s1, s2, m-1, n-1);

        return dp[m][n] = 1 + min({insertChk, deleteChk, replaceChk});
    }
    return dp[m][n];
}

int minOperations(string& s1, string& s2){
    int m = s1.size();
    int n = s2.size();
    vector<vector<int>> dp(m+1, vector<int> (n+1, -1));
    return minDistanceMemo(dp, s1, s2, m, n);
}





int main() {
    string x, y;
    cin >> x >> y;
    cout << minOperations(x,y) << endl;
    return 0;
}



// #include<iostream>
// #include<vector>
// using namespace std;
// int minOperations(string str1, string str2){
//     int m = str1.length();
//     int n = str2.length();
//     vector<vector<int>> dp(m+1, vector<int>(n+1,0));
//     for(int i=0;i<=m;i++){
//         dp[i][0] = i;
//     }
//     for(int j=0;j<=n;j++){
//         dp[0][j] = j;
//     }
//     for(int i=1;i<=m;i++){
//         for(int j=1;j<=n;j++){
//             if(str1[i-1]==str2[j-1]){
//                 dp[i][j] = dp[i-1][j-1];
//             }
//             else{
//                 dp[i][j] = 1 + min(min(dp[i-1][j],dp[i][j-1]),dp[i-1][j-1]);
//             }
//         }
//     }
//     return dp[m][n];
// }
// int main(){
//     string str1, str2;
//     getline(cin,str1);
//     getline(cin,str2);
//     cout << minOperations(str1,str2) << endl;
// }