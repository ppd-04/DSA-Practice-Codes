#include <iostream>
#include<algorithm>
#include<vector>
using namespace std;

int fun(vector<vector<int>> &dp, vector<int> &val, vector<int> &wt, int W, int n){
    if(n == 0 || W == 0){
        return 0;
    }
    if(dp[n][W] != -1){
        return dp[n][W];
    }

    int take = 0;
    int notTake = fun(dp, val, wt, W, n-1);

    if(wt[n-1] <= W){
        take = fun(dp, val, wt,  W-wt[n-1], n) + val[n-1];
    }

    return dp[n][W] = max(take, notTake);


}

int repeatKnapsack(vector<int> &val, vector<int> &wt, int W, int n){
    vector<vector<int>> dp(n+1, vector<int> (W+1, -1));

    return fun(dp, val, wt, W, n);

}

int main() {
    int n;
    cin >> n;
    vector<int> wt(n);
    vector<int> val(n);
    int W;

    for(int i = 0; i < n; i++){
        cin >> wt[i];
        cin >> val[i];
    }
    cin >> W;

    cout << repeatKnapsack(val, wt, W, n);

    return 0;
}