#include <iostream>
#include<vector>
using namespace std;

int maxRobbery(vector<vector<int>>&dp, vector<int>&val, vector<int>&wt, int n, int w){
    if(n == 0 || w == 0) return 0;

    if(dp[n][w] != -1) return dp[n][w];

    if(wt[n-1] <= w){
        int take;
        int notTake;
        // int take = val[n-1] + maxRobbery(dp, val, wt, n-2, w-wt[n-1]);
        if(n-2 >= 0){
            take = val[n-1] + maxRobbery(dp, val, wt, n-2, w-wt[n-1]);
        }else{
            take = val[n-1] + 0;
        }
        notTake = maxRobbery(dp, val, wt, n-1, w); 
        dp[n][w] = max(take, notTake);
    }
    else{
        return dp[n][w] =  maxRobbery(dp, val, wt, n-1, w);
    }
    return dp[n][w];
}

int main() {
        int n, w;
    cin >> n >> w;
    vector<int> val(n), wt(n);
    for (int i = 0; i < n; i++)
    {
        cin >> val[i];
    }
    for (int i = 0; i < n; i++)
    {
        cin >> wt[i];
    }
    vector<vector<int>> dp(n + 1, vector<int>(w + 1, -1));
    // cout << maxRobbery(val, wt, n, w) << endl; //Tabulation
    cout << maxRobbery(dp,val, wt, n, w) << endl; //Memoization
    return 0;
}



// #include <iostream>
// #include <vector>
// using namespace std;
// /*Tabulation*/
// int maxRobbery(vector<int> val, vector<int> wt, int n, int w)
// {
//     vector<vector<int>> dp(n + 1, vector<int>(w + 1, 0));
//     for (int i = 1; i <= n; i++)
//     {
//         for (int j = 1; j <= w; j++)
//         {
//             if (wt[i - 1] <= j)
//             {
//                 if (i > 1)
//                 {
//                     dp[i][j] = max(val[i - 1] + dp[i - 2][j - wt[i - 1]], dp[i - 1][j]);
//                 }
//                 else
//                 {
//                     dp[i][j] = max(val[i - 1], dp[i - 1][j]);
//                 }
//             }
//             else
//             {
//                 dp[i][j] = dp[i - 1][j];
//             }
//         }
//     }
//     return dp[n][w];
// }

// /*Memoization*/
// // int maxRobbery(vector<vector<int>> &dp,vector<int> &val, vector<int> &wt, int n, int w)
// // {
    
// //     if(n<=0 || w<=0)
// //     {
// //         return 0;
// //     }
// //     if(dp[n][w]!=-1)
// //     {
// //         return dp[n][w];
// //     }
// //     if(wt[n-1]<=w)
// //     {
// //         int a = val[n-1] + maxRobbery(dp,val,wt,n-2,w-wt[n-1]);
// //         int b = maxRobbery(dp,val,wt,n-1,w);
// //         dp[n][w] = max(a,b);
// //     }
// //     else{
// //         return maxRobbery(dp,val,wt,n-1,w);
// //     }
// //     return dp[n][w];
// // }
// int main()
// {
    // int n, w;
    // cin >> n >> w;
    // vector<int> val(n), wt(n);
    // for (int i = 0; i < n; i++)
    // {
    //     cin >> val[i];
    // }
    // for (int i = 0; i < n; i++)
    // {
    //     cin >> wt[i];
    // }
    // vector<vector<int>> dp(n + 1, vector<int>(w + 1, -1));
    // cout << maxRobbery(val, wt, n, w) << endl; //Tabulation
    // //cout << maxRobbery(dp,val, wt, n, w) << endl; //Memoization
// }
