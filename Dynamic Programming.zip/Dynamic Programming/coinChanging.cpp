#include <iostream>
#include<vector>
#include<algorithm>
using namespace std;

int coinSolve(vector<vector<int>>&dp, vector<int>&val, int n, int v){
    if(v == 0){
        return 0;
    }
    if(n == 0){
        return INT_MAX-1;
    }
    if(dp[n][v] != -1) return dp[n][v];

    int take = INT_MAX;
    int notTake;

    if(val[n-1] <= v){
        take = 1 + coinSolve(dp, val, n, v-val[n-1]);
    }
    notTake = coinSolve(dp, val, n-1, v);
    return dp[n][v] = min(take, notTake);

}

int coinProblem(int n, vector<int> &val, int v){
    vector<vector<int>> dp(n+1, vector<int> (v+1, -1));

    int res = coinSolve(dp, val, n, v);
    return res;
}

int main() {
    int n;
    cin >> n;
    vector<int> val(n);
    for(int i = 0; i < n; i++){
        cin >> val[i];
    }
    int v;
    cin >> v;
    cout << coinProblem(n, val, v);
    return 0;
}

