#include <iostream>
#include<vector>
#include<algorithm>
using namespace std;

int longestVal(vector<vector<int>> &dp, string &s1, string &s2, int m, int n){
    if(m == 0 || n == 0){
        return 0;
    }
    if(dp[m][n] != -1){
        return dp[m][n];
    }
    if(s1[m-1] == s2[n-1]){
        return 1 + longestVal(dp, s1, s2, m-1, n-1);
    }
    else{
        dp[m][n] = max(longestVal(dp, s1, s2, m-1, n), longestVal(dp, s1, s2, m, n-1));
    }
    return dp[m][n];
}

int lcs(string &s1, string &s2){
    int m = s1.size();
    int n = s2.size();
    vector<vector<int>> dp(m+1, vector<int> (n+1, -1));

    return longestVal(dp, s1, s2, m, n);
}

int main() {
    string s1, s2;
    cin >> s1 >> s2;
    cout << lcs(s1, s2);
    return 0;
}