#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
using namespace std;

const int INF = 1e9;

int bfs(int s, int t, vector<int>& parent, vector<vector<int>>& residual, vector<vector<int>>& adj){
    for(int i = 0; i < parent.size(); i++){
        parent[i] = -1;
    }
    parent[s] = -2;

    queue<pair<int, int>> q;
    q.push({s, INF});
    while(!q.empty()){
        int u = q.front().first;
        int flow=q.front().second;
        q.pop();

        for(int v : adj[u]){
            if(parent[v]==-1 && residual[u][v] > 0){
                parent[v] = u;
                int notun = min(flow, residual[u][v]);

                if(v==t){
                    return notun;
                }
                q.push({v, notun});
            }
        }
    }
    return 0;
}

int edmondsKarp(int s, int t, int N, vector<vector<int>>& residual, vector<vector<int>>& adj){
    int maxFlow = 0;
    vector<int> parent(N+1);

    while(true){
        int flow = bfs(s, t, parent, residual, adj);
        if(flow == 0) break;

        maxFlow += flow;
        int cur = t;
        while(cur != s){
            int prev=parent[cur];
            residual[prev][cur] -= flow;
            residual[cur][prev] += flow;
            cur = prev;
        }
    }
    return maxFlow;
}

void addEdge(int u, int v, int c, vector<vector<int>>& adj, vector<vector<int>> &residual){
    adj[u].push_back(v);
    residual[u][v] += c;
}

bool dfsPath(int u, int t, vector<vector<int>>& flow, vector<vector<int>>& adj, vector<int>& path){
    if(u == t) return true;

    for(int v : adj[u]){
        if(flow[u][v] > 0){
            path.push_back(v);
            flow[u][v]--; // use this edge
            if(dfsPath(v, t, flow, adj, path)) return true;
            // backtrack
            path.pop_back();
            flow[u][v]++; 
        }
    }
    return false;
}

int main() {
    int T;
    cin >> T;

    while(T--){
        int N, M;
        cin >> N >> M;

        vector<vector<int>> adj(N+1);
        vector<vector<int>> residual(N+1, vector<int>(N+1, 0));
        vector<vector<int>> capacity(N+1, vector<int>(N+1, 0));

        for (int i = 0; i < M; i++) {
            int u, v;
            cin >> u >> v;
            addEdge(u, v, 1, adj, residual);
            capacity[u][v] = 1;
        }

        int s = 1, t = N;

        int maxFlow = edmondsKarp(s, t, N, residual, adj);
        cout << maxFlow << "\n";

        // Build flow matrix
        vector<vector<int>> flow(N+1, vector<int>(N+1, 0));
        for(int i=1;i<=N;i++){
            for(int j: adj[i]){
                flow[i][j] = capacity[i][j] - residual[i][j];
            }
        }

        // Extract and print paths
        for(int i=0; i<maxFlow; i++){
            vector<int> path;
            path.push_back(s);
            dfsPath(s, t, flow, adj, path);

            for(int k=0; k<path.size(); k++){
                if(k) cout << "->";
                cout << path[k];
            }
            cout << "\n";
        }
    }
    return 0;
}
