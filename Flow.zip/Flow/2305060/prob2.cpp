#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>

using namespace std;
const int INF = 1e9;

struct Edge{
    int u, v, c;
};

int bfs(int s, int t, vector<int>& parent, vector<vector<int>>& residual, vector<vector<int>>& adj){
    for(int i = 0; i < parent.size(); i++){
        parent[i] = -1;
    }
    parent[s] = -2;
    // queue er moddhe node and flow rakhbo
    queue<pair<int, int>> q;
    q.push({s, INF});
    while(!q.empty()){
        int u = q.front().first;
        int flow=q.front().second;
        q.pop();

        for(int v : adj[u]){
            if(parent[v]==-1 && residual[u][v] > 0){
                parent[v] = u;
                int notun = min(flow, residual[u][v]);

                if(v==t){
                    return notun;
                }
                q.push({v, notun});
            }
        }
    }
    return 0;
}

int edmondsKarp(int s, int t, int N, vector<vector<int>>& residual, vector<vector<int>>& adj){
    int maxFlow = 0;
    vector<int> parent(N);

    while(true){
        int flow = bfs(s, t, parent, residual, adj);
        if(flow == 0) break;

        maxFlow += flow;
        int cur = t;
        while(cur != s){
            int temp=parent[cur];
            residual[temp][cur] -= flow;
            residual[cur][temp] += flow;
            cur = temp;
        }
    }
    return maxFlow;

}

int main() {
    int N, M, K;
    cin >> N >> K>> M;
    
    int s, t;
    s = N;
    t = N+1;
    int NodeTotal = N+2;
    vector<vector<int>> adj(NodeTotal);
    vector<Edge> edges;
    vector<vector<int>> capacity(NodeTotal, vector<int>(NodeTotal, 0));
    vector<vector<int>> residual(NodeTotal, vector<int>(NodeTotal, 0));
    
    for (int i = 0; i < K; i++){
        adj[s].push_back(i);
        adj[i].push_back(s);
        capacity[s][i] = 1;
        residual[s][i] = 1; 
    }

    for(int i = 0; i < M; i++){
        int u, v;
        cin >> u >> v;

        // ekta test case e genjam kore
        // ensure korbo jate ulta na hoy

        // if (u >= K && v < K) swap(u, v);

        adj[u].push_back(v);
        adj[v].push_back(u);
        capacity[u][v] = 1;
        residual[u][v] = 1;
    }

    for(int i = K; i < N; i++){
        adj[i].push_back(t);
        adj[t].push_back(i);
        capacity[i][t] = 1;
        residual[i][t] = 1;
    }

    
    int anssss= edmondsKarp(s, t, NodeTotal, residual, adj);
    cout <<anssss << endl;
    // for(auto& e : edges){
    //     int flow = capacity[e.u][e.v]-residual[e.u][e.v];
    //     cout << e.u << " " << e.v << " " << flow << "/" << e.c << endl;
    // }
    for(int i = 0; i < K; i++){
        for(int v : adj[i]){
            if(v>=K && v < N && capacity[i][v] == 1 && residual[i][v] == 0){
                cout << i << " " << v << endl;
            }
        }
    }




    return 0;
}