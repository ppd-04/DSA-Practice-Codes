#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>

using namespace std;
const int INF = 1e9;

struct Edge{
    int u, v, c;
};

int bfs(int s, int t, vector<int>& parent, vector<vector<int>>& residual, vector<vector<int>>& adj){
    for(int i = 0; i < parent.size(); i++){
        parent[i] = -1;
    }
    parent[s] = -2;

    queue<pair<int, int>> q;
    q.push({s, INF});
    while(!q.empty()){
        int u = q.front().first;
        int flow=q.front().second;
        q.pop();

        for(int v : adj[u]){
            if(parent[v]==-1 && residual[u][v] > 0){
                parent[v] = u;
                int notun = min(flow, residual[u][v]);

                if(v==t){
                    return notun;
                }
                q.push({v, notun});
            }
        }
    }
    return 0;
}

int edmondsKarp(int s, int t, int N, vector<vector<int>>& residual, vector<vector<int>>& adj){
    int maxFlow = 0;
    vector<int> parent(N);

    while(true){
        int flow = bfs(s, t, parent, residual, adj);
        if(flow == 0) break;

        maxFlow += flow;
        int cur = t;
        while(cur != s){
            int prev=parent[cur];
            residual[prev][cur] -= flow;
            residual[cur][prev] += flow;
            cur = prev;
        }
    }
    return maxFlow;

}

void addEdge(int u, int v, int c, vector<vector<int>>& adj, vector<vector<int>> &residual){
    adj[u].push_back(v);
    adj[v].push_back(u);
    residual[u][v] += c;
}

int main() {

    int t;
    cin >> t;
    int count = 0;
    while(t--){
        int H, M;
        double R;
        cin >> M >> H >> R;
        vector<pair<double, double>> mice(M);
        for(int i = 0; i < M; i++){
            cin >> mice[i].first >> mice[i].second;
        }
        vector<pair<double, double>> holes(H);
        vector<int> cap(H);
        for(int i = 0; i < H; i++){
            cin >> holes[i].first >> holes[i].second >> cap[i];
        }
        int N = M+H+2;
        int S = 0; 
        int Tt = N-1;

        vector<vector<int>> adj(N);
        vector<Edge> edges;
        vector<vector<int>> capacity(N, vector<int>(N, 0));
        vector<vector<int>> residual(N, vector<int>(N, 0));
        
        for(int i = 0; i < M; i++){
            addEdge(S, 1+i, 1, adj, residual);
        }
        
        for(int i = 0; i < M; i++){
            for(int j = 0; j < H; j++){
                double dx = mice[i].first-holes[j].first;
                double dy = mice[i].second-holes[j].second;
                if(dx*dx+dy*dy <= R*R){
                    addEdge(1+i, 1+M+j, 1, adj, residual);
                }
            }
        }
        for(int j = 0; j < H; j++){
            addEdge(1+M+j, Tt, cap[j], adj, residual);
        }
        int maxMice = edmondsKarp(S, Tt, N, residual, adj);
        cout << "Case: " << ++count << ":" << maxMice << endl; 
    }



    return 0;
}
