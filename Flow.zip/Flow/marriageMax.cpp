// Imagine you are the matchmaker for a matrimonial service. Your objective is to find the
// maximum matches possible based on certain criteria identified through their bio-data. After
// reading through all the bio-data you found the following criteria set by the candidates:
// ● No man will marry a woman if the gap in their heights exceeds 10 inches.
// ● No woman is willing to marry a man if the age difference surpasses 5 years.
// ● Of-course a single man can marry a single woman and vice versa.
// Given the bio-data/information of a group of men and women, your task is to find the maximum
// matches possible between them and print the matches.

// Input:
// First line will contain two integers m, n (1 ≤ m, n ≤ 50) denoting the number of men and women.
// Each of the next m lines will contain the information for a man, and each of the next n lines will
// contain the information for a woman. An information will contain three integers denoting the
// height in inches, age in years and ID of a man or woman.
// Assume that Height will be between 50 and 80, age will be between 20 and 50.
// Output:
// First line should print an integer A denoting the maximum number of matches you can make.
// Next A lines should print each match in the format given in samples.



#include <iostream>
#include <vector>
#include <queue>
using namespace std;

const int INF = 1e9;

int bfs(int s, int t, vector<int>& parent,
        vector<vector<int>>& residual,
        vector<vector<int>>& adj)
{
    fill(parent.begin(), parent.end(), -1);
    parent[s] = -2;

    queue<pair<int,int>> q;
    q.push({s, INF});

    while(!q.empty()){
        auto [u, flow] = q.front(); q.pop();
        for(int v : adj[u]){
            if(parent[v] == -1 && residual[u][v] > 0){
                parent[v] = u;
                int newFlow = min(flow, residual[u][v]);
                if(v == t) return newFlow;
                q.push({v, newFlow});
            }
        }
    }
    return 0;
}

int maxFlow(int s, int t, int N,
            vector<vector<int>>& residual,
            vector<vector<int>>& adj)
{
    int flow = 0;
    vector<int> parent(N);

    while(true){
        int pushed = bfs(s, t, parent, residual, adj);
        if(pushed == 0) break;

        flow += pushed;
        int cur = t;
        while(cur != s){
            int prev = parent[cur];
            residual[prev][cur] -= pushed;
            residual[cur][prev] += pushed;
            cur = prev;
        }
    }
    return flow;
}

void addEdge(int u, int v, int c,
             vector<vector<int>>& adj,
             vector<vector<int>>& residual)
{
    adj[u].push_back(v);
    adj[v].push_back(u);
    residual[u][v] += c;
}

int main(){
    int m, n;
    cin >> m >> n;

    vector<int> mh(m), ma(m), mid(m);
    vector<int> wh(n), wa(n), wid(n);

    for(int i = 0; i < m; i++)
        cin >> mh[i] >> ma[i] >> mid[i];

    for(int j = 0; j < n; j++)
        cin >> wh[j] >> wa[j] >> wid[j];

    int S = 0;
    int T = m + n + 1;
    int total = m + n + 2;

    vector<vector<int>> adj(total);
    vector<vector<int>> residual(total, vector<int>(total, 0));

    // Source -> men
    for(int i = 0; i < m; i++)
        addEdge(S, 1 + i, 1, adj, residual);

    // Men -> women (if valid)
    for(int i = 0; i < m; i++){
        for(int j = 0; j < n; j++){
            if(abs(mh[i] - wh[j]) <= 10 &&
               abs(ma[i] - wa[j]) <= 5)
            {
                addEdge(1 + i, 1 + m + j, 1, adj, residual);
            }
        }
    }

    // Women -> sink
    for(int j = 0; j < n; j++)
        addEdge(1 + m + j, T, 1, adj, residual);

    int ans = maxFlow(S, T, total, residual, adj);

    cout << ans << "\n";

    // Print matches
    for(int i = 0; i < m; i++){
        int manNode = 1 + i;
        for(int j = 0; j < n; j++){
            int womanNode = 1 + m + j;
            if(residual[manNode][womanNode] == 0){
                cout << mid[i] << " " << wid[j] << "\n";
            }
        }
    }

    return 0;
}
