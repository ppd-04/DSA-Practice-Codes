// You have M tasks and N workers. Each task requires an amount of strength to complete the
// task. Each of the workers has a strength. You’re given the strength of the workers and the
// strength each job required to be completed. One worker can only do one task. Find the
// maximum number of tasks that can be assigned to the workers.

// Input:
// First line of input contains 2 integers N and M– denoting respectively the number of workers and
// the number of tasks.
// Second line contains N space separated integers denoting the strength of the workers.
// Third line contains M space separated integers denoting the strength required for each of the M
// jobs to be completed.
// Output:
// Maximum number of tasks that can be assigned to the workers.

#include <iostream>
#include <vector>
#include <queue>
using namespace std;

const int INF = 1e9;

int bfs(int s, int t, vector<int>& parent,
        vector<vector<int>>& residual,
        vector<vector<int>>& adj)
{
    fill(parent.begin(), parent.end(), -1);
    parent[s] = -2;

    queue<pair<int,int>> q;
    q.push({s, INF});

    while(!q.empty()){
        auto [u, flow] = q.front(); q.pop();
        for(int v : adj[u]){
            if(parent[v] == -1 && residual[u][v] > 0){
                parent[v] = u;
                int newFlow = min(flow, residual[u][v]);
                if(v == t) return newFlow;
                q.push({v, newFlow});
            }
        }
    }
    return 0;
}

int edmondsKarp(int s, int t, int N,
                vector<vector<int>>& residual,
                vector<vector<int>>& adj)
{
    int maxFlow = 0;
    vector<int> parent(N);

    while(true){
        int flow = bfs(s, t, parent, residual, adj);
        if(flow == 0) break;

        maxFlow += flow;
        int cur = t;
        while(cur != s){
            int prev = parent[cur];
            residual[prev][cur] -= flow;
            residual[cur][prev] += flow;
            cur = prev;
        }
    }
    return maxFlow;
}

void addEdge(int u, int v, int c,
             vector<vector<int>>& adj,
             vector<vector<int>>& residual)
{
    adj[u].push_back(v);
    adj[v].push_back(u);
    residual[u][v] += c;
}

int main(){
    int N, M;
    cin >> N >> M;

    vector<int> worker(N);
    vector<int> task(M);

    for(int i = 0; i < N; i++) cin >> worker[i];
    for(int j = 0; j < M; j++) cin >> task[j];

    int S = 0;
    int T = N + M + 1;
    int totalNodes = N + M + 2;

    vector<vector<int>> adj(totalNodes);
    vector<vector<int>> residual(totalNodes,
                                 vector<int>(totalNodes, 0));

    // Source -> workers
    for(int i = 0; i < N; i++){
        addEdge(S, 1 + i, 1, adj, residual);
    }

    // Worker -> task (if strength allows)
    for(int i = 0; i < N; i++){
        for(int j = 0; j < M; j++){
            if(worker[i] >= task[j]){
                addEdge(1 + i, 1 + N + j, 1, adj, residual);
            }
        }
    }

    // Tasks -> sink
    for(int j = 0; j < M; j++){
        addEdge(1 + N + j, T, 1, adj, residual);
    }

    int ans = edmondsKarp(S, T, totalNodes, residual, adj);
    cout << ans << endl;

    return 0;
}
