#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>
using namespace std;

const int INF = 1e9;

int bfs(int s, int t, vector<int>& parent,
        vector<vector<int>>& residual,
        vector<vector<int>>& adj)
{
    fill(parent.begin(), parent.end(), -1);
    parent[s] = -2;

    queue<pair<int,int>> q;
    q.push({s, INF});

    while(!q.empty()){
        auto [u, flow] = q.front(); q.pop();
        for(int v : adj[u]){
            if(parent[v] == -1 && residual[u][v] > 0){
                parent[v] = u;
                int newFlow = min(flow, residual[u][v]);
                if(v == t) return newFlow;
                q.push({v, newFlow});
            }
        }
    }
    return 0;
}

int edmondsKarp(int s, int t, int N,
                vector<vector<int>>& residual,
                vector<vector<int>>& adj)
{
    int maxFlow = 0;
    vector<int> parent(N);

    while(true){
        int flow = bfs(s, t, parent, residual, adj);
        if(flow == 0) break;
        maxFlow += flow;

        int cur = t;
        while(cur != s){
            int prev = parent[cur];
            residual[prev][cur] -= flow;
            residual[cur][prev] += flow;
            cur = prev;
        }
    }
    return maxFlow;
}

void addEdge(int u, int v, int c,
             vector<vector<int>>& adj,
             vector<vector<int>>& residual)
{
    adj[u].push_back(v);
    adj[v].push_back(u);
    residual[u][v] += c;
}

struct Person{
    int exp, age, crime, origin, weapon, trust, lang;
};

int main(){
    int T;
    cin >> T;
    for(int tc = 1; tc <= T; tc++){
        int m, n;
        cin >> m >> n;

        vector<Person> gang(m), partner(n);

        for(int i = 0; i < m; i++)
            cin >> gang[i].exp >> gang[i].age >> gang[i].crime
                >> gang[i].origin >> gang[i].weapon
                >> gang[i].trust >> gang[i].lang;

        for(int i = 0; i < n; i++)
            cin >> partner[i].exp >> partner[i].age >> partner[i].crime
                >> partner[i].origin >> partner[i].weapon
                >> partner[i].trust >> partner[i].lang;

        int S = 0;
        int Tt = m + n + 1;
        int N = Tt + 1;

        vector<vector<int>> adj(N);
        vector<vector<int>> residual(N, vector<int>(N, 0));

        // Source -> gang members
        for(int i = 0; i < m; i++)
            addEdge(S, 1 + i, 1, adj, residual);

        // Partners -> sink
        for(int j = 0; j < n; j++)
            addEdge(1 + m + j, Tt, 1, adj, residual);

        // Compatibility edges
        for(int i = 0; i < m; i++){
            for(int j = 0; j < n; j++){
                auto &A = gang[i];
                auto &B = partner[j];

                if(abs(A.exp - B.exp) > 12) continue;
                if(abs(A.age - B.age) > 5) continue;
                if(A.crime != B.crime) continue;
                if(A.origin != B.origin) continue;
                if(!(A.weapon == 1 || B.weapon == 1)) continue;
                if(A.trust + B.trust < 10) continue;
                if((A.lang & B.lang) == 0) continue;

                addEdge(1 + i, 1 + m + j, 1, adj, residual);
            }
        }

        int ans = edmondsKarp(S, Tt, N, residual, adj);
        cout << "Case " << tc << ": " << ans << "\n";
    }
    return 0;
}
