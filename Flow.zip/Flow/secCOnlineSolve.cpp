#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>

using namespace std;
const int INF = 1e9;

struct Edge{
    int u, v, c;
};

int bfs(int s, int t, vector<int>& parent, vector<vector<int>>& residual, vector<vector<int>>& adj){
    for(int i = 0; i < parent.size(); i++){
        parent[i] = -1;
    }
    parent[s] = -2;

    queue<pair<int, int>> q;
    q.push({s, INF});
    while(!q.empty()){
        int u = q.front().first;
        int flow=q.front().second;
        q.pop();

        for(int v : adj[u]){
            if(parent[v]==-1 && residual[u][v] > 0){
                parent[v] = u;
                int notun = min(flow, residual[u][v]);

                if(v==t){
                    return notun;
                }
                q.push({v, notun});
            }
        }
    }
    return 0;
}

int edmondsKarp(int s, int t, int N, vector<vector<int>>& residual, vector<vector<int>>& adj){
    int maxFlow = 0;
    vector<int> parent(N);

    while(true){
        int flow = bfs(s, t, parent, residual, adj);
        if(flow == 0) break;

        maxFlow += flow;
        int cur = t;
        while(cur != s){
            int prev=parent[cur];
            residual[prev][cur] -= flow;
            residual[cur][prev] += flow;
            cur = prev;
        }
    }
    return maxFlow;

}

void addEdge(int u, int v, int c, vector<vector<int>>& adj, vector<vector<int>> &residual){
    adj[u].push_back(v);
    adj[v].push_back(u);
    residual[u][v] += c;
}

int main() {
    int N, M;
    cin >> N >> M;
    int totalNode = 2*N+1;
    vector<vector<int>> adj(totalNode);
    vector<Edge> edges;
    vector<vector<int>> capacity(N, vector<int>(N, 0));
    vector<vector<int>> residual(totalNode, vector<int>(totalNode, 0));


    for(int v = 2; v <= N-1; v++){
        addEdge(v, v+N, 1, adj, residual);
    }

    addEdge(1, 1+N, INF, adj, residual);
    addEdge(N, N+N, INF, adj, residual);

    for (int i = 0; i < M; i++) {
        int u, v;
        cin >> u >> v;
        addEdge(u+N, v, 1, adj, residual);
  
    }
    int s, t;

    s = 1+N;
    t = N;
    int anssss= edmondsKarp(s, t, totalNode, residual, adj);
    cout << anssss << endl;




    return 0;
}