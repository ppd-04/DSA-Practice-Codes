#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>

using namespace std;
const int INF = 1e9;

struct Edge{
    int u, v, c;
};

int bfs(int s, int t, vector<int>& parent, vector<vector<int>>& residual, vector<vector<int>>& adj){
    for(int i = 0; i < parent.size(); i++){
        parent[i] = -1;
    }
    parent[s] = -2;

    queue<pair<int, int>> q;
    q.push({s, INF});
    while(!q.empty()){
        int u = q.front().first;
        int flow=q.front().second;
        q.pop();

        for(int v : adj[u]){
            if(parent[v]==-1 && residual[u][v] > 0){
                parent[v] = u;
                int notun = min(flow, residual[u][v]);

                if(v==t){
                    return notun;
                }
                q.push({v, notun});
            }
        }
    }
    return 0;
}

int edmondsKarp(int s, int t, int N, vector<vector<int>>& residual, vector<vector<int>>& adj){
    int maxFlow = 0;
    vector<int> parent(N);

    while(true){
        int flow = bfs(s, t, parent, residual, adj);
        if(flow == 0) break;

        maxFlow += flow;
        int cur = t;
        while(cur != s){
            int prev=parent[cur];
            residual[prev][cur] -= flow;
            residual[cur][prev] += flow;
            cur = prev;
        }
    }
    return maxFlow;

}

void addEdge(int u, int v, int c, vector<vector<int>>& adj, vector<vector<int>> &residual){
    adj[u].push_back(v);
    adj[v].push_back(u);
    residual[u][v] += c;
}

int main() {
    int N, M;
    cin >> N >> M;
    vector<vector<int>> adj(N);
    vector<Edge> edges;
    vector<vector<int>> capacity(N, vector<int>(N, 0));
    vector<vector<int>> residual(N, vector<int>(N, 0));
    for (int i = 0; i < M; i++) {
        int u, v, c;
        cin >> u >> v >> c;

        edges.push_back({u, v, c});
        capacity[u][v] += c;
        residual[u][v] += c;

        adj[u].push_back(v);
        adj[v].push_back(u);  
    }
    int s, t;
    cin >> s >> t;
    int anssss= edmondsKarp(s, t, N, residual, adj);
    cout << anssss << endl;
    for(auto& e : edges){
        int flow = capacity[e.u][e.v]-residual[e.u][e.v];
        cout << e.u << " " << e.v << " " << flow << "/" << e.c << endl;
    }




    return 0;
}