#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>

using namespace std;
const int INF = 1e9;

struct Edge{
    int u, v, c;
};

int bfs(int s, int t, vector<int>& parent, vector<vector<int>>& residual, vector<vector<int>>& adj){
    for(int i = 0; i < parent.size(); i++){
        parent[i] = -1;
    }
    parent[s] = -2;

    queue<pair<int, int>> q;
    q.push({s, INF});
    while(!q.empty()){
        int u = q.front().first;
        int flow=q.front().second;
        q.pop();

        for(int v : adj[u]){
            if(parent[v]==-1 && residual[u][v] > 0){
                parent[v] = u;
                int notun = min(flow, residual[u][v]);

                if(v==t){
                    return notun;
                }
                q.push({v, notun});
            }
        }
    }
    return 0;
}

int edmondsKarp(int s, int t, int N, vector<vector<int>>& residual, vector<vector<int>>& adj){
    int maxFlow = 0;
    vector<int> parent(N);

    while(true){
        int flow = bfs(s, t, parent, residual, adj);
        if(flow == 0) break;

        maxFlow += flow;
        int cur = t;
        while(cur != s){
            int prev=parent[cur];
            residual[prev][cur] -= flow;
            residual[cur][prev] += flow;
            cur = prev;
        }
    }
    return maxFlow;

}

int main() {
    int N, M;
    cin >> N >> M;
    vector<vector<int>> adj(N+1);
    vector<Edge> edges;
    vector<vector<int>> capacity(N+1, vector<int>(N+1, 0));
    vector<vector<int>> residual(N+1, vector<int>(N+1, 0));
    for (int i = 0; i < M; i++) {
        int u, v, c;
        cin >> u >> v >> c;

        edges.push_back({u, v, c});
        capacity[u][v] += c;
        residual[u][v] += c;

        adj[u].push_back(v);
        adj[v].push_back(u);  
    }
    int P;
    cin >> P;
    vector<Edge> proposals;
    for(int i = 0; i < P; i++){
        int u, v, c;
        cin >> u >> v >> c;
        proposals.push_back({u, v, c});
    }

    int s, t;
    // cin >> s >> t;
    s = 1; 
    t = N;
    vector<vector<int>> residualCopy = residual;
    int originalFlow = edmondsKarp(s, t, N+1, residualCopy, adj);
    vector<int> answer;

    for(int i = 0; i < P; i++){
        vector<vector<int>> adj2 = adj;
        vector<vector<int>> residual2 = capacity;

        int u = proposals[i].u;
        int v = proposals[i].v;
        int c = proposals[i].c;

        adj2[u].push_back(v);
        adj2[v].push_back(u);
        residual2[u][v] += c;

        int newFlow = edmondsKarp(s, t, N+1, residual2, adj2);
        if(newFlow > originalFlow){
            answer.push_back(i+1);
        }
    }
    if(answer.empty()){
        cout << "None" << endl;
    }
    else{
        for(int i = 0; i < answer.size(); i++){
            cout << answer[i] << " ";
        }
        cout << endl;
    }




    return 0;
}