// Statement:
// There are M jobs and N applicants. Each applicant can do some jobs. Your task is to assign
// these jobs to the applicants so that maximum applicants get a job. Given the condition is one
// applicant will be assigned one job and vice versa.

// Input:
// First line of input contains 2 integers N and M– denoting respectively the number of applicants
// and the number of jobs. You can assign IDs 1-N to N applicants and IDs 1-M to M jobs.
// Each of the next M lines contains space separated integers. First of which represent the job ID
// followed by the applicant IDs applied for that job.
// Output:
// Maximum number of jobs that can be assigned to the applicants.

#include <iostream>
#include <vector>
#include <queue>
using namespace std;

const int INF = 1e9;

int bfs(int s, int t, vector<int>& parent,
        vector<vector<int>>& residual,
        vector<vector<int>>& adj)
{
    fill(parent.begin(), parent.end(), -1);
    parent[s] = -2;

    queue<pair<int,int>> q;
    q.push({s, INF});

    while(!q.empty()){
        auto [u, flow] = q.front(); q.pop();
        for(int v : adj[u]){
            if(parent[v] == -1 && residual[u][v] > 0){
                parent[v] = u;
                int newFlow = min(flow, residual[u][v]);
                if(v == t) return newFlow;
                q.push({v, newFlow});
            }
        }
    }
    return 0;
}

int edmondsKarp(int s, int t, int N,
                vector<vector<int>>& residual,
                vector<vector<int>>& adj)
{
    int maxFlow = 0;
    vector<int> parent(N);

    while(true){
        int flow = bfs(s, t, parent, residual, adj);
        if(flow == 0) break;
        maxFlow += flow;

        int cur = t;
        while(cur != s){
            int prev = parent[cur];
            residual[prev][cur] -= flow;
            residual[cur][prev] += flow;
            cur = prev;
        }
    }
    return maxFlow;
}

void addEdge(int u, int v, int c,
             vector<vector<int>>& adj,
             vector<vector<int>>& residual)
{
    adj[u].push_back(v);
    adj[v].push_back(u);
    residual[u][v] += c;
}

int main(){
    int N, M;
    cin >> N >> M;

    int S = 0;
    int T = N + M + 1;
    int totalNodes = N + M + 2;

    vector<vector<int>> adj(totalNodes);
    vector<vector<int>> residual(totalNodes,
                                 vector<int>(totalNodes, 0));

    // Source -> applicants
    for(int i = 1; i <= N; i++){
        addEdge(S, i, 1, adj, residual);
    }

    // Jobs input
    for(int i = 0; i < M; i++){
        int jobID;
        cin >> jobID;

        int applicant;
        while(cin.peek() != '\n' && cin >> applicant){
            addEdge(applicant, N + jobID, 1, adj, residual);
        }
    }

    // Jobs -> sink
    for(int j = 1; j <= M; j++){
        addEdge(N + j, T, 1, adj, residual);
    }

    int ans = edmondsKarp(S, T, totalNodes, residual, adj);
    cout << ans << endl;

    return 0;
}
