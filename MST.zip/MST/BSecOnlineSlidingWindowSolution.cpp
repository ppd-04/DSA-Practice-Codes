#include<iostream>
#include<vector>
#include<queue>
#include<algorithm>

using namespace std;

struct Edge {
    int u, v, w;
};

class UnionFind {
public:
    vector<int> parent, size;
    UnionFind(int n) {
        parent.resize(n);
        size.resize(n, 1);
        for (int i = 0; i < n; i++)
            parent[i] = i;
    }

    int find(int x) {
        if (parent[x] == x) return x;
        return parent[x] = find(parent[x]);
    }

    bool unite(int a, int b) {
        a = find(a);
        b = find(b);
        if (a == b) return false;
        if (size[a] < size[b]) swap(a, b);
        parent[b] = a;
        size[a] += size[b];
        return true;
    }
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N, M;
    cin >> N >> M;

    vector<Edge> edges(M);
    for (int i = 0; i < M; i++) {
        cin >> edges[i].u >> edges[i].v >> edges[i].w;
    }

    // Sort edges by weight
    sort(edges.begin(), edges.end(), [](Edge &a, Edge &b) {
        return a.w < b.w;
    });

    int ans = INT_MAX;
    int L = 0;

    // Sliding window
    for (int R = 0; R < M; R++) {
        UnionFind uf(N + 1);

        // Build connectivity from L to R
        for (int i = L; i <= R; i++) {
            uf.unite(edges[i].u, edges[i].v);
        }

        // Check if graph is connected
        int comp = 0;
        for (int i = 1; i <= N; i++) {
            if (uf.find(i) == i) comp++;
        }

        // If connected, update answer and try to shrink window
        while (comp == 1 && L <= R) {
            ans = min(ans, edges[R].w - edges[L].w);

            // Move L forward
            L++;
            UnionFind uf2(N + 1);
            for (int i = L; i <= R; i++) {
                uf2.unite(edges[i].u, edges[i].v);
            }

            comp = 0;
            for (int i = 1; i <= N; i++) {
                if (uf2.find(i) == i) comp++;
            }
        }
    }

    if (ans == INT_MAX) cout << -1 << "\n";
    else cout << ans << "\n";

    return 0;
}
