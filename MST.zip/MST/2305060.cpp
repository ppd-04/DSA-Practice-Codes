#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>

using namespace std;
const int INF = 1e9;

struct Edge{
    int u, v, weight;
    Edge(int u, int v, int w) : u(u), v(v), weight(w){}
};

class UnionFind{
    vector<int> Parent;
    vector<int> Size;
public:
    UnionFind(int n){
        Parent.resize(n);
        for(int i = 0; i < n; i++){
            Parent[i] = i;
        }
        Size.resize(n, 1);
    }
    
    int find(int i){
        int root = Parent[i]; 

        if(root != Parent[root]){
            return Parent[i] = find(root);
        }
        return root;
    }   

    void unite(int i, int j){
        int irep = find(i);
        int jrep = find(j);

        if(irep == jrep) return;

        if(Size[irep] < Size[jrep]){
            Parent[irep] = jrep;
            Size[jrep] += Size[irep];
        }
        else{
            Parent[jrep] = irep;
            Size[irep] += Size[jrep];
        }
    }
};


bool comparator(Edge& e1, Edge& e2){
    return e1.weight < e2.weight;
}

pair<vector<Edge>, int> kruskalMST(int V, vector<Edge>& edges){
    sort(edges.begin(), edges.end(), comparator);
    UnionFind uf(V+1);
    vector<Edge> mst;
    int totalWeight = 0;

    for(Edge& e : edges){
        if(uf.find(e.u) != uf.find(e.v)){
            uf.unite(e.u, e.v);
            mst.push_back(e);
            totalWeight += e.weight;
        }
    }
    return {mst, totalWeight};
}


pair<vector<Edge>, int> findMST(int n, vector<Edge>& edges, int src){
    vector<vector<pair<int, int>>> adj(n+1);
    for(auto& e : edges){
        adj[e.u].push_back({e.v, e.weight});
        adj[e.v].push_back({e.u, e.weight});

    }
    //  {weight, {curnode, parnode}}
    priority_queue<pair<int, pair<int, int>>, vector<pair<int, pair<int, int>>>, greater<>> pq;
    vector<bool> inMST(n+1, false);
    vector<Edge> mst;
    pq.push({0,{src,-1}});
    int cost = 0;

    while(!pq.empty()){
        auto tmp = pq.top();
        int w = tmp.first;
        int u = tmp.second.first;
        int par = tmp.second.second;
        pq.pop();

        if(inMST[u]) continue;
        inMST[u] = true;
        cost += w;
        if(par != -1){
            mst.push_back(Edge(par, u, w));
        }

        for(auto& it : adj[u]){
            int weight = it.second;
            int v = it.first;
            if(!inMST[v]) pq.push({weight, {v, u}});
        }
    }
    return {mst, cost};
}


int main() {
    int N, M;
    cin >> N >> M;
    // vector<vector<pair<int, int>>> adj(N);
    vector<Edge> edges;
    edges.reserve(M);
    for(int i = 0; i < M; i++){
        int u, v, w;
        cin >> u >> v >> w;
        edges.push_back(Edge(u, v, w));
    }
    int src;
    cin >> src;
    pair<vector<Edge>, int> result;
    result = kruskalMST(N, edges);
    cout << "Kruskal: " << endl;
    cout << "Total Weight: " << result.second << endl;
    cout << "Path: " << endl;
    for(int i = 0; i < result.first.size(); i++){
        cout << result.first[i].u << " " <<  result.first[i].v << endl;
    }

    pair<vector<Edge>, int> ansfromPrim = findMST(N, edges, src);

    cout << "Prims: ";
    cout << "Cost: " << ansfromPrim.second << endl;
    cout << "Root Node: " << src << endl;
    cout << "Path: " << endl;
    for(int i = 0; i < ansfromPrim.first.size(); i++){
        cout << ansfromPrim.first[i].u << " " << ansfromPrim.first[i].v << endl;
    }

    return 0;
}