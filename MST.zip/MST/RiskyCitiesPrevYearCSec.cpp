#include<vector>
#include<iostream>
#include<algorithm>
using namespace std;

struct Edge {
    int u, v;
    long long w;
};

struct DSU {
    vector<int> parent, sz, safeCount;
    DSU(int n, vector<int>& isSafe) {
        parent.resize(n);
        sz.resize(n, 1);
        safeCount.resize(n, 0);
        for(int i = 0; i < n; i++) {
            parent[i] = i;
            safeCount[i] = isSafe[i];
        }
    }

    int find(int x) {
        if(parent[x] == x) return x;
        return parent[x] = find(parent[x]);
    }

    bool unite(int a, int b) {
        a = find(a);
        b = find(b);
        if(a == b) return false;
        if(sz[a] < sz[b]) swap(a, b);
        parent[b] = a;
        sz[a] += sz[b];
        safeCount[a] += safeCount[b];
        return true;
    }

    int safeInComponent(int x) {
        return safeCount[find(x)];
    }
};

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N, M, P;
    cin >> N >> M >> P;

    int K;
    cin >> K;

    vector<int> risky(N, 0), isSafe(N, 1);
    for(int i = 0; i < K; i++) {
        int x;
        cin >> x;
        risky[x] = 1;
        isSafe[x] = 0;
    }

    vector<Edge> edges;
    for(int i = 0; i < M; i++) {
        int u, v, w;
        cin >> u >> v >> w;
        edges.push_back({u, v, w});
    }

    // Effective weight
    vector<pair<long long, int>> sorted;
    for(int i = 0; i < M; i++) {
        long long eff = edges[i].w;
        if(risky[edges[i].u] || risky[edges[i].v]) eff += P;
        sorted.push_back({eff, i});
    }

    sort(sorted.begin(), sorted.end());

    DSU dsu(N, isSafe);

    int safeCount = 0;
    for(int i = 0; i < N; i++) safeCount += isSafe[i];

    if(safeCount <= 1) {
        cout << 0 << "\n" << 0 << "\n";
        return 0;
    }

    vector<pair<int,int>> chosenEdges;
    long long totalCost = 0;

    for(auto &it : sorted) {
        int idx = it.second;
        int u = edges[idx].u;
        int v = edges[idx].v;

        int ru = dsu.find(u);
        int rv = dsu.find(v);

        if(ru != rv) {
            dsu.unite(u, v);
            chosenEdges.push_back({u, v});
            totalCost += it.first;

            // If all safe cities are in one component, we are done
            if(dsu.safeInComponent(u) == safeCount) break;
        }
    }

    // Check if all safe cities connected
    int compSafe = 0;
    for(int i = 0; i < N; i++) {
        if(isSafe[i] && dsu.find(i) == i) compSafe++;
    }

    if(compSafe != 1) {
        cout << -1 << "\n";
        return 0;
    }

    cout << chosenEdges.size() << "\n";
    for(auto &e : chosenEdges) {
        cout << e.first << " " << e.second << "\n";
    }
    cout << totalCost << "\n";
    return 0;
}



// #include <iostream>
// #include <vector>
// #include <algorithm>

// using namespace std;

// struct Edge{
//     int u, v, w;
//     Edge(int u, int v, int w) : u(u), v(v), w(w) {}
// };

// class UnionFind{
//     vector<int> parent, size;
// public:
//     UnionFind(int n){
//         parent.resize(n);
//         size.resize(n, 1);
//         for(int i=0; i<n; i++) parent[i]=i;
//     }
//     int find(int x){
//         if(parent[x]==x) return x;
//         return parent[x]=find(parent[x]);
//     }
//     void unite(int a,int b){
//         a=find(a); b=find(b);
//         if(a==b) return;
//         if(size[a]<size[b]) swap(a,b);
//         parent[b]=a;
//         size[a]+=size[b];
//     }
// };

// bool cmp(Edge &a, Edge &b){
//     return a.w < b.w;
// }

// int kruskal(int n, vector<Edge> &edges, vector<bool> &risky, bool ignoreRisky, int P){
//     sort(edges.begin(), edges.end(), cmp);
//     UnionFind uf(n+1);

//     int total=0, edgesUsed=0;
//     int nonRiskyCount = 0;
//     for(int i=1;i<=n;i++) if(!risky[i]) nonRiskyCount++;

//     for(auto &e : edges){
//         if(ignoreRisky){
//             if(risky[e.u] || risky[e.v]) continue;  // ignore risky cities completely
//         } else {
//             if(risky[e.u] || risky[e.v]) e.w += P; // increase weight
//         }

//         int pu = uf.find(e.u);
//         int pv = uf.find(e.v);

//         if(pu!=pv){
//             uf.unite(pu,pv);
//             total += e.w;
//             edgesUsed++;
//         }
//     }

//     if(ignoreRisky){
//         if(nonRiskyCount <= 1) return 0;
//         if(edgesUsed != nonRiskyCount-1) return -1;
//     } else {
//         if(edgesUsed != n-1) return -1;
//     }
//     return total;
// }

// int main(){
//     int N, M, P;
//     cin >> N >> M >> P;

//     int K;
//     cin >> K;

//     vector<bool> risky(N+1,false);
//     for(int i=0;i<K;i++){
//         int x; cin>>x;
//         risky[x]=true;
//     }

//     vector<Edge> edges;
//     for(int i=0;i<M;i++){
//         int u,v,w;
//         cin>>u>>v>>w;
//         edges.push_back(Edge(u,v,w));
//     }

//     // 1) Try without risky cities
//     int ans = kruskal(N, edges, risky, true, P);

//     // 2) If not possible, include risky cities with penalty
//     if(ans == -1){
//         ans = kruskal(N, edges, risky, false, P);
//     }

//     cout << ans << endl;
//     return 0;
// }



// // #include <iostream>
// // #include <vector>
// // #include <algorithm>
// // #include <queue>
// // #include <stack>

// // using namespace std;
// // const int INF = 1e9;

// // struct Edge{
// //     int u, v, weight;
// //     Edge(int u, int v, int w) : u(u), v(v), weight(w){}
// // };

// // class UnionFind{
// //     vector<int> Parent;
// //     vector<int> Size;
// // public:
// //     UnionFind(int n){
// //         Parent.resize(n);
// //         for(int i = 0; i < n; i++){
// //             Parent[i] = i;
// //         }
// //         Size.resize(n, 1);
// //     }
    
// //     int find(int i){
// //         int root = Parent[i]; 

// //         if(root != Parent[root]){
// //             return Parent[i] = find(root);
// //         }
// //         return root;
// //     }   

// //     void unite(int i, int j){
// //         int irep = find(i);
// //         int jrep = find(j);

// //         if(irep == jrep) return;

// //         if(Size[irep] < Size[jrep]){
// //             Parent[irep] = jrep;
// //             Size[jrep] += Size[irep];
// //         }
// //         else{
// //             Parent[jrep] = irep;
// //             Size[irep] += Size[jrep];
// //         }
// //     }
// // };


// // bool comparator(Edge& e1, Edge& e2){
// //     return e1.weight < e2.weight;
// // }

// // pair<vector<Edge>, int> kruskalMST(int V, vector<Edge>& edges, vector<int>& skip){
// //     sort(edges.begin(), edges.end(), comparator);
// //     UnionFind uf(V+1);
// //     vector<Edge> mst;
// //     int totalWeight = 0;

// //     for(int i = 0; i < V; i++){
// //         for(int asenki : skip){
// //             if(i == asenki) continue;
// //         }
// //         Edge& e = edges[i];
// //         if(uf.find(e.u) != uf.find(e.v)){
// //             uf.unite(e.u, e.v);
// //             mst.push_back(e);
// //             totalWeight += e.weight;
// //         }
// //     }
// //     if(mst.size() != V-1){
// //         return {{}, -1};
// //     }
// //     return {mst, totalWeight};
// // }


// // pair<vector<Edge>, int> RiskykruskalMST(int V, vector<Edge>& edges, vector<int>& skip){
// //     sort(edges.begin(), edges.end(), comparator);
// //     UnionFind uf(V+1);
// //     vector<Edge> mst;
// //     int totalWeight = 0;

// //     for(int i = 0; i < V; i++){
// //         // for(int asenki : skip){
// //         //     if(i == asenki) continue;
// //         // }
// //         Edge& e = edges[i];
// //         if(uf.find(e.u) != uf.find(e.v)){
// //             uf.unite(e.u, e.v);
// //             mst.push_back(e);
// //             // totalWeight += e.weight;


// //             for(int asenki : skip){
// //                 if(i == asenki) continue;
// //             }
// //         }
// //     }
// //     if(mst.size() != V-1){
// //         return {{}, -1};
// //     }
// //     return {mst, totalWeight};
// // }


// // int main() {
// //     int N, M, P;
// //     cin >> N >> M >> P;
// //     int K;
// //     cin >> K;

// //     vector<int> riskyCityIdx(K);
// //     for(int i = 0; i < K; i++){
// //         cin >> riskyCityIdx[i];
// //     }

// //     // vector<vector<pair<int, int>>> adj(N);
// //     vector<Edge> edges;
// //     edges.reserve(M);
// //     for(int i = 0; i < M; i++){
// //         int u, v, w;
// //         cin >> u >> v >> w;
// //         edges.push_back(Edge(u, v, w));
// //     }
// //     auto firstTime = kruskalMST(N, edges, riskyCityIdx);
// //     if(firstTime.second != -1){
// //         cout << firstTime.second << endl;
// //         return 0;
// //     }
    

    

// //     return 0;
// // }