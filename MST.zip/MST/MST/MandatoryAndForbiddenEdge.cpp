#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>

using namespace std;
const int INF = 1e9;

struct Edge{
    int u, v, weight;
    Edge(int u, int v, int w) : u(u), v(v), weight(w){}
};

class UnionFind{
    vector<int> Parent;
    vector<int> Size;
public:
    UnionFind(int n){
        Parent.resize(n);
        for(int i = 0; i < n; i++){
            Parent[i] = i;
        }
        Size.resize(n, 1);
    }
    
    int find(int i){
        int root = Parent[i]; 

        if(root != Parent[root]){
            return Parent[i] = find(root);
        }
        return root;
    }   

    void unite(int i, int j){
        int irep = find(i);
        int jrep = find(j);

        if(irep == jrep) return;

        if(Size[irep] < Size[jrep]){
            Parent[irep] = jrep;
            Size[jrep] += Size[irep];
        }
        else{
            Parent[jrep] = irep;
            Size[irep] += Size[jrep];
        }
    }
};


bool comparator(Edge& e1, Edge& e2){
    return e1.weight < e2.weight;
}

pair<vector<Edge>, int> kruskalMST(int V, vector<Edge>& edges, vector<int>& mandatory, vector<int>& forbidden){
    // sort(edges.begin(), edges.end(), comparator);
    UnionFind uf(V+1);
    vector<Edge> mst;
    int totalWeight = 0;

    vector<bool> isMandatory(edges.size(), false);
    vector<bool> isForbidden(edges.size(), false);

    for(int i : mandatory) isMandatory[i] = true;
    for(int i : forbidden) isForbidden[i] = true;

    for(int i = 0; i < edges.size(); i++){
        if(!isMandatory[i]) continue;
        Edge& e = edges[i];
        if(uf.find(e.u) == uf.find(e.v)){
            return {{}, INF};
        }
        uf.unite(e.u, e.v);
        mst.push_back(e);
        totalWeight += e.weight;
        edges[i].weight = INF;
    }
    for(int i = 0; i < edges.size(); i++){
        if(isForbidden[i]){
            edges[i].weight = INF; 
        }
    }


    sort(edges.begin(), edges.end(), comparator);

    for(int i = 0; i < edges.size(); i++){
        // if(isMandatory[i] || isForbidden[i]) continue;
        Edge& e = edges[i];
        if(uf.find(e.u) != uf.find(e.v)){
            mst.push_back(e);
            uf.unite(e.u, e.v);
            totalWeight += e.weight;
        }
    }
    if(mst.size() != V-1) return {{}, INF};
    return {mst, totalWeight};
}



int main() {
    int N, M;
    cin >> N >> M;
    // vector<vector<pair<int, int>>> adj(N);
    vector<Edge> edges;
    edges.reserve(M);
    for(int i = 0; i < M; i++){
        int u, v, w;
        cin >> u >> v >> w;
        edges.push_back(Edge(u, v, w));
    }
    // sort(edges.begin(), edges.end(), comparator);

    int mandatorySize, forbiddenSize;
    cin >> mandatorySize >> forbiddenSize;
    vector<int> mandatory(mandatorySize);
    vector<int> forbidden(forbiddenSize);

    for(int i = 0; i < mandatorySize; i++){
        cin >> mandatory[i];
    }

    for(int i = 0; i < forbiddenSize; i++){
        cin >> forbidden[i];
    }

    pair<vector<Edge>, int> result;
    result = kruskalMST(N, edges, mandatory, forbidden);

    if(result.second==INF) cout << "Impossible" << endl;
    else cout << result.second << endl;

    return 0;
}