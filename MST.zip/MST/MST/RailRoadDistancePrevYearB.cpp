#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>
#include<cmath>

using namespace std;
const int INF = 1e9;

struct Edge{
    int u, v;
    double weight;
    Edge(int u, int v, int w) : u(u), v(v), weight(w){}
};

class UnionFind{
    vector<int> Parent;
    vector<int> Size;
public:
    UnionFind(int n){
        Parent.resize(n);
        for(int i = 0; i < n; i++){
            Parent[i] = i;
        }
        Size.resize(n, 1);
    }
    
    int find(int i){
        int root = Parent[i]; 

        if(root != Parent[root]){
            return Parent[i] = find(root);
        }
        return root;
    }   

    void unite(int i, int j){
        int irep = find(i);
        int jrep = find(j);

        if(irep == jrep) return;

        if(Size[irep] < Size[jrep]){
            Parent[irep] = jrep;
            Size[jrep] += Size[irep];
        }
        else{
            Parent[jrep] = irep;
            Size[irep] += Size[jrep];
        }
    }
};


bool comparator(Edge& e1, Edge& e2){
    return e1.weight < e2.weight;
}

pair<pair<int, int>, int> kruskalMST(int V, vector<Edge>& edges, double r){
    sort(edges.begin(), edges.end(), comparator);
    double railLine = 0;
    double roadLine = 0;
    UnionFind uf(V+1);
    vector<Edge> mst;
    int totalWeight = 0;
    int railLineNumber = 0;

    for(Edge& e : edges){
        if(uf.find(e.u) != uf.find(e.v)){
            uf.unite(e.u, e.v);

            if(e.weight <= r){
                roadLine += e.weight;
            }
            else{
                railLine += e.weight;
                railLineNumber += 1;
            }

            mst.push_back(e);
            totalWeight += e.weight;
        }
    }
    return {{roadLine, railLine}, railLineNumber};
}


int main() {
    int n;
    double r;
    cin >> n >> r;
    vector<pair<int, int>> coordinates(n+1);
    for(int i = 1; i <= n; i++){
        int x, y;
        cin >> x >> y;
        coordinates[i].first = x;
        coordinates[i].second = y;
    }

    vector<Edge> edges;
    for(int i = 1; i <= n; i++){
        for(int j = i+1; j <= n; j++){
            int dx = coordinates[i].first - coordinates[j].first;
            int dy = coordinates[i].second - coordinates[j].second;
            double dist = sqrt(dx*dx+dy*dy);
            edges.push_back(Edge(i, j, dist));
        }
    }
    sort(edges.begin(), edges.end(), comparator);
    auto ans = kruskalMST(n, edges, r);

    cout << ans.second+1 << " " << ans.first.first << " " << ans.first.second << endl;




    return 0;
}