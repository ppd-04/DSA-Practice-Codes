#include<bits/stdc++.h>
using namespace std;

struct Edge{
    int u, v, weight;
    Edge(int u, int v, int w) : u(u), v(v), weight(w){}
};

int main(){
    int n, m, q;
    cin >> n >> m >> q;
    vector<vector<pair<int, int>>> adj(n+1);
    vector<Edge> e;

    for(int i = 0; i < m; i++){
        int u, v, c;
        cin >> u >> v >> c;
        adj[u].push_back({v, c});
        adj[v].push_back({u, c});
        e.push_back(Edge(u, v, c));    
    }
    
}