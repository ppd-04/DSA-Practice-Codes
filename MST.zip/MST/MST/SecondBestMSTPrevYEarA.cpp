#include <iostream>
#include <vector>
#include <algorithm>
#include <climits>

using namespace std;

const int INF = INT_MAX;

struct Edge {
    int u, v, weight;
    Edge(int u, int v, int w) : u(u), v(v), weight(w) {}
};

class UnionFind {
    vector<int> Parent, Size;
public:
    UnionFind(int n) {
        Parent.resize(n);
        Size.resize(n, 1);
        for (int i = 0; i < n; i++) Parent[i] = i;
    }

    int find(int i) {
        if (Parent[i] == i) return i;
        return Parent[i] = find(Parent[i]);
    }

    void unite(int i, int j) {
        int a = find(i);
        int b = find(j);
        if (a == b) return;

        if (Size[a] < Size[b]) {
            Parent[a] = b;
            Size[b] += Size[a];
        } else {
            Parent[b] = a;
            Size[a] += Size[b];
        }
    }
};

bool comparator(const Edge& a, const Edge& b) {
    return a.weight < b.weight;
}



pair<vector<int>, int> kruskalMST(int V, vector<Edge>& edges, int forcedEdge){
    // sort(edges.begin(), edges.end(), comparator);
    vector<int> mst;
    int totalProduct = 1;
    UnionFind uf(V+1);
    
    if(forcedEdge != -1){
        Edge& dhukanoEdge = edges[forcedEdge];
        uf.unite(dhukanoEdge.u, dhukanoEdge.v);
        totalProduct *= dhukanoEdge.weight;
        mst.push_back(forcedEdge);
    }

    for(int i = 0; i < edges.size(); i++){
        if(i == forcedEdge) continue;
        Edge& e = edges[i];
        if(uf.find(e.u) != uf.find(e.v)){
            uf.unite(e.u, e.v);
            totalProduct *= e.weight;
            mst.push_back(i);
        }

    }

    if(mst.size() != V-1){
        return {{}, -1};
    }
    return {mst, totalProduct};
}



int main() {
    int N, M;
    cin >> N >> M;
    // vector<vector<pair<int, int>>> adj(N);
    vector<Edge> edges;
    edges.reserve(M);
    for(int i = 0; i < M; i++){
        int u, v, w;
        cin >> u >> v >> w;
        edges.push_back(Edge(u, v, w));
    }
    sort(edges.begin(), edges.end(), comparator);
    auto originalAns = kruskalMST(N, edges, -1);
    int originalWeight = originalAns.second;
    vector<int> originalMST = originalAns.first;
    int besTAns = INF;

    for(int i = 0; i < M; i++){
        bool inMST = false;
        for(int idx : originalMST){
            if(idx == i) inMST = true;
        }
        if(inMST) continue;
        auto candidate = kruskalMST(N, edges, i);
        if(candidate.second != -1 && candidate.second > originalWeight){
            besTAns = min(besTAns, candidate.second);
        }
    }
    if(besTAns == INF) cout << -1 << endl;
    else cout << besTAns << endl;
    // cout << besTAns << endl;





    return 0;
}

// pair<vector<int>, int> kruskalMST(
//     int V,
//     vector<Edge>& edges,
//     int skippedEdge,
//     int forcedEdge
// ) {
//     UnionFind uf(V + 1);
//     vector<int> mstEdges;
//     int product = 1;

//     // FORCE ONE EDGE (new)
//     if (forcedEdge != -1) {
//         Edge &e = edges[forcedEdge];
//         uf.unite(e.u, e.v);
//         mstEdges.push_back(forcedEdge);
//         product *= e.weight;
//     }

//     for (int i = 0; i < edges.size(); i++) {
//         if (i == skippedEdge || i == forcedEdge) continue;

//         Edge &e = edges[i];
//         if (uf.find(e.u) != uf.find(e.v)) {
//             uf.unite(e.u, e.v);
//             mstEdges.push_back(i);
//             product *= e.weight;
//         }
//     }

//     if (mstEdges.size() != V - 1)
//         return {{}, -1};

//     return {mstEdges, product};
// }

// int main() {
//     int N, M;
//     cin >> N >> M;

//     vector<Edge> edges;
//     for (int i = 0; i < M; i++) {
//         int u, v, w;
//         cin >> u >> v >> w;
//         edges.push_back(Edge(u, v, w));
//     }

//     sort(edges.begin(), edges.end(), comparator);

//     // Primary MST (minimum product)
//     auto best = kruskalMST(N, edges, -1, -1);
//     int bestProduct = best.second;
//     vector<int> bestEdges = best.first;

//     int secondBest = INF;

//     // Try forcing every NON-MST edge
//     for (int i = 0; i < M; i++) {

//         bool inMST = false;
//         for (int idx : bestEdges)
//             if (idx == i) inMST = true;

//         if (inMST) continue;

//         auto candidate = kruskalMST(N, edges, -1, i);

//         if (candidate.second != -1 && candidate.second > bestProduct) {
//             secondBest = min(secondBest, candidate.second);
//         }
//     }

//     if (secondBest == INF)
//         cout << -1 << endl;
//     else
//         cout << secondBest << endl;

//     return 0;
// }
