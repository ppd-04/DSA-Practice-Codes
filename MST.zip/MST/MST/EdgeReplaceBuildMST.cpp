#include <bits/stdc++.h>
using namespace std;

const int MAXN = 200005;
const int LOG = 20;

struct Edge {
    int u, v, w;
};

vector<pair<int,int>> treeAdj[MAXN];
int up[MAXN][LOG];
int maxUp[MAXN][LOG];
int depthArr[MAXN];

void dfs(int node, int parent, int w) {
    up[node][0] = parent;
    maxUp[node][0] = w;
    for(auto &edge : treeAdj[node]) {
        int nxt = edge.first;
        int wt  = edge.second;
        if(nxt == parent) continue;
        depthArr[nxt] = depthArr[node] + 1;
        dfs(nxt, node, wt);
    }
}

int maxEdgeOnPath(int u, int v) {
    if(depthArr[u] < depthArr[v]) swap(u, v);

    int diff = depthArr[u] - depthArr[v];
    int maxEdge = 0;

    for(int i = LOG - 1; i >= 0; i--) {
        if(diff & (1 << i)) {
            maxEdge = max(maxEdge, maxUp[u][i]);
            u = up[u][i];
        }
    }

    if(u == v) return maxEdge;

    for(int i = LOG - 1; i >= 0; i--) {
        if(up[u][i] != up[v][i]) {
            maxEdge = max(maxEdge, maxUp[u][i]);
            maxEdge = max(maxEdge, maxUp[v][i]);
            u = up[u][i];
            v = up[v][i];
        }
    }

    maxEdge = max(maxEdge, maxUp[u][0]);
    maxEdge = max(maxEdge, maxUp[v][0]);
    return maxEdge;
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N, M;
    cin >> N >> M;

    vector<Edge> allEdges(M);
    for(int i = 0; i < M; i++){
        cin >> allEdges[i].u >> allEdges[i].v >> allEdges[i].w;
    }

    // Read the tree edges (N-1 edges)
    long long treeCost = 0;
    vector<bool> isTreeEdge(M, false);

    for(int i = 0; i < N-1; i++){
        int idx;
        cin >> idx;  // index of edge in allEdges
        isTreeEdge[idx] = true;
        treeCost += allEdges[idx].w;

        int u = allEdges[idx].u;
        int v = allEdges[idx].v;
        int w = allEdges[idx].w;
        treeAdj[u].push_back({v, w});
        treeAdj[v].push_back({u, w});
    }

    // preprocess LCA
    depthArr[1] = 0;
    dfs(1, 1, 0);

    for(int j = 1; j < LOG; j++){
        for(int i = 1; i <= N; i++){
            up[i][j] = up[ up[i][j-1] ][j-1];
            maxUp[i][j] = max(maxUp[i][j-1], maxUp[ up[i][j-1] ][j-1]);
        }
    }

    long long bestCost = treeCost;

    // Try replacing each non-tree edge
    for(int i = 0; i < M; i++){
        if(isTreeEdge[i]) continue;

        int u = allEdges[i].u;
        int v = allEdges[i].v;
        int w = allEdges[i].w;

        int mx = maxEdgeOnPath(u, v);
        long long candidate = treeCost + w - mx;
        bestCost = min(bestCost, candidate);
    }

    cout << bestCost << "\n";
    return 0;
}
