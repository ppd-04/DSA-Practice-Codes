#include <bits/stdc++.h>
using namespace std;

struct Edge {
    int u, v, w;
    int idx;
};

struct DSU {
    vector<int> p, sz;
    DSU(int n) : p(n+1), sz(n+1,1) {
        iota(p.begin(), p.end(), 0);
    }
    int find(int x) {
        if(p[x]==x) return x;
        return p[x]=find(p[x]);
    }
    bool unite(int a,int b){
        a=find(a); b=find(b);
        if(a==b) return false;
        if(sz[a]<sz[b]) swap(a,b);
        p[b]=a;
        sz[a]+=sz[b];
        return true;
    }
};

struct State {
    long long cost;
    vector<int> includeEdges;
    vector<int> excludeEdges;
    bool operator>(const State& other) const {
        return cost > other.cost;
    }
};

pair<long long, vector<int>> kruskal(int N, vector<Edge>& edges,
                                    vector<int>& include, vector<int>& exclude)
{
    DSU dsu(N);
    long long cost = 0;
    vector<int> mst;

    // force include edges
    for(int id : include){
        Edge &e = edges[id];
        if(!dsu.unite(e.u, e.v)) return {-1, {}};
        cost += e.w;
        mst.push_back(id);
    }

    // skip excluded edges
    vector<bool> forbidden(edges.size(), false);
    for(int id : exclude) forbidden[id] = true;

    sort(edges.begin(), edges.end(), [](Edge &a, Edge &b){
        return a.w < b.w;
    });

    for(int i=0; i<edges.size(); i++){
        if(forbidden[edges[i].idx]) continue;
        if(dsu.unite(edges[i].u, edges[i].v)){
            cost += edges[i].w;
            mst.push_back(edges[i].idx);
        }
    }

    if(mst.size()!=N-1) return {-1, {}};
    return {cost, mst};
}

int main(){
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N,M;
    cin>>N>>M;
    vector<Edge> edges;
    edges.reserve(M);

    for(int i=0;i<M;i++){
        int u,v,w;
        cin>>u>>v>>w;
        edges.push_back({u,v,w,i});
    }

    int K;
    cin>>K;

    // initial MST
    vector<int> inc, exc;
    auto base = kruskal(N, edges, inc, exc);
    if(base.first == -1){
        cout << "Impossible\n";
        return 0;
    }

    priority_queue<State, vector<State>, greater<State>> pq;
    pq.push({base.first, {}, {}});

    int count=0;
    long long ans=-1;

    while(!pq.empty()){
        auto cur = pq.top(); pq.pop();
        count++;
        if(count==K){
            ans=cur.cost;
            break;
        }

        // expand
        auto res = kruskal(N, edges, cur.includeEdges, cur.excludeEdges);
        auto mst = res.second;

        for(int e : mst){
            auto inc2 = cur.includeEdges;
            auto exc2 = cur.excludeEdges;

            // split into two
            exc2.push_back(e);
            pq.push({-1, inc2, exc2}); // cost will be recomputed in kruskal later
        }
    }

    if(ans==-1) cout << "Impossible\n";
    else cout << ans << "\n";

    return 0;
}
