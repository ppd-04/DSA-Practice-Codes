#include <bits/stdc++.h>
//#include <boost/multiprecision/cpp_int.hpp>

using namespace std;
//using boost::multiprecision::cpp_int;

struct Edge {
    int u, v;
    int w;
    int id;
    bool inMST = false;
};

struct DSU {
    vector<int> p, r;
    DSU(int n = 0) { init(n); }
    void init(int n) {
        p.resize(n + 1);
        r.assign(n + 1, 0);
        iota(p.begin(), p.end(), 0);
    }
    int find(int x) {
        if (p[x] == x)
            return x;
        return p[x] = find(p[x]);
    }
    bool unite(int a, int b) {
        a = find(a), b = find(b);
        if (a == b)
            return false;
        if (r[a] < r[b])
            swap(a, b);
        p[b] = a;
        if (r[a] == r[b])
            r[a]++;
        return true;
    }
};

// DFS to find max edge weight on path u -> target in MST
bool dfsMaxEdge(int u, int par, int target,
                vector<vector<pair<int, int>>> &tree, int &maxW) {
    if (u == target)
        return true;

    for (auto [v, w] : tree[u]) {
        if (v == par)
            continue;
        int before = maxW;
        maxW = max(maxW, w);
        if (dfsMaxEdge(v, u, target, tree, maxW))
            return true;
        maxW = before; // backtrack if not found
    }
    return false;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int N, M;
    cin >> N >> M;

    vector<Edge> edges(M);
    for (int i = 0; i < M; i++) {
        cin >> edges[i].u >> edges[i].v >> edges[i].w;
        edges[i].id = i;
    }

    // 1) Build MST using Kruskal (works for min-product too)
    vector<int> idx(M);
    iota(idx.begin(), idx.end(), 0);
    sort(idx.begin(), idx.end(),
         [&](int a, int b) { return edges[a].w < edges[b].w; });

    DSU dsu(N);
    //cpp_int mstProduct = 1;
    int mstProduct = 1;
    int taken = 0;

    vector<vector<pair<int, int>>> tree(N + 1); // adjacency: (to, weight)

    for (int id : idx) {
        auto &e = edges[id];
        if (dsu.unite(e.u, e.v)) {
            e.inMST = true;
            taken++;
            mstProduct *= e.w;

            tree[e.u].push_back({e.v, e.w});
            tree[e.v].push_back({e.u, e.w});
        }
    }

    // If MST doesn't exist (graph disconnected)
    if (taken != N - 1) {
        cout << -1 << "\n";
        return 0;
    }

    // 2) Try all non-MST edges to generate second best
    bool found = false;
    //cpp_int best2;
    int best2;

    for (auto &e : edges) {
        if (e.inMST)
            continue;

        int maxW = 0;
        dfsMaxEdge(e.u, -1, e.v, tree, maxW);

        // candidate product = MST / maxW * e.w
        //cpp_int cand = mstProduct / maxW;
        int cand = mstProduct / maxW;
        cand *= e.w;

        if (cand > mstProduct) {
            if (!found || cand < best2) {
                best2 = cand;
                found = true;
            }
        }
    }

    if (!found)
        cout << -1 << "\n";
    else
        cout << best2 << "\n";

    return 0;
}