#include <bits/stdc++.h>
using namespace std;

struct DSU {
    vector<int> parent, rnk;
    DSU(int n = 0) { init(n); }
    void init(int n) {
        parent.resize(n);
        rnk.assign(n, 0);
        iota(parent.begin(), parent.end(), 0);
    }
    int find(int x) {
        if (parent[x] == x)
            return x;
        return parent[x] = find(parent[x]);
    }
    bool unite(int a, int b) {
        a = find(a), b = find(b);
        if (a == b)
            return false;
        if (rnk[a] < rnk[b])
            swap(a, b);
        parent[b] = a;
        if (rnk[a] == rnk[b])
            rnk[a]++;
        return true;
    }
};

struct Edge {
    int u, v;
    double w;
    bool operator<(Edge const &other) const { return w < other.w; }
};

static inline double dist(int x1, int y1, int x2, int y2) {
    long long dx = x1 - x2;
    long long dy = y1 - y2;
    return sqrt((double)dx * dx + (double)dy * dy);
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    int n;
    double r;
    cin >> n >> r;

    vector<int> x(n), y(n);
    for (int i = 0; i < n; i++) {
        cin >> x[i] >> y[i];
    }

    // Build all edges (complete graph)
    vector<Edge> edges;
    edges.reserve(n * (n - 1) / 2);

    for (int i = 0; i < n; i++) {
        for (int j = i + 1; j < n; j++) {
            edges.push_back({i, j, dist(x[i], y[i], x[j], y[j])});
        }
    }

    sort(edges.begin(), edges.end());

    DSU dsu(n);

    double roadSum = 0.0, railSum = 0.0;
    int railEdges = 0;
    int taken = 0;

    // Kruskal MST
    for (auto &e : edges) {
        if (dsu.unite(e.u, e.v)) {
            taken++;
            if (e.w <= r) {
                roadSum += e.w;
            } else {
                railSum += e.w;
                railEdges++;
            }
            if (taken == n - 1)
                break;
        }
    }

    int states = railEdges + 1;

    // Round to nearest integer
    long long roadOut = llround(roadSum);
    long long railOut = llround(railSum);

    cout << states << " " << roadOut << " " << railOut << "\n";
    return 0;
}