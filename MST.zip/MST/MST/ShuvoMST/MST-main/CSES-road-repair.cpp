#include <algorithm>
#include <iostream>
#include <numeric>
#include <vector>

using namespace std;

// --- DSU Structure for Kruskal's Algorithm ---
struct DSU {
    vector<int> parent;
    vector<int> size;

    DSU(int n) {
        parent.resize(n + 1);
        iota(parent.begin(), parent.end(), 0); // Fill with 0, 1, 2...
        size.assign(n + 1, 1);
    }

    int find(int i) {
        if (parent[i] == i)
            return i;
        return parent[i] = find(parent[i]); // Path compression
    }

    bool unite(int i, int j) {
        int root_i = find(i);
        int root_j = find(j);

        if (root_i != root_j) {
            // Union by size: attach smaller tree to larger tree
            if (size[root_i] < size[root_j])
                swap(root_i, root_j);
            parent[root_j] = root_i;
            size[root_i] += size[root_j];
            return true;
        }
        return false;
    }
};

// --- Edge Structure ---
struct Edge {
    int u, v, weight;
    bool operator<(const Edge &other) const { return weight < other.weight; }
};

void solve() {
    int n, m; // n = cities, m = roads
    if (!(cin >> n >> m))
        return;

    vector<Edge> edges;
    for (int i = 0; i < m; i++) {
        int u, v, w;
        cin >> u >> v >> w;
        edges.push_back({u, v, w});
    }

    // Step 1: Sort edges by weight
    sort(edges.begin(), edges.end());

    // Step 2: Initialize DSU
    DSU dsu(n);
    long long total_cost = 0;
    int edges_count = 0;

    // Step 3: Kruskal's Loop
    for (const auto &edge : edges) {
        if (dsu.unite(edge.u, edge.v)) {
            total_cost += edge.weight;
            edges_count++;
        }
    }

    // Step 4: Verification (CSES specific)
    // A spanning tree for N nodes must have exactly N-1 edges
    if (edges_count == n - 1) {
        cout << total_cost << endl;
    } else {
        // Special case: Single node graph is technically connected with 0 edges
        if (n == 1)
            cout << 0 << endl;
        else
            cout << "IMPOSSIBLE" << endl;
    }
}

int main() {
    ios_base::sync_with_stdio(false);
    cin.tie(NULL);
    solve();
    return 0;
}