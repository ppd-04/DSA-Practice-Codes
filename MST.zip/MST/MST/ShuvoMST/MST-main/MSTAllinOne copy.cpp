/*******************************************************
 * mst_lab.cpp
 * Complete MST Lab Toolkit (C++17)
 *
 * Build:
 *   g++ -std=c++17 -O2 -pipe -static -s mst_lab.cpp -o mst_lab
 *
 * Notes:
 * - Node indexing: 1..N for graph problems.
 * - Coordinate MST uses points indexed 0..N-1 internally.
 * - Second Best MST uses LCA on MST (assumes connected).
 *******************************************************/

#include <bits/stdc++.h>
using namespace std;

using ll = long long;

/*********************** DSU ****************************/
struct DSU {
    vector<int> p, r;
    DSU(int n = 0) { init(n); }
    void init(int n) {
        p.resize(n + 1);
        r.assign(n + 1, 0);
        iota(p.begin(), p.end(), 0);
    }
    int find(int x) {
        if (p[x] == x)
            return x;
        return p[x] = find(p[x]);
    }
    bool unite(int a, int b) {
        a = find(a);
        b = find(b);
        if (a == b)
            return false;
        if (r[a] < r[b])
            swap(a, b);
        p[b] = a;
        if (r[a] == r[b])
            r[a]++;
        return true;
    }
};

/*********************** EDGE ***************************/
struct Edge {
    int u, v;
    ll w;
};

/******************** Input Helpers *********************/
static inline pair<int, int> normPair(int a, int b) {
    if (a > b)
        swap(a, b);
    return {a, b};
}

vector<Edge> readEdges(int m) {
    vector<Edge> edges(m);
    for (int i = 0; i < m; i++) {
        cin >> edges[i].u >> edges[i].v >> edges[i].w;
    }
    return edges;
}

vector<vector<pair<int, ll>>> buildAdj(int n, vector<Edge> &edges) {
    vector<vector<pair<int, ll>>> g(n + 1);
    for (auto &e : edges) {
        g[e.u].push_back({e.v, e.w});
        g[e.v].push_back({e.u, e.w});
    }
    return g;
}

/******************** Kruskal MST ***********************/
ll kruskalMST_total(int n, vector<Edge> edges) {
    sort(edges.begin(), edges.end(),
         [](const Edge &a, const Edge &b) { return a.w < b.w; });
    DSU dsu(n);
    ll cost = 0;
    int taken = 0;
    for (auto &e : edges) {
        if (dsu.unite(e.u, e.v)) {
            cost += e.w;
            taken++;
        }
    }
    if (taken != n - 1)
        return -1; // disconnected
    return cost;
}

pair<ll, vector<pair<int, int>>> kruskalMST_edges(int n, vector<Edge> edges) {
    sort(edges.begin(), edges.end(),
         [](const Edge &a, const Edge &b) { return a.w < b.w; });
    DSU dsu(n);
    ll cost = 0;
    vector<pair<int, int>> chosen;
    for (auto &e : edges) {
        if (dsu.unite(e.u, e.v)) {
            cost += e.w;
            chosen.push_back({e.u, e.v});
        }
    }
    if ((int)chosen.size() != n - 1)
        return {-1, {}};
    return {cost, chosen};
}

/******************** Prim Rooted ***********************/
pair<ll, vector<pair<int, int>>>
primRooted(int n, vector<vector<pair<int, ll>>> &g, int root) {

    const ll INF = (1LL << 62);
    vector<ll> key(n + 1, INF);
    vector<int> parent(n + 1, -1);
    vector<char> used(n + 1, 0);

    priority_queue<pair<ll, int>, vector<pair<ll, int>>, greater<pair<ll, int>>>
        pq;
    key[root] = 0;
    pq.push({0, root});

    ll cost = 0;
    while (!pq.empty()) {
        auto [w, u] = pq.top();
        pq.pop();
        if (used[u])
            continue;
        used[u] = 1;
        cost += w;
        for (auto [v, wt] : g[u]) {
            if (!used[v] && wt < key[v]) {
                key[v] = wt;
                parent[v] = u;
                pq.push({key[v], v});
            }
        }
    }

    for (int i = 1; i <= n; i++) {
        if (!used[i])
            return {-1, {}};
    }

    vector<pair<int, int>> edges;
    for (int v = 1; v <= n; v++) {
        if (v == root)
            continue;
        edges.push_back({parent[v], v});
    }
    return {cost, edges};
}

/***************** Minimum Spanning Forest **************/
pair<ll, vector<vector<pair<int, int>>>> kruskalForest(int n,
                                                       vector<Edge> edges) {
    sort(edges.begin(), edges.end(),
         [](const Edge &a, const Edge &b) { return a.w < b.w; });
    DSU dsu(n);
    ll cost = 0;
    vector<pair<int, int>> chosen;
    for (auto &e : edges) {
        if (dsu.unite(e.u, e.v)) {
            cost += e.w;
            chosen.push_back({e.u, e.v});
        }
    }

    // group chosen edges by component representative
    unordered_map<int, vector<pair<int, int>>> compEdges;
    for (auto &p : chosen) {
        int c = dsu.find(p.first);
        compEdges[c].push_back(p);
    }
    vector<vector<pair<int, int>>> forest;
    for (auto &kv : compEdges)
        forest.push_back(kv.second);

    return {cost, forest};
}

/*********************** Connected? *********************/
bool mstExists(int n, vector<Edge> edges) {
    DSU dsu(n);
    for (auto &e : edges)
        dsu.unite(e.u, e.v);
    int root = dsu.find(1);
    for (int i = 2; i <= n; i++) {
        if (dsu.find(i) != root)
            return false;
    }
    return true;
}

/******************* Maximum Spanning Tree **************/
ll kruskalMaxST_total(int n, vector<Edge> edges) {
    sort(edges.begin(), edges.end(),
         [](const Edge &a, const Edge &b) { return a.w > b.w; });
    DSU dsu(n);
    ll cost = 0;
    int taken = 0;
    for (auto &e : edges) {
        if (dsu.unite(e.u, e.v)) {
            cost += e.w;
            taken++;
        }
    }
    if (taken != n - 1)
        return -1;
    return cost;
}

/********************* LCA for 2nd MST ******************/
struct LCA {
    int n, LOG;
    vector<int> depth;
    vector<vector<int>> up;
    vector<vector<ll>> mx;
    vector<vector<pair<int, ll>>> tree;

    LCA(int n = 0) { init(n); }

    void init(int N) {
        n = N;
        LOG = 20;
        depth.assign(n + 1, 0);
        up.assign(LOG, vector<int>(n + 1, 0));
        mx.assign(LOG, vector<ll>(n + 1, 0));
        tree.assign(n + 1, {});
    }

    void addEdge(int u, int v, ll w) {
        tree[u].push_back({v, w});
        tree[v].push_back({u, w});
    }

    void dfs(int u, int p, ll w) {
        up[0][u] = p;
        mx[0][u] = w;
        for (auto [v, wt] : tree[u]) {
            if (v == p)
                continue;
            depth[v] = depth[u] + 1;
            dfs(v, u, wt);
        }
    }

    void build(int root = 1) {
        depth[root] = 0;
        dfs(root, 0, 0);
        for (int k = 1; k < LOG; k++) {
            for (int v = 1; v <= n; v++) {
                int mid = up[k - 1][v];
                up[k][v] = up[k - 1][mid];
                mx[k][v] = max(mx[k - 1][v], mx[k - 1][mid]);
            }
        }
    }

    ll maxOnPath(int a, int b) {
        ll res = 0;
        if (depth[a] < depth[b])
            swap(a, b);
        int diff = depth[a] - depth[b];
        for (int k = LOG - 1; k >= 0; k--) {
            if (diff & (1 << k)) {
                res = max(res, mx[k][a]);
                a = up[k][a];
            }
        }
        if (a == b)
            return res;
        for (int k = LOG - 1; k >= 0; k--) {
            if (up[k][a] != up[k][b]) {
                res = max(res, mx[k][a]);
                res = max(res, mx[k][b]);
                a = up[k][a];
                b = up[k][b];
            }
        }
        res = max(res, mx[0][a]);
        res = max(res, mx[0][b]);
        return res;
    }
};

pair<ll, ll> secondBestMST(int n, vector<Edge> edges) {
    int m = (int)edges.size();
    vector<int> idx(m);
    iota(idx.begin(), idx.end(), 0);

    sort(idx.begin(), idx.end(),
         [&](int i, int j) { return edges[i].w < edges[j].w; });

    DSU dsu(n);
    vector<char> inMST(m, 0);
    ll mst = 0;
    int taken = 0;

    LCA lca(n);

    for (int id : idx) {
        auto &e = edges[id];
        if (dsu.unite(e.u, e.v)) {
            inMST[id] = 1;
            mst += e.w;
            taken++;
            lca.addEdge(e.u, e.v, e.w);
        }
    }
    if (taken != n - 1)
        return {-1, -1}; // disconnected

    lca.build(1);

    ll second = (1LL << 62);
    for (int i = 0; i < m; i++) {
        if (inMST[i])
            continue;
        auto &e = edges[i];
        ll mx = lca.maxOnPath(e.u, e.v);
        ll cand = mst + e.w - mx;
        if (cand > mst)
            second = min(second, cand);
    }
    if (second == (1LL << 62))
        second = -1;
    return {mst, second};
}

/******************** Forced Edge MST *******************/
pair<ll, vector<pair<int, int>>> mstForcedEdges(int n, vector<Edge> edges,
                                                vector<pair<int, int>> forced) {

    // Map min(u,v),max(u,v) -> min weight among parallel edges
    unordered_map<long long, ll> bestW;
    bestW.reserve(edges.size() * 2);

    auto key = [&](int a, int b) -> long long {
        auto [x, y] = normPair(a, b);
        return ((long long)x << 32) ^ (unsigned long long)y;
    };

    for (auto &e : edges) {
        long long k = key(e.u, e.v);
        if (!bestW.count(k))
            bestW[k] = e.w;
        else
            bestW[k] = min(bestW[k], e.w);
    }

    DSU dsu(n);
    ll cost = 0;
    vector<pair<int, int>> chosen;

    for (auto [a, b] : forced) {
        long long k = key(a, b);
        if (!bestW.count(k))
            return {-1, {}};
        if (!dsu.unite(a, b))
            return {-1, {}};
        cost += bestW[k];
        chosen.push_back({a, b});
    }

    sort(edges.begin(), edges.end(),
         [](const Edge &a, const Edge &b) { return a.w < b.w; });

    for (auto &e : edges) {
        if (dsu.unite(e.u, e.v)) {
            cost += e.w;
            chosen.push_back({e.u, e.v});
        }
    }

    if ((int)chosen.size() != n - 1)
        return {-1, {}};
    return {cost, chosen};
}

/******************** Banned Edge MST *******************/
ll mstWithBannedEdges(int n, vector<Edge> edges, set<pair<int, int>> banned) {
    vector<Edge> filtered;
    for (auto &e : edges) {
        auto a = min(e.u, e.v), b = max(e.u, e.v);
        if (!banned.count({a, b}))
            filtered.push_back(e);
    }
    return kruskalMST_total(n, filtered);
}

/************** Degree Constraint on node X **************
 * Greedy heuristic (not guaranteed optimal in general).
 *********************************************************/
ll mstDegreeLimitX_greedy(int n, vector<Edge> edges, int X, int D) {
    sort(edges.begin(), edges.end(),
         [](const Edge &a, const Edge &b) { return a.w < b.w; });

    DSU dsu(n);
    vector<int> deg(n + 1, 0);
    ll cost = 0;
    int taken = 0;

    for (auto &e : edges) {
        if (dsu.find(e.u) == dsu.find(e.v))
            continue;

        if (e.u == X && deg[X] >= D)
            continue;
        if (e.v == X && deg[X] >= D)
            continue;

        dsu.unite(e.u, e.v);
        cost += e.w;
        deg[e.u]++;
        deg[e.v]++;
        taken++;
    }

    if (taken != n - 1)
        return -1;
    return cost;
}

/**************** Edge-add Query new MST ****************/
struct MSTForQueries {
    ll mstCost;
    LCA lca;
};

optional<MSTForQueries> buildMSTForQueries(int n, vector<Edge> edges) {
    // build MST + LCA
    int m = edges.size();
    vector<int> idx(m);
    iota(idx.begin(), idx.end(), 0);
    sort(idx.begin(), idx.end(),
         [&](int i, int j) { return edges[i].w < edges[j].w; });

    DSU dsu(n);
    ll mst = 0;
    int taken = 0;

    LCA lca(n);

    for (int id : idx) {
        auto &e = edges[id];
        if (dsu.unite(e.u, e.v)) {
            mst += e.w;
            taken++;
            lca.addEdge(e.u, e.v, e.w);
        }
    }
    if (taken != n - 1)
        return nullopt;
    lca.build(1);
    return MSTForQueries{mst, lca};
}

ll newMST_ifAddEdge(ll mstCost, LCA &lca, int u, int v, ll w) {
    ll mx = lca.maxOnPath(u, v);
    return mstCost + w - mx;
}

/******************* Coordinate MST *********************/
struct Point {
    double x, y;
};

double distP(Point a, Point b) {
    double dx = a.x - b.x, dy = a.y - b.y;
    return sqrt(dx * dx + dy * dy);
}

// O(N^2) Prim on complete graph
double primPoints(vector<Point> &p) {
    int n = p.size();
    vector<double> key(n, 1e100);
    vector<char> used(n, 0);
    key[0] = 0;
    double total = 0;

    for (int i = 0; i < n; i++) {
        int u = -1;
        for (int j = 0; j < n; j++) {
            if (!used[j] && (u == -1 || key[j] < key[u]))
                u = j;
        }
        used[u] = 1;
        total += key[u];
        for (int v = 0; v < n; v++) {
            if (!used[v]) {
                key[v] = min(key[v], distP(p[u], p[v]));
            }
        }
    }
    return total;
}

/******************** Printing helpers ******************/
void printEdgesList(vector<pair<int, int>> &edges) {
    for (auto &e : edges) {
        cout << e.first << " " << e.second << "\n";
    }
}

/*********************** MENU ***************************/
void showMenu() {
    cout << "\n========= MST LAB TOOLKIT =========\n";
    cout << "1) Kruskal MST (total weight)\n";
    cout << "2) Kruskal MST (weight + edge list)\n";
    cout << "3) Prim Rooted MST (weight + edge list)\n";
    cout << "4) Minimum Spanning Forest (disconnected allowed)\n";
    cout << "5) Check if MST exists (graph connected?)\n";
    cout << "6) Maximum Spanning Tree (total weight)\n";
    cout << "7) Second Best MST (best + second best)\n";
    cout << "8) MST with Forced edges\n";
    cout << "9) MST with Banned edges\n";
    cout << "10) MST with degree constraint on node X (greedy)\n";
    cout << "11) MST add-edge queries (new MST after adding each edge)\n";
    cout << "12) Coordinate MST (2D points)\n";
    cout << "0) Exit\n";
    cout << "===================================\n";
    cout << "Choose option: ";
}

/*********************** MAIN ***************************/
int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    while (true) {
        showMenu();
        int op;
        if (!(cin >> op))
            return 0;
        if (op == 0)
            break;

        if (op >= 1 && op <= 11) {
            int n, m;
            cout << "Enter N M:\n";
            cin >> n >> m;
            cout << "Enter edges: u v w (" << m << " lines)\n";
            vector<Edge> edges = readEdges(m);

            if (op == 1) {
                ll ans = kruskalMST_total(n, edges);
                if (ans == -1)
                    cout << "IMPOSSIBLE (Disconnected)\n";
                else
                    cout << "MST total weight = " << ans << "\n";
            }

            else if (op == 2) {
                auto [cost, mstEdges] = kruskalMST_edges(n, edges);
                if (cost == -1)
                    cout << "IMPOSSIBLE (Disconnected)\n";
                else {
                    cout << "MST total weight = " << cost << "\n";
                    cout << "Edges (u v):\n";
                    printEdgesList(mstEdges);
                }
            }

            else if (op == 3) {
                cout << "Enter root:\n";
                int root;
                cin >> root;
                auto g = buildAdj(n, edges);
                auto [cost, mstEdges] = primRooted(n, g, root);
                if (cost == -1)
                    cout << "IMPOSSIBLE (Disconnected)\n";
                else {
                    cout << "Prim rooted at " << root << "\n";
                    cout << "MST total weight = " << cost << "\n";
                    cout << "Edges (parent child):\n";
                    printEdgesList(mstEdges);
                }
            }

            else if (op == 4) {
                auto [cost, forest] = kruskalForest(n, edges);
                cout << "Forest total weight = " << cost << "\n";
                cout << "Components = " << forest.size() << "\n";
                for (size_t i = 0; i < forest.size(); i++) {
                    cout << "Component " << (i + 1) << " edges:\n";
                    for (auto &e : forest[i]) {
                        cout << e.first << " " << e.second << "\n";
                    }
                }
            }

            else if (op == 5) {
                bool ok = mstExists(n, edges);
                cout << (ok ? "YES (MST exists)\n" : "NO (Disconnected)\n");
            }

            else if (op == 6) {
                ll ans = kruskalMaxST_total(n, edges);
                if (ans == -1)
                    cout << "IMPOSSIBLE (Disconnected)\n";
                else
                    cout << "Maximum spanning tree weight = " << ans << "\n";
            }

            else if (op == 7) {
                auto [best, second] = secondBestMST(n, edges);
                if (best == -1)
                    cout << "IMPOSSIBLE (Disconnected)\n";
                else {
                    cout << "Best MST weight = " << best << "\n";
                    if (second == -1)
                        cout << "Second Best MST = NOT FOUND\n";
                    else
                        cout << "Second Best MST weight = " << second << "\n";
                }
            }

            else if (op == 8) {
                cout << "Enter K (#forced edges):\n";
                int K;
                cin >> K;
                vector<pair<int, int>> forced(K);
                cout << "Enter forced edges (u v):\n";
                for (int i = 0; i < K; i++)
                    cin >> forced[i].first >> forced[i].second;

                auto [cost, chosen] = mstForcedEdges(n, edges, forced);
                if (cost == -1)
                    cout << "IMPOSSIBLE\n";
                else {
                    cout << "Forced-edge MST weight = " << cost << "\n";
                    cout << "Edges:\n";
                    printEdgesList(chosen);
                }
            }

            else if (op == 9) {
                cout << "Enter B (#banned edges):\n";
                int B;
                cin >> B;
                set<pair<int, int>> banned;
                cout << "Enter banned edges (u v):\n";
                for (int i = 0; i < B; i++) {
                    int u, v;
                    cin >> u >> v;
                    banned.insert(normPair(u, v));
                }
                ll ans = mstWithBannedEdges(n, edges, banned);
                if (ans == -1)
                    cout << "IMPOSSIBLE\n";
                else
                    cout << "MST weight without banned edges = " << ans << "\n";
            }

            else if (op == 10) {
                cout << "Enter X D (degree limit for node X):\n";
                int X, D;
                cin >> X >> D;
                ll ans = mstDegreeLimitX_greedy(n, edges, X, D);
                if (ans == -1)
                    cout << "IMPOSSIBLE / Not found by greedy\n";
                else
                    cout << "Greedy constrained MST weight = " << ans << "\n";
            }

            else if (op == 11) {
                cout << "Enter Q (#queries):\n";
                int Q;
                cin >> Q;
                cout << "Enter each query edge u v w:\n";

                auto built = buildMSTForQueries(n, edges);
                if (!built) {
                    cout << "IMPOSSIBLE (Base graph disconnected; MST doesn't "
                            "exist)\n";
                    // still read queries but ignore output
                    for (int i = 0; i < Q; i++) {
                        int u, v;
                        ll w;
                        cin >> u >> v >> w;
                    }
                } else {
                    auto pack = *built;
                    cout << "Base MST cost = " << pack.mstCost << "\n";
                    cout << "Query answers (new MST weight):\n";
                    for (int i = 0; i < Q; i++) {
                        int u, v;
                        ll w;
                        cin >> u >> v >> w;
                        cout
                            << newMST_ifAddEdge(pack.mstCost, pack.lca, u, v, w)
                            << "\n";
                    }
                }
            }
        }

        else if (op == 12) {
            int n;
            cout << "Enter N (#points):\n";
            cin >> n;
            vector<Point> pts(n);
            cout << "Enter x y (" << n << " lines):\n";
            for (int i = 0; i < n; i++) {
                cin >> pts[i].x >> pts[i].y;
            }
            double ans = primPoints(pts);
            cout.setf(std::ios::fixed);
            cout << setprecision(6);
            cout << "Coordinate MST length = " << ans << "\n";
        }

        else {
            cout << "Invalid option.\n";
        }
    }

    cout << "Exiting MST Lab Toolkit.\n";
    return 0;
}
