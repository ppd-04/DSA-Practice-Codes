#include <bits/stdc++.h>
using namespace std;

using ll = long long;
const ll INFLL = (1LL << 62);

struct DSU {
    vector<int> p, sz;
    DSU(int n = 0) { init(n); }
    void init(int n) {
        p.resize(n + 1);
        sz.assign(n + 1, 1);
        iota(p.begin(), p.end(), 0);
    }
    int find(int x) { return (p[x] == x) ? x : p[x] = find(p[x]); }
    bool unite(int a, int b) {
        a = find(a);
        b = find(b);
        if (a == b)
            return false;
        if (sz[a] < sz[b])
            swap(a, b);
        p[b] = a;
        sz[a] += sz[b];
        return true;
    }
};

struct Edge {
    int u, v;
    ll w;
    int id;
    bool in_mst = false;
};
bool operator<(const Edge &a, const Edge &b) {
    if (a.w != b.w)
        return a.w < b.w;
    return a.id < b.id;
}

pair<ll, vector<Edge>> kruskal_mst(int n, vector<Edge> edges) {
    sort(edges.begin(), edges.end());
    DSU dsu(n);
    ll cost = 0;
    vector<Edge> chosen;
    for (auto &e : edges) {
        if (dsu.unite(e.u, e.v)) {
            cost += e.w;
            e.in_mst = true;
            chosen.push_back(e);
        }
    }
    if ((int)chosen.size() != n - 1)
        return {INFLL, {}};
    return {cost, chosen};
}

// Prim MST: O((n+m)logn) for adjacency list
pair<ll, vector<tuple<int, int, ll>>>
prim_mst(int n, vector<vector<pair<int, ll>>> &g) {
    vector<ll> dist(n + 1, INFLL);
    vector<int> parent(n + 1, -1);
    vector<char> used(n + 1, false);

    priority_queue<pair<ll, int>, vector<pair<ll, int>>, greater<pair<ll, int>>>
        pq;
    dist[1] = 0;
    pq.push({0, 1});

    ll cost = 0;
    while (!pq.empty()) {
        auto [d, u] = pq.top();
        pq.pop();
        if (used[u])
            continue;
        used[u] = true;
        cost += d;
        for (auto [v, w] : g[u]) {
            if (!used[v] && w < dist[v]) {
                dist[v] = w;
                parent[v] = u;
                pq.push({dist[v], v});
            }
        }
    }

    for (int i = 1; i <= n; i++)
        if (!used[i])
            return {INFLL, {}};

    vector<tuple<int, int, ll>> edges;
    for (int v = 2; v <= n; v++) {
        edges.push_back({parent[v], v, dist[v]});
    }
    return {cost, edges};
}

/*** LCA (binary lifting) with max edge on path — for Second-Best MST ***/
struct LCA {
    int n, LOG;
    vector<int> depth;
    vector<vector<int>> up;
    vector<vector<ll>> mx; // max edge weight to 2^k parent

    LCA(int n = 0) { init(n); }

    void init(int N) {
        n = N;
        LOG = 1;
        while ((1 << LOG) <= n)
            LOG++;
        depth.assign(n + 1, 0);
        up.assign(LOG, vector<int>(n + 1, 0));
        mx.assign(LOG, vector<ll>(n + 1, 0));
    }

    void dfs(int u, int p, ll w, vector<vector<pair<int, ll>>> &tree) {
        up[0][u] = p;
        mx[0][u] = w;
        for (auto [v, wt] : tree[u]) {
            if (v == p)
                continue;
            depth[v] = depth[u] + 1;
            dfs(v, u, wt, tree);
        }
    }

    void build(int root, vector<vector<pair<int, ll>>> &tree) {
        depth[root] = 0;
        dfs(root, root, 0, tree);
        for (int k = 1; k < LOG; k++) {
            for (int v = 1; v <= n; v++) {
                up[k][v] = up[k - 1][up[k - 1][v]];
                mx[k][v] = max(mx[k - 1][v], mx[k - 1][up[k - 1][v]]);
            }
        }
    }

    ll maxOnPath(int a, int b) {
        if (a == b)
            return 0;
        ll ans = 0;
        if (depth[a] < depth[b])
            swap(a, b);
        int diff = depth[a] - depth[b];
        for (int k = LOG - 1; k >= 0; k--) {
            if (diff & (1 << k)) {
                ans = max(ans, mx[k][a]);
                a = up[k][a];
            }
        }
        if (a == b)
            return ans;
        for (int k = LOG - 1; k >= 0; k--) {
            if (up[k][a] != up[k][b]) {
                ans = max(ans, mx[k][a]);
                ans = max(ans, mx[k][b]);
                a = up[k][a];
                b = up[k][b];
            }
        }
        // now parent is LCA
        ans = max(ans, mx[0][a]);
        ans = max(ans, mx[0][b]);
        return ans;
    }
};

ll second_best_mst(int n, vector<Edge> edges) {
    auto [mstCost, mstEdges] = kruskal_mst(n, edges);
    if (mstCost == INFLL)
        return -1;

    // Build MST tree adjacency
    vector<vector<pair<int, ll>>> tree(n + 1);
    vector<char> isTree(edges.size(), false);

    // Mark tree edges by ID
    vector<char> inTree(edges.size(), false);
    for (auto &e : mstEdges) {
        inTree[e.id] = true;
        tree[e.u].push_back({e.v, e.w});
        tree[e.v].push_back({e.u, e.w});
    }

    LCA lca(n);
    lca.build(1, tree);

    ll ans = INFLL;
    for (auto &e : edges) {
        if (inTree[e.id])
            continue;
        ll mxEdge = lca.maxOnPath(e.u, e.v);
        ll cand = mstCost + e.w - mxEdge;
        if (cand > mstCost)
            ans = min(ans, cand);
    }
    return (ans == INFLL ? -1 : ans);
}
