#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>

using namespace std;
const int INF = 1e9;

vector<int> repeatedDijsktra(int src, vector<vector<pair<int, int>>>& adj){
    int V = adj.size();
    vector<int> dist(V+1, INF);
    dist[src] = 0;
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<>> pq;
    pq.push({dist[src], src});
    
    while(!pq.empty()){
        auto [curCost, u] = pq.top();
        pq.pop();
        if(dist[u] < curCost) continue;
        for(auto [v, cost] : adj[u]){
            if(dist[v] > dist[u] + cost){
                dist[v] = dist[u] + cost;
                pq.push({dist[v], v});
            }
        }
    }
    return dist;
}


int main() {
    int V = 5;

    // Adjacency list: (neighbor, weight)
    vector<vector<pair<int,int>>> adj(V);

    adj[0] = {{1,4}, {3,5}};
    adj[1] = {{2,1}, {4,6}};
    adj[2] = {{0,2}, {3,3}};
    adj[3] = {{2,1}, {4,2}};
    adj[4] = {{0,1}, {3,4}};

    // APSP distance matrix
    vector<vector<int>> dist(V, vector<int>(V, INF));

    // Run Dijkstra from every vertex
    for(int i = 0; i < V; i++) {
        dist[i] = repeatedDijsktra(i, adj);
    }

    // Print result
    for(int i = 0; i < V; i++) {
        for(int j = 0; j < V; j++) {
            cout << dist[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}