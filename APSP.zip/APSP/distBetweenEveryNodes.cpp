#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>

using namespace std;
const int INF = 1e9;

// You are given a directed graph with N cities and M roads.
// Each road has a cost.
// Find the shortest distance between every pair of cities.

vector<vector<int>> floydWarshall(vector<vector<pair<int, int>>> &adj, int n){
    vector<vector<int>> result(n+1, vector<int> (n+1, INF));
    for(int i = 1; i <= n; i++){
        result[i][i] = 0;
    }
    for(int u = 1; u <= n; u++){
        for(auto [v, cost] : adj[u]){
            result[u][v] = min(result[u][v], cost);
        }
    }

    for(int k = 1; k <= n; k++){
        for(int i = 1; i <= n; i++){
            for(int j = 1; j <= n; j++){
                if(result[i][k] < INF && result[k][j] < INF){
                    result[i][j] = min(result[i][j], result[i][k]+result[k][j]);
                }
            }
        }
    }
    return result;
}

int main() {
    int n, m;
    cin >> n >> m;
    vector<vector<pair<int, int>>> adj(n+1);
    for(int i = 0; i < m; i++){
        int u, v, w;
        cin >> u >> v >> w;
        adj[u].push_back({v, w});
    }
    vector<vector<int>> result;
    result = floydWarshall(adj, n);

    for(int i = 1; i <= n; i++){
        for(int j = 1; j <= n; j++){
            cout << result[i][j] << " ";
        }
        cout << endl;
    }

    return 0;
}