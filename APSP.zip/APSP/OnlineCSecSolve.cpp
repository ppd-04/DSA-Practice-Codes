#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>

using namespace std;
const long long INF = 1e18;

pair<vector<vector<long long>>, vector<vector<long long>>> floydWarshall(vector<vector<pair<int, int>>> &adj, int n){
    vector<vector<long long>> dist(n, vector<long long>(n, INF));
    vector<vector<long long>> edges(n, vector<long long>(n, INF));
    
    for(int i = 0; i < n; i++){
        dist[i][i] = 0;
        edges[i][i] = 0;
    }
    
    for(int u = 0; u < n; u++){
        for(auto [v, cost] : adj[u]){
            if(cost < dist[u][v]){
                dist[u][v] = cost;
                edges[u][v] = 1;
            }
        }
    }

    for(int k = 0; k < n; k++){
        for(int i = 0; i < n; i++){
            for(int j = 0; j < n; j++){
                if(dist[i][k] < INF && dist[k][j] < INF){
                    if(dist[i][k] + dist[k][j] < dist[i][j]){
                        dist[i][j] = dist[i][k] + dist[k][j];
                        edges[i][j] = edges[i][k] + edges[k][j];
                    }
                }
            }
        }
    }
    return {dist, edges};
}

int main() {
    int n, m;
    cin >> n >> m;
    vector<vector<pair<int, int>>> adj(n);
    
    for(int i = 0; i < m; i++){
        int u, v, w;
        cin >> u >> v >> w;
        adj[u].push_back({v, w});
    }
    
    int V;
    cin >> V;

    auto [dist, edge_count] = floydWarshall(adj, n);

    int q;
    cin >> q;
    while(q--){
        int a, b;
        cin >> a >> b;
        
        // Case 1: Direct path (no discount)
        long long ans = dist[a][b];
        
        // Case 2: Path through V with discount (each edge gets -1)
        if(dist[a][V] < INF && dist[V][b] < INF){
            long long pathCost = dist[a][V] + dist[V][b];
            long long pathEdges = edge_count[a][V] + edge_count[V][b];
            long long discountedCost = pathCost - pathEdges;
            ans = min(ans, discountedCost);
        }

        if(ans >= INF) cout << -1 << endl;
        else cout << ans << endl;
    }

    return 0;
}

