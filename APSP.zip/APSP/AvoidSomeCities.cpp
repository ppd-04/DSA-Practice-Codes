#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;
const int INF = 1e9;

vector<vector<int>> floydWarshall(vector<vector<pair<int, int>>> &adj, int n, vector<bool> &blocked){
    vector<vector<int>> result(n, vector<int>(n, INF));

    // distance to itself
    for(int i = 0; i < n; i++){
        if(!blocked[i])
            result[i][i] = 0;
    }

    // edges
    for(int u = 0; u < n; u++){
        if(blocked[u]) continue;
        for(auto [v, cost] : adj[u]){
            if(!blocked[v])
                result[u][v] = min(result[u][v], cost);
        }
    }

    // Floyd–Warshall
    for(int k = 0; k < n; k++){
        if(blocked[k]) continue;

        for(int i = 0; i < n; i++){
            if(blocked[i]) continue;

            for(int j = 0; j < n; j++){
                if(blocked[j]) continue;

                if(result[i][k] < INF && result[k][j] < INF){
                    result[i][j] = min(result[i][j],
                                       result[i][k] + result[k][j]);
                }
            }
        }
    }

    return result;
}

int main(){
    int n, m;
    cin >> n >> m;

    vector<vector<pair<int,int>>> adj(n);
    for(int i = 0; i < m; i++){
        int u, v, w;
        cin >> u >> v >> w;
        adj[u].push_back({v, w});
        adj[v].push_back({u, w});   // undirected
    }

    int k;
    cin >> k;

    vector<bool> blocked(n, false);
    for(int i = 0; i < k; i++){
        int x;
        cin >> x;
        blocked[x] = true;
    }

    vector<vector<int>> dist = floydWarshall(adj, n, blocked);

    int q;
    cin >> q;
    while(q--){
        int a, b;
        cin >> a >> b;

        if(blocked[a] || blocked[b] || dist[a][b] == INF)
            cout << -1 << endl;
        else
            cout << dist[a][b] << endl;
    }

    return 0;
}


