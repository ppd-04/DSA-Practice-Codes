#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>

using namespace std;
const int INF = 1e9 * 2LL;

vector<vector<int>> floydWarshall(vector<vector<pair<int, int>>> &adj, int n){
    vector<vector<int>> result(n+1, vector<int>(n+1, INF));
    for(int i = 1; i <= n; i++) result[i][i] = 0;
    for(int u = 1; u <= n; u++){
        for(auto [v, cost] : adj[u]){
            result[u][v] = min(result[u][v], cost);
        }
    }
    for(int k = 1; k <= n; k++){
        for(int i = 1; i <= n; i++){
            for(int j = 1; j <= n; j++){
                if(result[i][k] < INF && result[k][j] < INF){
                    result[i][j] = min(result[i][j], result[i][k]+result[k][j]);
                }
            }
        }
    }
    return result;
}

int main() {
    int n, m, KA, KB;
    cin >> n >> m >> KA >> KB;
    vector<vector<pair<int, int>>> adj(n+1);
    
    // Store all edges with indices
    vector<int> a_list(m+1), b_list(m+1), c_list(m+1);
    for(int i = 1; i <= m; i++){  // 1-indexed edges
        int u, v, w;
        cin >> u >> v >> w;
        adj[u].push_back({v, w});
        a_list[i] = u; b_list[i] = v; c_list[i] = w;
    }
    
    // Read highway A and B edge indices
    vector<bool> is_highwayA(m+1, false), is_highwayB(m+1, false);
    for(int i = 0; i < KA; i++){
        int idx; cin >> idx;
        is_highwayA[idx] = true;
    }
    for(int i = 0; i < KB; i++){
        int idx; cin >> idx;
        is_highwayB[idx] = true;
    }
    
    long long DA, DB;
    cin >> DA >> DB;
    
    // Pass 1: Normal graph (no discounts)
    vector<vector<int>> dist_normal = floydWarshall(adj, n);
    
    // Pass 2: DA_first - Highway A free (0 cost), Highway B blocked (INF)
    vector<vector<pair<int, int>>> adj_DA(n+1);
    for(int u = 1; u <= n; u++){
        for(auto [v, cost] : adj[u]){
            // Find edge index (simple linear scan since m small)
            int edge_idx = -1;
            for(int idx = 1; idx <= m; idx++){
                if(a_list[idx] == u && b_list[idx] == v && c_list[idx] == cost){
                    edge_idx = idx; break;
                }
            }
            int new_cost = cost;
            if(is_highwayA[edge_idx]) new_cost = 0;        // A free
            if(is_highwayB[edge_idx]) new_cost = INF;       // B blocked
            adj_DA[u].push_back({v, new_cost});
        }
    }
    vector<vector<int>> dist_DA_first = floydWarshall(adj_DA, n);
    
    // Pass 3: DB_first - Highway B free (0 cost), Highway A blocked (INF)
    vector<vector<pair<int, int>>> adj_DB(n+1);
    for(int u = 1; u <= n; u++){
        for(auto [v, cost] : adj[u]){
            int edge_idx = -1;
            for(int idx = 1; idx <= m; idx++){
                if(a_list[idx] == u && b_list[idx] == v && c_list[idx] == cost){
                    edge_idx = idx; break;
                }
            }
            int new_cost = cost;
            if(is_highwayB[edge_idx]) new_cost = 0;        // B free
            if(is_highwayA[edge_idx]) new_cost = INF;      // A blocked
            adj_DB[u].push_back({v, new_cost});
        }
    }
    vector<vector<int>> dist_DB_first = floydWarshall(adj_DB, n);
    
    int q;
    cin >> q;
    
    for(int query = 0; query < q; query++){
        int i, j;
        cin >> i >> j;
        
        long long ans = INF;
        
        // Option 1: No discount (normal)
        ans = min(ans, (long long)dist_normal[i][j]);
        
        // Option 2: DA discount (A before B)
        if(dist_DA_first[i][j] < INF){
            ans = min(ans, (long long)dist_DA_first[i][j] + DA);
        }
        
        // Option 3: DB discount (B before A)
        if(dist_DB_first[i][j] < INF){
            ans = min(ans, (long long)dist_DB_first[i][j] + DB);
        }
        
        cout << (ans >= INF ? -1 : ans) << endl;
    }
    
    return 0;
}
