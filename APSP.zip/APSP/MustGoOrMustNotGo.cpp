
#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>

using namespace std;
const int INF = 1e9;


vector<vector<int>> floydWarshall(vector<vector<pair<int, int>>> &adj, int n){
    vector<vector<int>> result(n+1, vector<int> (n+1, INF));
    for(int i = 0; i < n; i++){
        result[i][i] = 0;
    }
    for(int u = 0; u < n; u++){
        for(auto [v, cost] : adj[u]){
            result[u][v] = min(result[u][v], cost);
        }
    }

    for(int k = 0; k < n; k++){
        for(int i = 0; i < n; i++){
            for(int j = 0; j < n; j++){
                if(result[i][k] < INF && result[k][j] < INF){
                    result[i][j] = min(result[i][j], result[i][k]+result[k][j]);
                }
            }
        }
    }
    return result;
}

int main() {
    int n, m;
    cin >> n >> m;
    int V;
    cin >> V;
    vector<vector<pair<int, int>>> adj(n+1);
    vector<vector<pair<int, int>>> adjNew(n+1);
    for(int i = 0; i < m; i++){
        int u, v, w;
        cin >> u >> v >> w;
        adj[u].push_back({v, w});
        adj[v].push_back({u, w});

        if(v==V){
            adjNew[u].push_back({v, INF});
        }
    }
    

    

    vector<vector<int>> result;
    vector<vector<int>> result2;
    result = floydWarshall(adj, n);
    result2 = floydWarshall(adjNew, n);


    int q;
    cin >> q;
    while(q--){
        int ans = INF;
        int a, b;
        cin >> a >> b;
        bool yes;

        cin >> yes;
        if(yes){
            ans = result[a][V]+result[V][b];
        }else{
            ans = result2[a][b];
        }

        
        
        

        if(ans == INF) cout << -1 << endl;
        else cout << ans << endl;

    }

    // for(int i = 1; i <= n; i++){
    //     for(int j = 1; j <= n; j++){
    //         cout << result[i][j] << " ";
    //     }
    //     cout << endl;
    // }

    return 0;
}
