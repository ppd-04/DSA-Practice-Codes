#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;
const long long INF = 1e18;

vector<vector<long long>> floydWarshall(vector<vector<pair<int, int>>> &adj, int n){
    vector<vector<long long>> dist(n, vector<long long>(n, INF));
    
    for(int i = 0; i < n; i++){
        dist[i][i] = 0;
    }
    
    for(int u = 0; u < n; u++){
        for(int x = 0; x < adj[u].size(); x++){
            int v = adj[u][x].first;
            int cost = adj[u][x].second;
            dist[u][v] = min(dist[u][v], (long long)cost);
        }
    }

    for(int k = 0; k < n; k++){
        for(int i = 0; i < n; i++){
            for(int j = 0; j < n; j++){
                if(dist[i][k] < INF && dist[k][j] < INF){
                    dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j]);
                }
            }
        }
    }
    return dist;
}

int main() {
    int n, m;
    cin >> n >> m;
    vector<vector<pair<int, int>>> adj(n);
    vector<pair<pair<int, int>, int>> edges; // Store all edges: ((u, v), cost)
    
    for(int i = 0; i < m; i++){
        int u, v, w;
        cin >> u >> v >> w;
        adj[u].push_back(make_pair(v, w));
        edges.push_back(make_pair(make_pair(u, v), w));
    }

    vector<vector<long long>> dist = floydWarshall(adj, n);

    int q;
    cin >> q;
    while(q--){
        int a, b;
        cin >> a >> b;
        
        // Case 1: Direct path (no toll-free pass)
        long long ans = dist[a][b];
        
        // Case 2: Use toll-free pass on one edge (u, v)
        for(int i = 0; i < edges.size(); i++){
            int u = edges[i].first.first;
            int v = edges[i].first.second;
            // Path: a -> u -> v (free) -> b
            if(dist[a][u] < INF && dist[v][b] < INF){
                ans = min(ans, dist[a][u] + 0 + dist[v][b]);
            }
        }

        if(ans >= INF) cout << -1 << endl;
        else cout << ans << endl;
    }

    return 0;
}
