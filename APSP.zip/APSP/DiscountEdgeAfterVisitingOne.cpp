#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;
const long long INF = 4e18;

vector<vector<long long>> floydWarshall(
    vector<vector<pair<int, int>>> &adj,
    int n,
    int H
){
    // total states = n * 2
    int N = 2 * n;
    vector<vector<long long>> dist(N, vector<long long>(N, INF));

    // initialize self distance
    for(int i = 0; i < N; i++){
        dist[i][i] = 0;
    }

    // build edges
    for(int u = 0; u < n; u++){
        for(auto [v, w] : adj[u]){
            // normal edge, discount not used
            dist[u][v] = min(dist[u][v], (long long)w);

            // normal edge, discount already used
            dist[u + n][v + n] = min(dist[u + n][v + n], (long long)w);

            // discount edge (only from H, and only once)
            if(u == H){
                dist[u][v + n] = min(dist[u][v + n], 0LL);
            }
        }
    }

    // Floyd–Warshall
    for(int k = 0; k < N; k++){
        for(int i = 0; i < N; i++){
            if(dist[i][k] == INF) continue;
            for(int j = 0; j < N; j++){
                if(dist[k][j] == INF) continue;
                dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j]);
            }
        }
    }

    return dist;
}

int main(){
    int n, m;
    cin >> n >> m;

    vector<vector<pair<int, int>>> adj(n);
    for(int i = 0; i < m; i++){
        int u, v, w;
        cin >> u >> v >> w;
        adj[u].push_back({v, w});
        adj[v].push_back({u, w});
    }

    int H;
    cin >> H;

    vector<vector<long long>> dist = floydWarshall(adj, n, H);

    int q;
    cin >> q;
    while(q--){
        int a, b;
        cin >> a >> b;

        long long ans = min(
            dist[a][b],           // discount not used
            dist[a][b + n]        // discount used
        );

        if(ans == INF) cout << -1 << endl;
        else cout << ans << endl;
    }

    return 0;
}
