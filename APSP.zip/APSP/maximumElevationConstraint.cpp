#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;
const long long INF = 1e18;

vector<vector<long long>> floydWarshall(vector<vector<pair<int, int>>> &adj, int n, vector<int> &elevation){
    vector<vector<long long>> dist(n, vector<long long>(n, INF));
    
    for(int i = 0; i < n; i++){
        dist[i][i] = 0;
    }
    
    for(int u = 0; u < n; u++){
        for(int x = 0; x < adj[u].size(); x++){
            int v = adj[u][x].first;
            int cost = adj[u][x].second;
            dist[u][v] = min(dist[u][v], (long long)cost);
        }
    }

    for(int k = 0; k < n; k++){
        for(int i = 0; i < n; i++){
            for(int j = 0; j < n; j++){
                // Only use k as intermediate if its elevation is not greater than max(elevation[i], elevation[j])
                int max_elevation = max(elevation[i], elevation[j]);
                if(elevation[k] <= max_elevation){
                    if(dist[i][k] < INF && dist[k][j] < INF){
                        dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j]);
                    }
                }
            }
        }
    }
    return dist;
}

int main() {
    int n, m;
    cin >> n >> m;
    
    vector<int> elevation(n);
    for(int i = 0; i < n; i++){
        cin >> elevation[i];
    }
    
    vector<vector<pair<int, int>>> adj(n);
    for(int i = 0; i < m; i++){
        int u, v, w;
        cin >> u >> v >> w;
        adj[u].push_back(make_pair(v, w));
    }

    vector<vector<long long>> dist = floydWarshall(adj, n, elevation);

    int q;
    cin >> q;
    while(q--){
        int a, b;
        cin >> a >> b;
        
        long long ans = dist[a][b];

        if(ans >= INF) cout << -1 << endl;
        else cout << ans << endl;
    }

    return 0;
}
