#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>

using namespace std;
const int INF = 1e9;

vector<vector<int>> floydWarshall(vector<vector<pair<int, int>>> &adj, int n){
    vector<vector<int>> result(n+1, vector<int> (n+1, INF));
    for(int i = 1; i <= n; i++){
        result[i][i] = 0;
    }
    for(int u = 1; u <=n; u++){
        for(auto [v, cost] : adj[u]){
            result[u][v] = cost;
        }
    }

    for(int k = 1; k <= n; k++){
        for(int i = 1; i <= n; i++){
            for(int j = 1; j <= n; j++){
                result[i][j] = min(result[i][k]+result[k][j], result[i][j]);
            }
        }
    }
    return result;
}

int main() {
    int n, m, q;
    cin >> n >> m >> q;
    vector<vector<pair<int, int>>> adj(n+1);
    for(int i = 0; i < m; i++){
        int u, v, c;
        cin >> u >> v >> c;
        adj[u].push_back({v, c});
        adj[v].push_back({u, c});
    }
    vector<pair<int, int>> queries(q);
    for(int i = 0; i < q; i++){
        int a, b;
        cin >> a >> b;
        queries[i] = {a, b};
    }
    vector<vector<int>> result(n+1, vector<int> (n+1, INF));
    result = floydWarshall(adj, n);
    for(auto [u, v] : queries){
        if(result[u][v] == INF){
            cout << -1 << endl;
            continue;
        }
        cout << result[u][v] << endl;
    }
    
    return 0;
}