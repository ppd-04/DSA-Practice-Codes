#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>


using namespace std;
// const int INF = 1e9;
const int negINF = -1e9;

vector<vector<double>> floydWarshall(vector<vector<pair<int, double>>> &adj, int n){
    vector<vector<double>> result(n+1, vector<double> (n+1, 0));
    for(int i = 1; i <= n; i++){
        result[i][i] = 1;
    }
    for(int u = 1; u <=n; u++){
        for(auto [v, cost] : adj[u]){
            result[u][v] = cost;
        }
    }

    for(int k = 1; k <= n; k++){
        for(int i = 1; i <= n; i++){
            for(int j = 1; j <= n; j++){
                if(result[i][k] > 0 && result[k][j] > 0){
                    result[i][j]= max(result[i][k]*result[k][j], result[i][j]);
                }
            }
        }
    }
    return result;
}

void solve(){
    int n;
    cin >> n;
    vector<string> curr(n+1);
    for(int i = 1; i <= n; i++){
        cin >> curr[i];
    }
    int m;
    cin >> m;
    vector<vector<pair<int, double>>> adj(n+1);
    for(int i = 0; i < m; i++){
        string fc, tc;
        double rt;
        cin >> fc >> rt >> tc;
        int from = -1;
        int to = -1;
        for(int j = 1; j <= n; j++){
            if(curr[j]==fc) from = j;
            if(curr[j]==tc) to = j;
        }
        adj[from].push_back({to, rt});
    }

    vector<vector<double>> result = floydWarshall(adj, n);
    bool isArbitrage = false;
    for(int i = 1; i <= n; i++){
        if(result[i][i] > 1){
            isArbitrage = true;
            break;
        }
    }
    if(isArbitrage) cout << "Yes" << endl;
    else cout << "No" << endl;
}

int main() {
    solve();
    
    return 0;
}