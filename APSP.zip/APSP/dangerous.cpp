#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;
const long long INF = 1e18;

vector<vector<long long>> floydWarshall(vector<vector<pair<int, int>>> &adj, int n, vector<bool> &is_dangerous, bool avoid_dangerous){
    vector<vector<long long>> dist(n, vector<long long>(n, INF));
    
    for(int i = 0; i < n; i++){
        dist[i][i] = 0;
    }
    
    for(int u = 0; u < n; u++){
        for(int x = 0; x < adj[u].size(); x++){
            int v = adj[u][x].first;
            int cost = adj[u][x].second;
            dist[u][v] = min(dist[u][v], (long long)cost);
        }
    }

    for(int k = 0; k < n; k++){
        // Skip dangerous zones as intermediate vertices if avoid_dangerous is true
        if(avoid_dangerous && is_dangerous[k]){
            continue;
        }
        
        for(int i = 0; i < n; i++){
            for(int j = 0; j < n; j++){
                if(dist[i][k] < INF && dist[k][j] < INF){
                    dist[i][j] = min(dist[i][j], dist[i][k] + dist[k][j]);
                }
            }
        }
    }
    return dist;
}

int main() {
    int n, m;
    cin >> n >> m;
    vector<vector<pair<int, int>>> adj(n);
    
    for(int i = 0; i < m; i++){
        int u, v, w;
        cin >> u >> v >> w;
        adj[u].push_back(make_pair(v, w));
    }
    
    int D;
    cin >> D;
    vector<bool> is_dangerous(n, false);
    
    for(int i = 0; i < D; i++){
        int zone;
        cin >> zone;
        is_dangerous[zone] = true;
    }
    
    long long X;
    cin >> X;

    // Run Floyd-Warshall twice
    vector<vector<long long>> dist_full = floydWarshall(adj, n, is_dangerous, false);  // Use all vertices
    vector<vector<long long>> dist_safe = floydWarshall(adj, n, is_dangerous, true);   // Avoid dangerous zones

    int q;
    cin >> q;
    while(q--){
        int a, b;
        cin >> a >> b;
        
        long long ans;
        
        // If safe path is at most X units longer than full path, use safe path
        if(dist_safe[a][b] <= dist_full[a][b] + X){
            ans = dist_safe[a][b];
        } else {
            ans = dist_full[a][b];
        }

        if(ans >= INF) cout << -1 << endl;
        else cout << ans << endl;
    }

    return 0;
}
