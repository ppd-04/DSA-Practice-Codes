#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>

using namespace std;
const int INF = 1e9 * 2LL;

vector<vector<int>> floydWarshall(vector<vector<pair<int, int>>> &adj, int n){
    vector<vector<int>> result(n+1, vector<int>(n+1, INF));
    for(int i = 1; i <= n; i++) result[i][i] = 0;
    for(int u = 1; u <= n; u++){
        for(auto [v, cost] : adj[u]){
            result[u][v] = min(result[u][v], cost);
        }
    }
    for(int k = 1; k <= n; k++){
        for(int i = 1; i <= n; i++){
            for(int j = 1; j <= n; j++){
                if(result[i][k] < INF && result[k][j] < INF){
                    result[i][j] = min(result[i][j], result[i][k]+result[k][j]);
                }
            }
        }
    }
    return result;
}

int main() {
    int n, m, K;
    long long F;
    cin >> n >> m >> K >> F;
    
    vector<vector<pair<int, int>>> adj(n+1);
    vector<int> a_list(m+1), b_list(m+1), c_list(m+1);
    
    for(int i = 1; i <= m; i++){  // 1-indexed edges
        int u, v, w;
        cin >> u >> v >> w; 
        adj[u].push_back({v, w});
        a_list[i] = u; b_list[i] = v; c_list[i] = w;
    }
    
    // Read toll road indices
    vector<bool> is_toll(m+1, false);
    for(int i = 0; i < K; i++){
        int idx; cin >> idx;
        is_toll[idx] = true;
    }
    
    // Pass 1: Normal graph (pay all tolls)
    vector<vector<int>> dist_normal = floydWarshall(adj, n);
    
    // Pass 2: Subscription graph (toll roads FREE)
    vector<vector<pair<int, int>>> adj_sub(n+1);
    for(int u = 1; u <= n; u++){
        for(auto [v, cost] : adj[u]){
            // Find edge index
            int edge_idx = -1;
            for(int idx = 1; idx <= m; idx++){
                if(a_list[idx] == u && b_list[idx] == v && c_list[idx] == cost){
                    edge_idx = idx; break;
                }
            }
            int new_cost = is_toll[edge_idx] ? 0 : cost;  // Toll = FREE
            adj_sub[u].push_back({v, new_cost});
        }
    }
    vector<vector<int>> dist_subscribed = floydWarshall(adj_sub, n);
    
    int q;
    cin >> q;
    
    for(int query = 0; query < q; query++){
        int i, j;
        cin >> i >> j;
        
        long long ans = INF;
        
        // Option 1: No subscription (pay all tolls)
        if(dist_normal[i][j] < INF){
            ans = dist_normal[i][j];
        }
        
        // Option 2: Subscription (F + non-toll edges only)
        if(dist_subscribed[i][j] < INF){
            ans = min(ans, F + dist_subscribed[i][j]);
        }
        
        cout << (ans >= INF ? -1LL : ans) << endl;
    }
    
    return 0;
}
