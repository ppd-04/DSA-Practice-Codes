#include <iostream>
#include <vector>
#include <algorithm>
#include<queue>
using namespace std;

struct fligt{
    int a, b, c;
};



vector<vector<int>> dijkstra(vector<vector<pair<int, int>>>&adj, int src){
    // priority_queue<pair<int,pair<int,int>>, vector<pair<int, pair<int,int>>>, greater<pair<int, int>>> pq;
    priority_queue<pair<int, pair<int,int>>, vector<pair<int, pair<int,int>>>, greater<>> pq;
    int sz = adj.size();
    
    vector<vector<int>>dist(sz, vector<int>(2, INT_MAX));
    // vector<array<int, 2>> dist(sz, {INT_MAX, INT_MAX});

    pq.push({0,{src,0}});
    dist[src][0] = 0;
    // dijsktray 3 tacase
    while(!pq.empty()){
        auto t=pq.top();
        pq.pop();
        int d = t.first;
        int u = t.second.first;
        int used = t.second.second;
        // distance boro hole skip
        if(d > dist[u][used]){
            continue;
        }
        for(auto &p : adj[u]){
            int v = p.first;
            int w = p.second;
            // if(used == 1){} 
            if(dist[u][used]+w<dist[v][used]){
                dist[v][used] = dist[u][used] + w;
               
                pq.push({dist[v][used], {v, used}});
            }
            if(used == 0){
                int hf = w/2;
                if(dist[u][0] + hf < dist[v][1]){
                    dist[v][1] = dist[u][0] + hf;
                    pq.push({dist[v][1], {v,1}});
                }
            }
        }

    }
    return dist;



}

void solve(){
    int n, m;
    cin >> n >> m;
    vector<fligt> flights(m);
    vector<vector<pair<int,int>>> adj(n+1);
    for(int i = 0; i < m; i++){
        cin >> flights[i].a >> flights[i].b >> flights[i].c;
        adj[flights[i].a].push_back({flights[i].b, flights[i].c});

    }
    vector<vector<int>> finalDestination = dijkstra(adj,1);
    cout << finalDestination[n][1] << endl;

}

int main() {
    solve();
    return 0;
}