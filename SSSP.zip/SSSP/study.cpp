#include<iostream> 
using namespace std;

int sum(int a, int b){
    return a+b;
}

int main(){
    cout << "hello world\n"; 
    cout << "mridula";
    cout << "tanhia" << " " << "tabassum" << "mridula";
    cout << "\nTanhia Tabassum Mridula\n";

    cout << 5+1 << endl;
    
    int a, b;
    cout << "Please enter two numbers: ";
    cin >> a >> b;
    cout << a+b << endl;

    int result = sum(a,b);
    cout << result;

}

