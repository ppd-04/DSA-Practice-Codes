def dfs(start, adj, visited, topoOrder):
    visited[start] = True
    for neighbour in adj[start]:
        if not visited[neighbour]:
            dfs(neighbour, adj, visited, topoOrder)
    topoOrder.append(start)

def topoSort(V, adj):
    res = []
    visited = [False] * V
    topoOrder = []
    for i in range(V):
        if not visited[i]:
            dfs(i, adj, visited, topoOrder)
    while topoOrder:
        res.append(topoOrder.pop())
    return res
# python kemne easiest, shob syntax i to ultapalta....