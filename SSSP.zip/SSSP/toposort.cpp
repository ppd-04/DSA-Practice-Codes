#include <iostream>
#include <vector>
#include <stack>
using namespace std;

void dfs(int start, vector<vector<int>>& adj, vector<bool> & visited, stack<int>& topoOrder){
    visited[start] = true;
    for(int neighbour : adj[start]){
        if(!visited[neighbour]){
            dfs(neighbour, adj, visited, topoOrder);
        }
    }
    topoOrder.push(start);
}

vector<int> topologicalSort(int V, vector<vector<int>>& adj){
    stack<int> topoOrder;
    vector<int> res;
    vector<bool> visited(V, false);
    for(int i = 0; i < V; i++){
        if(!visited[i]){
            dfs(i, adj, visited, topoOrder);
        }
    }

    while(!topoOrder.empty()){
        res.push_back(topoOrder.top());
        topoOrder.pop();
    }
    return res;
}

int main() {
    // Example DAG: A(0) → B(1) → C(2), A → D(3) → E(4)
    int V = 5; // Number of vertices
    vector<vector<int>> adj = {{1, 3}, {2}, {}, {4}, {}}; // Adjacency list
    vector<int> topo = topologicalSort(V, adj);

    cout << "Topological Sort: ";
    for (int node : topo) {
        cout << node << " ";
    }
    cout << endl;

    return 0;
}