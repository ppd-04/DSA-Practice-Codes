def dfs(w, edges, currentTime, vis):
    w.startTime = currentTime
    currentTime[0] += 1
    w.inProgress = True
    vis[w] = True
    for v in edges[w]:
        if vis[v] != True:
            dfs(v, edges, currentTime, vis)
    w.endTime = currentTime[0]
    currentTime[0] +=1
    w.inProgress = False
    w.finished = True


class Node:
    def __init__(self, name):
        self.name = name
        self.startTime = None
        self.endTime = None
        self.inProgress = False
        self.finished = False

    def __repr__(self):
        return self.name
nodes = {name: Node(name) for name in ["A", "B", "C", "D"]}

# Define adjacency list (graph)
edges = {
    nodes["A"]: [nodes["B"], nodes["C"]],
    nodes["B"]: [nodes["D"]],
    nodes["C"]: [],
    nodes["D"]: []
}

# Initialize visited map and time counter
vis = {node: False for node in nodes.values()}
time = [0]  # mutable counter

# Run DFS starting from A
dfs(nodes["A"], edges, time, vis)

# Print results
print("DFS Simulation Results:")
for node in nodes.values():
    print(f"{node.name}: start={node.startTime}, end={node.endTime}, finished={node.finished}")
