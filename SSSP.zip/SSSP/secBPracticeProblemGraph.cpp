#include <iostream>
#include <vector>
using namespace std;

int dx[4] = {-1, 1, 0, 0};
int dy[4] = {0, 0, -1, 1};

void dfs(int x, int y, vector<vector<int>>& adj, vector<vector<bool>>& vis, int n, int m) {
    vis[x][y] = true;
    for(int i = 0; i < 4; i++) {
        int nx = x + dx[i];
        int ny = y + dy[i];
        if(nx >= 0 && nx < n && ny >= 0 && ny < m && adj[nx][ny] == 0 && !vis[nx][ny]) {
            dfs(nx, ny, adj, vis, n, m);
        }
    }
}

int main() {
    int n, m;
    cin >> n >> m;
    vector<vector<int>> adj(n, vector<int>(m));
    vector<vector<bool>> vis(n, vector<bool>(m, false));

    for(int i = 0; i < n; i++) {
        for(int j = 0; j < m; j++) {
            cin >> adj[i][j];
        }
    }

    int room = 0;
    for(int i = 0; i < n; i++) {
        for(int j = 0; j < m; j++) {
            if(adj[i][j] == 0 && !vis[i][j]) {
                dfs(i, j, adj, vis, n, m);
                room++;
            }
        }
    }

    cout << room << endl;
    return 0;
}