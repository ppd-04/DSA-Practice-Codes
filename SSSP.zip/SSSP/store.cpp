#include<iostream>
using namespace std;

int main(){
    // this will take n*n space
    int n, m;
    cin >> n >> m;
    
    int adj[n][n] = {0};

    for(int i = 0; i < m; i++){
        int u, v;
        cin >> u >> v;
        adj[u][v] = 1;
        adj[v][u] = 1;
    }
    return 0;
}