#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
using namespace std;

struct flight {
    int a, b, c;
};

// MODIFIED: Added K parameter
vector<vector<vector<int>>> dijkstra(vector<vector<pair<int, int>>>& adj, 
                                      int K, int src) {
    
    // MODIFIED: State now {cost, {node, {flights_taken, coupon_used}}}
    priority_queue<pair<int, pair<int, pair<int, int>>>, 
                   vector<pair<int, pair<int, pair<int, int>>>>, 
                   greater<>> pq;
    
    int sz = adj.size();
    
    // MODIFIED: 3D distance array [node][flights_taken][coupon_used]
    vector<vector<vector<int>>> dist(sz, 
        vector<vector<int>>(K + 1, vector<int>(2, INT_MAX)));

    pq.push({0, {src, {0, 0}}});  // Start with 0 flights taken
    dist[src][0][0] = 0;
    
    while(!pq.empty()) {
        auto t = pq.top();
        pq.pop();
        int d = t.first;
        int u = t.second.first;
        int flights_taken = t.second.second.first;  // ADDED
        int used = t.second.second.second;
        
        if(d > dist[u][flights_taken][used]) {
            continue;
        }
        
        // ADDED: Skip if already used K flights
        if(flights_taken >= K) {
            continue;
        }
        
        for(auto& p : adj[u]) {
            int v = p.first;
            int w = p.second;
            
            // ADDED: Calculate new flight count
            int new_flights = flights_taken + 1;
            
            // ADDED: Skip if this would exceed K flights
            if(new_flights > K) {
                continue;
            }
            
            // Transition without using coupon
            if(dist[u][flights_taken][used] + w < dist[v][new_flights][used]) {
                dist[v][new_flights][used] = dist[u][flights_taken][used] + w;
                pq.push({dist[v][new_flights][used], {v, {new_flights, used}}});
            }
            
            // Transition with coupon
            if(used == 0) {
                int hf = w / 2;
                if(dist[u][flights_taken][0] + hf < dist[v][new_flights][1]) {
                    dist[v][new_flights][1] = dist[u][flights_taken][0] + hf;
                    pq.push({dist[v][new_flights][1], {v, {new_flights, 1}}});
                }
            }
        }
    }
    return dist;
}

void solve() {
    int n, m, K;  // ADDED: K = max flights allowed
    cin >> n >> m >> K;
    
    vector<flight> flights(m);
    vector<vector<pair<int, int>>> adj(n + 1);
    
    for(int i = 0; i < m; i++) {
        cin >> flights[i].a >> flights[i].b >> flights[i].c;
        adj[flights[i].a].push_back({flights[i].b, flights[i].c});
    }
    
    vector<vector<vector<int>>> result = dijkstra(adj, K, 1);
    
    // MODIFIED: Find minimum across all valid flight counts (0 to K)
    int ans = INT_MAX;
    for(int f = 0; f <= K; f++) {
        ans = min(ans, result[n][f][0]);  // Without coupon
        ans = min(ans, result[n][f][1]);  // With coupon
    }
    
    if(ans == INT_MAX) {
        cout << -1 << endl;  // No path within K flights
    } else {
        cout << ans << endl;
    }
}

int main() {
    solve();
    return 0;
}
