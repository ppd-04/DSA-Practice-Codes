#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <set>
using namespace std;

struct flight {
    int a, b, c;
};

// MODIFIED: Added mandatory_cities set and M
vector<vector<vector<int>>> dijkstra(vector<vector<pair<int, int>>>& adj, 
                                      set<int>& mandatory_cities, 
                                      int M, int src, int dest) {
    
    // MODIFIED: State now {cost, {node, {visited_count, coupon_used}}}
    priority_queue<pair<int, pair<int, pair<int, int>>>, 
                   vector<pair<int, pair<int, pair<int, int>>>>, 
                   greater<>> pq;
    
    int sz = adj.size();
    
    // MODIFIED: 3D distance array [node][visited_count][coupon_used]
    // visited_count goes from 0 to M (cap at M since we only need M)
    vector<vector<vector<int>>> dist(sz, 
        vector<vector<int>>(M + 1, vector<int>(2, INT_MAX)));

    // ADDED: Check if source is a mandatory city
    int initial_count = mandatory_cities.count(src) ? 1 : 0;
    
    pq.push({0, {src, {initial_count, 0}}});
    dist[src][initial_count][0] = 0;
    
    while(!pq.empty()) {
        auto t = pq.top();
        pq.pop();
        int d = t.first;
        int u = t.second.first;
        int visited_count = t.second.second.first;
        int used = t.second.second.second;
        
        if(d > dist[u][visited_count][used]) {
            continue;
        }
        
        for(auto& p : adj[u]) {
            int v = p.first;
            int w = p.second;
            
            // ADDED: Calculate new visited count
            int new_visited = visited_count;
            if(mandatory_cities.count(v) && visited_count < M) {
                new_visited = visited_count + 1;
            }
            
            // ADDED: If destination is London, only accept if visited >= M
            if(v == dest && new_visited < M) {
                continue;  // Haven't visited enough mandatory cities
            }
            
            // Transition without using coupon
            if(dist[u][visited_count][used] + w < dist[v][new_visited][used]) {
                dist[v][new_visited][used] = dist[u][visited_count][used] + w;
                pq.push({dist[v][new_visited][used], {v, {new_visited, used}}});
            }
            
            // Transition with coupon
            if(used == 0) {
                int hf = w / 2;
                if(dist[u][visited_count][0] + hf < dist[v][new_visited][1]) {
                    dist[v][new_visited][1] = dist[u][visited_count][0] + hf;
                    pq.push({dist[v][new_visited][1], {v, {new_visited, 1}}});
                }
            }
        }
    }
    return dist;
}

void solve() {
    int n, m, M;  // ADDED: M = minimum mandatory cities to visit
    cin >> n >> m >> M;
    
    int s_size;
    cin >> s_size;
    
    set<int> mandatory_cities;  // ADDED: Set S
    for(int i = 0; i < s_size; i++) {
        int city;
        cin >> city;
        mandatory_cities.insert(city);
    }
    
    vector<flight> flights(m);
    vector<vector<pair<int, int>>> adj(n + 1);
    
    for(int i = 0; i < m; i++) {
        cin >> flights[i].a >> flights[i].b >> flights[i].c;
        adj[flights[i].a].push_back({flights[i].b, flights[i].c});
    }
    
    vector<vector<vector<int>>> result = dijkstra(adj, mandatory_cities, M, 1, n);
    
    // MODIFIED: Find minimum cost across all valid states at destination
    int ans = INT_MAX;
    for(int visited = M; visited <= M; visited++) {  // Only visited_count >= M
        ans = min(ans, result[n][visited][0]);  // Without coupon
        ans = min(ans, result[n][visited][1]);  // With coupon
    }
    
    if(ans == INT_MAX) {
        cout << -1 << endl;  // No valid path
    } else {
        cout << ans << endl;
    }
}

int main() {
    solve();
    return 0;
}
