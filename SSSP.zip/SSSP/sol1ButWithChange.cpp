#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
using namespace std;

const int INF = 1e9;

// Dijkstra function
void dijkstra(int N, int S, const vector<vector<pair<int,int>>>& adj, 
              vector<int>& dist, vector<int>& parent) {
    dist.assign(N+1, INF);
    parent.assign(N+1, -1);

    priority_queue<pair<int,int>, vector<pair<int,int>>, greater<>> pq;
    dist[S] = 0;
    pq.push({0, S});

    while(!pq.empty()) {
        auto [curDist, u] = pq.top();
        pq.pop();

        if(curDist > dist[u]) continue;

        for(auto [v, cost] : adj[u]) {
            if(dist[v] > dist[u] + cost) {
                dist[v] = dist[u] + cost;
                parent[v] = u;
                pq.push({dist[v], v});
            }
        }
    }
}

int main() {
    int N, M;
    cin >> N >> M;

    vector<vector<pair<int,int>>> adj(N+1);
    for(int i = 0; i < M; i++) {
        int u, v, c;
        cin >> u >> v >> c;
        adj[u].push_back({v, c});
        adj[v].push_back({u, c}); // remove if directed
    }

    int S, D;
    cin >> S >> D;

    vector<int> dist, parent;
    dijkstra(N, S, adj, dist, parent);

    if(dist[D] == INF) {
        cout << "No Path Found" << endl;
    } else {
        cout << "The cost is: " << dist[D] << endl;
    }

    return 0;
}