#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
using namespace std;

struct flight {
    int a, b, c;
};

int dijkstra_kth_shortest(vector<vector<pair<int, int>>>& adj, int src, int dest, int k) {
    
    // State: {cost, {node, coupon_used}}
    priority_queue<pair<int, pair<int, int>>, 
                   vector<pair<int, pair<int, int>>>, 
                   greater<>> pq;
    
    int sz = adj.size();
    
    // MODIFIED: Count how many times each state is processed
    vector<vector<int>> visit_count(sz, vector<int>(2, 0));
    
    // Track costs when reaching destination
    vector<int> dest_costs;

    pq.push({0, {src, 0}});
    
    while(!pq.empty()) {
        auto t = pq.top();
        pq.pop();
        int d = t.first;
        int u = t.second.first;
        int used = t.second.second;
        
        // Increment visit count for this state
        visit_count[u][used]++;
        
        // MODIFIED: Allow processing each state up to k times
        if(visit_count[u][used] > k) {
            continue;
        }
        
        // If reached destination, record the cost
        if(u == dest) {
            dest_costs.push_back(d);
            if(dest_costs.size() == k) {
                return dest_costs[k-1];  // Return k-th shortest
            }
        }
        
        for(auto& p : adj[u]) {
            int v = p.first;
            int w = p.second;
            
            // Transition without coupon
            pq.push({d + w, {v, used}});
            
            // Transition with coupon
            if(used == 0) {
                int hf = w / 2;
                pq.push({d + hf, {v, 1}});
            }
        }
    }
    
    // If didn't find k paths
    if(dest_costs.size() >= k) {
        return dest_costs[k-1];
    }
    return -1;
}

void solve() {
    int n, m;
    cin >> n >> m;
    
    vector<flight> flights(m);
    vector<vector<pair<int, int>>> adj(n + 1);
    
    for(int i = 0; i < m; i++) {
        cin >> flights[i].a >> flights[i].b >> flights[i].c;
        adj[flights[i].a].push_back({flights[i].b, flights[i].c});
    }
    
    int first = dijkstra_kth_shortest(adj, 1, n, 1);
    int second = dijkstra_kth_shortest(adj, 1, n, 2);
    
    cout << "First shortest: " << first << endl;
    if(second == -1) {
        cout << "Second shortest: No alternative path" << endl;
    } else {
        cout << "Second shortest: " << second << endl;
    }
}

int main() {
    solve();
    return 0;
}
