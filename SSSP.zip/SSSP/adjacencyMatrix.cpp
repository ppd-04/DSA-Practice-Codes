#include <bits/stdc++.h>
using namespace std;

int main() {
    int n, m;
    cin >> n >> m;
    int graph[n+1][n+1] = {0};
    // m = edge number
    // n = vertices
    vector<int> graph2[n+1];
    for(int i = 0; i < m; i++){
        int u, v;
        cin >> u >> v;
        graph[u][v] = 1;
        graph[v][u] = 1;

        graph2[u].push_back(v);
        graph2[v].push_back(u);
    }
    return 0;
}