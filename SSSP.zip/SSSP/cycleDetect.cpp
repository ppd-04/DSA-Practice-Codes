#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

vector<vector<int>> constructadj(int V, vector<vector<int>> &edges){
    
    vector<vector<int>> adj(V);
    for (auto it : edges)
    {
        adj[it[0]].push_back(it[1]);
        adj[it[1]].push_back(it[0]);
    }
    
    return adj;
}

bool isCycleUtil(int node, vector<vector<int>>& adj, vector<bool>& visited, int parent){
    visited[node] = true;
    for(int i : adj[node]){
        if(!visited[i]){
            if(isCycleUtil(i, adj, visited, parent)){
                return true;
            }
            
            // matching the poem\// the poet
            // 
/*
            your smile is the sunrise warming my day
            your love is like a rain, washing my fears away
            your voice is a song, i always knew
            and my every poem says, I love you
*/
        }
        else if(i != parent){
            return true;
        }
    }
    return false;
}

bool isCycle(int V, vector<vector<int>>& edges){
    vector<vector<int>> adj = constructadj(V, edges);
    vector<bool> visited(V, false);

    for(int i = 0; i < V; i++){
        if(!visited[i]){
            if(isCycleUtil(i, adj, visited, -1)){
                return true;
            }
        }
    } 
    return false;
}

int main() {
    int V = 5;
    vector<vector<int>> edges = {{0, 1}, {0, 2}, {0, 3}, {1, 2}, {3, 4}};

    if (isCycle(V, edges))
    {
        cout << "true" << endl;
    }
    else
    {
        cout << "false" << endl;
    }

    return 0;
}