#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

void bfs(int start, vector<vector<int>>&adj, )

int main() {
    
    return 0;
}