#include <iostream>
#include <vector>
#include <algorithm>
#include<queue>
using namespace std;
// Kahn
vector<vector<int>> constructadj(int V,vector<vector<int>> &edges){

    vector<vector<int> > adj(V);
    for (auto i : edges) {
        adj[i[0]].push_back(i[1]);
    }
    
    return adj;
}

vector<int> topologicalSort(int V, vector<vector<int>>& edges){
    vector<vector<int>> adj = constructadj(V, edges);
    vector<int> inDegree(V);
    for(int i = 0; i < V; i++){
        for(auto it : adj[i]){
            inDegree[it]++;
        }
    }
    // queue<int> q;
    // use a min heap instead of normal queue
    priority_queue<int, vector<int>, greater<int>> q;
    for(int i = 0; i < V; i++){
        if(inDegree[i] == 0){
            q.push(i);
        }
    }
    vector<int> result;
    while(!q.empty()){
        int node = q.top();
        q.pop();

        result.push_back(node);
        for(auto it : adj[node]){
            inDegree[it]--;
            if(inDegree[it] == 0){
                q.push(it);
            }
        }       
    }
    if(result.size() != V){
            cout << "Graph Contains Cycle" << endl;
            return {};
    }
    return result;

}

int main() {
     // Number of nodes
    int V = 6;

    // Edges
    vector<vector<int> > edges
        = {{0, 1}, {1, 2}, {2, 3},
           {4, 5}, {5, 1}, {5, 2}};

    vector<int> result = topologicalSort(V, edges);

    // Displaying result
    for (auto i : result) {
        cout << i << " ";
    }
    return 0;
}