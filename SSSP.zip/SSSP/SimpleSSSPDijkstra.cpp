#include<iostream>
#include<vector>
#include<algorithm>
#include<queue>

using namespace std;

const int INF = 1e9;

int main() {
    int N, M;
    cin >> N >> M;

    vector<vector<pair<int,int>>> adj(N + 1);
    // adj[u] = {v, cost}

    for (int i = 0; i < M; i++) {
        int u, v, c;
        cin >> u >> v >> c;
        adj[u].push_back({v, c});
        adj[v].push_back({u, c});
    }

    int S, D;
    cin >> S >> D;

    vector<int> dist(N + 1, INF);
    vector<int> parent(N + 1, -1);

    priority_queue<pair<int,int>, vector<pair<int,int>>, greater<>> pq;

    dist[S] = 0;
    pq.push({0, S});

    while (!pq.empty()) {
        auto [curDist, u] = pq.top();
        pq.pop();

        if (curDist > dist[u]) continue;

        for (auto [v, cost] : adj[u]) {
            if (dist[u] + cost < dist[v]) {
                dist[v] = dist[u] + cost;
                parent[v] = u;
                pq.push({dist[v], v});
            }
        }
    }

    if (dist[D] == INF) {
        cout << "No path\n";
        return 0;
    }

    vector<int> path;
    for (int cur = D; cur != -1; cur = parent[cur])
        path.push_back(cur);

    reverse(path.begin(), path.end());

    for (int i = 0; i < path.size(); i++) {
        if (i) cout << "->";
        cout << path[i];
    }

    cout << " " << dist[D] << "\n";
}
