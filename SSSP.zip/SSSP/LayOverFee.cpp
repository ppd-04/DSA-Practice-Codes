#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
using namespace std;

struct flight {
    int a, b, c;
};

// prottek vertex e ekta fee ase ekhon


// ADDED: layover parameter
vector<vector<int>> dijkstra(vector<vector<pair<int, int>>>& adj, 
                              vector<int>& layover, int src, int dest) {
    
    priority_queue<pair<int, pair<int, int>>, 
                   vector<pair<int, pair<int, int>>>, 
                   greater<>> pq;
    
    int sz = adj.size();
    vector<vector<int>> dist(sz, vector<int>(2, INT_MAX));

    pq.push({0, {src, 0}});
    dist[src][0] = 0;
    
    while(!pq.empty()) {
        auto t = pq.top();
        pq.pop();
        int d = t.first;
        int u = t.second.first;
        int used = t.second.second;
        
        if(d > dist[u][used]) {
            continue;
        }
        
        for(auto& p : adj[u]) {
            int v = p.first;
            int w = p.second;
            
            // ADDED: Calculate layover fee for node v
            int layover_fee = 0;
            if(v != src && v != dest) {  // Intermediate node only
                layover_fee = layover[v];
            }
            
            // Transition without using coupon
            int new_cost = dist[u][used] + w + layover_fee;  // MODIFIED: Added layover_fee
            if(new_cost < dist[v][used]) {
                dist[v][used] = new_cost;
                pq.push({dist[v][used], {v, used}});
            }
            
            // Transition with coupon (only on flight cost, not layover)
            if(used == 0) {
                int hf = w / 2;
                int new_cost_coupon = dist[u][0] + hf + layover_fee;  // MODIFIED: Added layover_fee
                if(new_cost_coupon < dist[v][1]) {
                    dist[v][1] = new_cost_coupon;
                    pq.push({dist[v][1], {v, 1}});
                }
            }
        }
    }
    return dist;
}

void solve() {
    int n, m;
    cin >> n >> m;
    
    vector<flight> flights(m);
    vector<vector<pair<int, int>>> adj(n + 1);
    vector<int> layover(n + 1, 0);  // ADDED: Layover fees
    
    // ADDED: Read layover fees for intermediate airports (2 to n-1)
    for(int i = 2; i < n; i++) {
        cin >> layover[i];
    }
    
    for(int i = 0; i < m; i++) {
        cin >> flights[i].a >> flights[i].b >> flights[i].c;
        adj[flights[i].a].push_back({flights[i].b, flights[i].c});
    }
    
    vector<vector<int>> finalDestination = dijkstra(adj, layover, 1, n);  // MODIFIED: Pass layover and dest
    
    // Take minimum of using coupon or not
    int result = min(finalDestination[n][0], finalDestination[n][1]);
    cout << result << endl;
}

int main() {
    solve();
    return 0;
}
