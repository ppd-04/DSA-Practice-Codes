#include <bits/stdc++.h>
using namespace std;

// Reads two integers and prints their sum
void basicIO() {
    int a, b;
    cin >> a >> b;
    cout << a + b << endl;
}

void solve(){
    int n, q;
    cin >> n >> q;
    vector<int> vals;
    
    vector<vector<int>> adj;

    for(int i = 0; i < n; i++){
        cin >> vals[i];
    }
    for(int i = 0; i < n-1; i++){
        
    }

}

int main() {
    // basicIO();
    int t;
    cin >> t;
    while(t--){
        solve();
    }
    
    // Your cpp code here
    return 0;
}
