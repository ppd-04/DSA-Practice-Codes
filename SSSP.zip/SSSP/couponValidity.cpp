#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
using namespace std;

struct flight {
    int a, b, c;
    int start, end;  // ADDED: time window
};

struct Edge {
    int to, cost;
    bool coupon_valid;  // ADDED: can coupon be used on this edge?
};

// MINIMAL CHANGE: Edge structure now includes coupon_valid flag
vector<vector<int>> dijkstra(vector<vector<Edge>>& adj, int src) {
    
    priority_queue<pair<int, pair<int, int>>, 
                   vector<pair<int, pair<int, int>>>, 
                   greater<>> pq;
    
    int sz = adj.size();
    vector<vector<int>> dist(sz, vector<int>(2, INT_MAX));

    pq.push({0, {src, 0}});
    dist[src][0] = 0;
    
    while(!pq.empty()) {
        auto t = pq.top();
        pq.pop();
        int d = t.first;
        int u = t.second.first;
        int used = t.second.second;
        
        if(d > dist[u][used]) {
            continue;
        }
        
        for(auto& edge : adj[u]) {  // MODIFIED: now Edge struct
            int v = edge.to;
            int w = edge.cost;
            bool can_use = edge.coupon_valid;  // ADDED: check if coupon valid
            
            // Transition without using coupon (always possible)
            if(dist[u][used] + w < dist[v][used]) {
                dist[v][used] = dist[u][used] + w;
                pq.push({dist[v][used], {v, used}});
            }
            
            // Transition with coupon (only if not used AND edge is coupon-eligible)
            if(used == 0 && can_use) {  // MODIFIED: Added can_use check
                int hf = w / 2;
                if(dist[u][0] + hf < dist[v][1]) {
                    dist[v][1] = dist[u][0] + hf;
                    pq.push({dist[v][1], {v, 1}});
                }
            }
        }
    }
    return dist;
}

void solve() {
    int n, m, T_start, T_end;  // ADDED: coupon validity window
    cin >> n >> m >> T_start >> T_end;
    
    vector<flight> flights(m);
    vector<vector<Edge>> adj(n + 1);  // MODIFIED: now stores Edge struct
    
    for(int i = 0; i < m; i++) {
        cin >> flights[i].a >> flights[i].b >> flights[i].c 
            >> flights[i].start >> flights[i].end;  // ADDED: time window
        
        // ADDED: Check if coupon can be used on this flight
        bool coupon_valid = (flights[i].start <= T_end) && 
                           (T_start <= flights[i].end);
        
        adj[flights[i].a].push_back({flights[i].b, flights[i].c, coupon_valid});
    }
    
    vector<vector<int>> finalDestination = dijkstra(adj, 1);
    
    int result = min(finalDestination[n][0], finalDestination[n][1]);
    cout << result << endl;
}

int main() {
    solve();
    return 0;
}
