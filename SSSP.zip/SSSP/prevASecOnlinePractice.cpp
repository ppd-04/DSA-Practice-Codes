#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>

using namespace std;
const int INF = 1e9;


int main() {
    int K, N, X;
    cin >> K >> N >> X;

    vector<vector<pair<int, pair<int, int>>>> adj(N+1);

    for(int i = 0; i < X; i++){
        int u1, v1, t1, c1;
        cin >> u1 >> v1 >> t1 >> c1;
        adj[u1].push_back({v1, {t1, c1}});
        adj[v1].push_back({u1, {t1, c1}});
    }
    int S, D;
    cin >> S >> D;
    
    vector<int> dist(N+1, INF);
    vector<int> parent(N+1, -1);
    vector<int> totalTime(N+1, INF);
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<>> pq;

    dist[S] = 0;
    totalTime[S] = 0;

    pq.push({dist[S], S});

    while(!pq.empty()){
        auto [curCost, u] = pq.top();
        pq.pop();
        if(dist[u] < curCost) continue;
        for(auto &edge : adj[u]){
            int v = edge.first;
            int t = edge.second.first;
            int c = edge.second.second;

            if(dist[v] > dist[u] + K*t + c + K){
                dist[v] = dist[u] + K*t + c + K;
                pq.push({dist[v], v});
                parent[v] = u;
                totalTime[v] = totalTime[u]+t+1;
            }
        }
    }
    vector<int> path;
    for(int i = D; i != -1; i = parent[i]){
        path.push_back(i);
    }
    
    reverse(path.begin(), path.end());

    for(int i = 0; i < path.size(); i++){
        if(i) cout << "->";
        cout << path[i];
    }
    cout << " " << totalTime[D]-1;
    cout << " " << dist[D] - K << endl;
    
    return 0;
}


// #include <iostream>
// #include <vector>
// #include <algorithm>
// #include <queue>
// #include <stack>

// using namespace std;
// const int INF = 1e9;


// int main() {
//     int K, N, X;
//     cin >> K >> N >> X;
//     vector<vector<pair<int, pair<int, int>>>> adj(N+1);
//     for(int i = 0; i < X; i++){
//         int u1, v1, t1, c1;
//         cin >> u1 >> v1 >> t1 >> c1;
//         adj[u1].push_back({v1, {t1, c1}});
//         adj[v1].push_back({u1, {t1, c1}}); 
//     }
//     vector<int> dist(N+1, INF);
//     vector<int> parent(N+1, -1);
//     vector<int> totalTime(N+1, INF);
//     priority_queue<pair<int, int>, vector<pair<int, int>>, greater<>> pq;
//     int S, D;
//     cin >> S >> D;
//     dist[S] = 0;
//     totalTime[S] = 0;
//     pq.push({dist[S], S});
//     while(!pq.empty()){
//         auto [curCost, u] = pq.top();
//         pq.pop();
//         if(dist[u] < curCost) continue;
//         for(auto &edge : adj[u]){
//             int v = edge.first;
//             int t = edge.second.first;
//             int c = edge.second.second;
//             int cost = K*t+c+K;
//             if(dist[v] > dist[u] + cost){
//                 dist[v] = dist[u] + cost;
//                 pq.push({dist[v], v});
//                 parent[v] = u;
//                 totalTime[v] = totalTime[u] + t + 1;
//             }

//         }
//     }
//     cout << totalTime[D] -1 << endl;
//     cout << dist[D] - K << endl;
//     return 0;
// }