#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>
using namespace std;

struct Flight {
    int a, b, c;
};

vector<vector<long long>> dijkstra(vector<vector<pair<int, int>>>& adj, int src) {
    priority_queue<pair<long long, pair<int, int>>, 
                   vector<pair<long long, pair<int, int>>>, 
                   greater<>> pq;
    
    int sz = adj.size();
    vector<vector<long long>> dist(sz, vector<long long>(2, LLONG_MAX));
    
    pq.push({0, {src, 0}});
    dist[src][0] = 0;
    
    while(!pq.empty()) {
        auto [d, state] = pq.top();
        auto [u, used] = state;
        pq.pop();
        
        if(d > dist[u][used]) continue;
        
        for(auto [v, w] : adj[u]) {
            // Without coupon
            if(dist[u][used] + w < dist[v][used]) {
                dist[v][used] = dist[u][used] + w;
                pq.push({dist[v][used], {v, used}});
            }
            
            // With coupon
            if(used == 0) {
                long long hf = w / 2;
                if(dist[u][0] + hf < dist[v][1]) {
                    dist[v][1] = dist[u][0] + hf;
                    pq.push({dist[v][1], {v, 1}});
                }
            }
        }
    }
    return dist;
}

void solve() {
    int n, m, A, B;
    cin >> n >> m >> A >> B;
    
    vector<Flight> flights(m);
    vector<vector<pair<int, int>>> adj(n + 1);
    
    for(int i = 0; i < m; i++) {
        cin >> flights[i].a >> flights[i].b >> flights[i].c;
        adj[flights[i].a].push_back({flights[i].b, flights[i].c});
    }
    
    // Run Dijkstra from both sources
    vector<vector<long long>> dist_A = dijkstra(adj, A);
    vector<vector<long long>> dist_B = dijkstra(adj, B);
    
    long long min_cost = LLONG_MAX;
    int meeting_city = -1;
    
    // Try each city as meeting point
    for(int city = 1; city <= n; city++) {
        // Try all coupon combinations
        for(int used_A = 0; used_A <= 1; used_A++) {
            for(int used_B = 0; used_B <= 1; used_B++) {
                if(dist_A[city][used_A] != LLONG_MAX && 
                   dist_B[city][used_B] != LLONG_MAX) {
                    long long total = dist_A[city][used_A] + dist_B[city][used_B];
                    if(total < min_cost) {
                        min_cost = total;
                        meeting_city = city;
                    }
                }
            }
        }
    }
    
    cout << "Meeting city: " << meeting_city << endl;
    cout << "Total cost: " << min_cost << endl;
}

int main() {
    solve();
    return 0;
}
