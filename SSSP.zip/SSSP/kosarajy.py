def dfs1(u, visited, stack, adj):
    visited[u] = True
    for v in adj[u]:
        if not visited[v]:
            dfs1(v, visited, stack, adj)
    stack.append(u)

def dfs2(u, visited, adj_rev, component):
    visited[u] = True
    component.append(u)
    for v in adj_rev[u]:
        if not visited[v]:
            dfs2(v, visited, adj_rev, component)

def kosaraju(V, adj):
    stack = []
    visited = [False] * V

    # Step 1: Fill vertices by finish time
    for i in range(V):
        if not visited[i]:
            dfs1(i, visited, stack, adj)

    # Step 2: Reverse the graph
    adj_rev = [[] for _ in range(V)]
    for u in range(V):
        for v in adj[u]:
            adj_rev[v].append(u)

    # Step 3: Process vertices in decreasing finish time
    visited = [False] * V
    scc_list = []
    while stack:
        u = stack.pop()
        if not visited[u]:
            component = []
            dfs2(u, visited, adj_rev, component)
            scc_list.append(component)

    return scc_list
