#include<iostream>
#include<algorithm>
#include<queue>

using namespace std;

struct Edge {
    int u, v, w;
};

bool bellmanFord(int V, int src, vector<Edge>& edges, vector<int>& dist) {
    dist.assign(V, INT_MAX);
    dist[src] = 0;

    for(int i = 1; i <= V-1; i++) {
        for(auto &e : edges) {
            if(dist[e.u] != INT_MAX && dist[e.u] + e.w < dist[e.v])
                dist[e.v] = dist[e.u] + e.w;
        }
    }

    // Check for negative cycles
    for(auto &e : edges) {
        if(dist[e.u] != INT_MAX && dist[e.u] + e.w < dist[e.v])
            return false; // negative cycle exists
    }

    return true; // no negative cycle
}

int main() {
    int V = 4;
    vector<Edge> edges = {
        {0,1,4},{0,2,5},{1,2,-3},{2,3,4},{3,1,6}
    };
    vector<int> dist;
    if(bellmanFord(V, 0, edges, dist)) {
        for(int i=0;i<V;i++)
            cout << "Distance to " << i << " = " << dist[i] << endl;
    } else {
        cout << "Graph contains a negative weight cycle\n";
    }
}
