#include <iostream>
#include <vector>
#include <algorithm>
using namespace std;

struct flight {
    int a, b, c;
};

// Helper function for floor division (handles negatives correctly)
long long floor_div(long long x) {
    // ⌊x/2⌋
    if(x >= 0) {
        return x / 2;
    } else {
        return (x - 1) / 2;  // For negative, adjust before division
    }
}

vector<vector<long long>> bellman_ford(vector<flight>& flights, int n, int src) {
    
    vector<vector<long long>> dist(n + 1, vector<long long>(2, LLONG_MAX));
    
    dist[src][0] = 0;
    
    // Relax edges n-1 times
    for(int iteration = 0; iteration < n - 1; iteration++) {
        
        for(auto& f : flights) {
            int u = f.a;
            int v = f.b;
            long long w = f.c;
            
            // Try without using coupon (from both states)
            for(int used = 0; used <= 1; used++) {
                if(dist[u][used] != LLONG_MAX) {
                    if(dist[u][used] + w < dist[v][used]) {
                        dist[v][used] = dist[u][used] + w;
                    }
                }
            }
            
            // Try using coupon (only from unused state)
            if(dist[u][0] != LLONG_MAX) {
                long long discounted = floor_div(w);
                if(dist[u][0] + discounted < dist[v][1]) {
                    dist[v][1] = dist[u][0] + discounted;
                }
            }
        }
    }
    
    return dist;
}

void solve() {
    int n, m;
    cin >> n >> m;
    
    vector<flight> flights(m);
    
    for(int i = 0; i < m; i++) {
        cin >> flights[i].a >> flights[i].b >> flights[i].c;
    }
    
    vector<vector<long long>> result = bellman_ford(flights, n, 1);
    
    long long ans = min(result[n][0], result[n][1]);
    
    if(ans == LLONG_MAX) {
        cout << "IMPOSSIBLE" << endl;
    } else {
        cout << ans << endl;
    }
}

int main() {
    solve();
    return 0;
}
