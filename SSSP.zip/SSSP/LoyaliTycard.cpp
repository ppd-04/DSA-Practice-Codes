#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
using namespace std;

struct flight {
    int a, b, c;
    int airline;  // ADDED: airline ID (1 to K)
};

// MODIFIED: Added K (number of airlines)
vector<vector<vector<int>>> dijkstra(vector<vector<pair<int, pair<int, int>>>>& adj, 
                                      int K, int src, int dest) {
    
    // MODIFIED: State now {cost, {node, {last_airline, coupon_used}}}
    priority_queue<pair<int, pair<int, pair<int, int>>>, 
                   vector<pair<int, pair<int, pair<int, int>>>>, 
                   greater<>> pq;
    
    int sz = adj.size();
    
    // MODIFIED: 3D distance array [node][airline][coupon_used]
    // airline 0 means "no previous airline" (starting state)
    vector<vector<vector<int>>> dist(sz, 
        vector<vector<int>>(K + 1, vector<int>(2, INT_MAX)));

    pq.push({0, {src, {0, 0}}});  // Start with airline=0 (no previous)
    dist[src][0][0] = 0;
    
    while(!pq.empty()) {
        auto t = pq.top();
        pq.pop();
        int d = t.first;
        int u = t.second.first;
        int last_airline = t.second.second.first;
        int used = t.second.second.second;
        
        if(d > dist[u][last_airline][used]) {
            continue;
        }
        
        for(auto& p : adj[u]) {
            int v = p.first;
            int w = p.second.first;
            int airline = p.second.second;  // ADDED: Get airline of this flight
            
            // ADDED: Check if loyalty discount applies
            bool loyalty = (last_airline == airline);
            
            // Calculate base cost with loyalty discount if applicable
            int base_cost = w;
            if(loyalty) {
                base_cost = (w * 4) / 5;  // 20% off = 80% of original
            }
            
            // Transition without using coupon
            int cost_no_coupon = dist[u][last_airline][used] + base_cost;
            if(cost_no_coupon < dist[v][airline][used]) {
                dist[v][airline][used] = cost_no_coupon;
                pq.push({dist[v][airline][used], {v, {airline, used}}});
            }
            
            // Transition with coupon
            if(used == 0) {
                int cost_with_coupon;
                if(loyalty) {
                    // Both loyalty and coupon: 20% off, then 50% off
                    cost_with_coupon = base_cost / 2;  // (w × 0.8) / 2
                } else {
                    // Only coupon: 50% off
                    cost_with_coupon = w / 2;
                }
                
                int total_cost = dist[u][last_airline][0] + cost_with_coupon;
                if(total_cost < dist[v][airline][1]) {
                    dist[v][airline][1] = total_cost;
                    pq.push({dist[v][airline][1], {v, {airline, 1}}});
                }
            }
        }
    }
    return dist;
}

void solve() {
    int n, m, K;  // ADDED: K = number of airlines
    cin >> n >> m >> K;
    
    vector<flight> flights(m);
    // MODIFIED: Adjacency list stores {destination, {cost, airline}}
    vector<vector<pair<int, pair<int, int>>>> adj(n + 1);
    
    for(int i = 0; i < m; i++) {
        cin >> flights[i].a >> flights[i].b >> flights[i].c >> flights[i].airline;
        adj[flights[i].a].push_back({flights[i].b, {flights[i].c, flights[i].airline}});
    }
    
    vector<vector<vector<int>>> result = dijkstra(adj, K, 1, n);
    
    // MODIFIED: Find minimum across all airlines at destination
    int ans = INT_MAX;
    for(int airline = 0; airline <= K; airline++) {
        ans = min(ans, result[n][airline][0]);  // Without coupon
        ans = min(ans, result[n][airline][1]);  // With coupon
    }
    
    if(ans == INT_MAX) {
        cout << -1 << endl;
    } else {
        cout << ans << endl;
    }
}

int main() {
    solve();
    return 0;
}
