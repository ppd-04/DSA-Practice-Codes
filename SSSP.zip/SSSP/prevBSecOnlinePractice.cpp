#include <iostream>
#include <vector>
#include <algorithm>
#include <queue>
#include <stack>

using namespace std;
const int INF = 1e9;


int main() {
    int N, M, F;
    cin >> N >> M >> F;
    vector<int> capacity(N+1);
    for(int i = 0; i < N; i++){
        cin >> capacity[i];
    }
    vector<vector<pair<int, int>>> adj(N+1);
    for(int i = 0; i < M; i++){
        int u1, v1, w1;
        cin >> u1 >> v1 >> w1;
        adj[u1].push_back({v1, w1});
        adj[v1].push_back({u1, w1});
    }
    int K;
    cin >> K;
    vector<int> ans(K+1, -1);
    ans[0] = F;
    vector<int> dist(N+1);
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<>> pq;
    dist[0] = 0;
    pq.push({dist[0], 0});
    capacity[0]--;
    
    while(!pq.empty()){
        auto [curCost, u] = pq.top();
        pq.pop();
        if(dist[u] < curCost) continue;
        for(auto [v, cost] : adj[u]){
            int newCost = F + dist[u] + cost;
            if(dist[v] > newCost && capacity[v] != 0){
                dist[v] = newCost;
                pq.push({dist[v], v});
                capacity[v]--;
            }
        }
    }

    return 0;
}