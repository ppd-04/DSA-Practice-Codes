import networkx as nx
import matplotlib.pyplot as plt

def dfs_visual(G, start, pos):
    visited = set()
    time_counter = [0]
    start_times = {}
    end_times = {}

    def dfs(u):
        visited.add(u)
        time_counter[0] += 1
        start_times[u] = time_counter[0]

        # Color node as "in progress"
        nx.draw(G, pos, with_labels=True,
                node_color=["orange" if n == u else "lightblue" for n in G.nodes()])
        plt.title(f"Visiting {u}, start={start_times[u]}")
        plt.pause(1)

        for v in G.neighbors(u):
            if v not in visited:
                dfs(v)

        time_counter[0] += 1
        end_times[u] = time_counter[0]

        # Color node as "finished"
        nx.draw(G, pos, with_labels=True,
                node_color=["green" if n == u else "lightblue" for n in G.nodes()])
        plt.title(f"Finished {u}, end={end_times[u]}")
        plt.pause(1)

    dfs(start)
    return start_times, end_times

# -------------------------------
# Interactive input
# -------------------------------
n_vertices = int(input("Enter number of vertices: "))
vertices = [input(f"Enter name of vertex {i+1}: ") for i in range(n_vertices)]

n_edges = int(input("Enter number of edges: "))
edges = []
print("Enter edges (e.g., A B for an edge between A and B):")
for _ in range(n_edges):
    u, v = input().split()
    edges.append((u, v))

# Build graph
G = nx.Graph()
G.add_nodes_from(vertices)
G.add_edges_from(edges)

# Layout for visualization
pos = nx.spring_layout(G)

# Run DFS from a chosen start node
start_node = input("Enter start node: ")

plt.figure(figsize=(6, 4))
start_times, end_times = dfs_visual(G, start_node, pos)
plt.show()

print("Start times:", start_times)
print("End times:", end_times)