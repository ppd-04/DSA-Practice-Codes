import queue
def bfs(start, adj, visited):
    q = queue.Queue()
    q.put(start)
    visited[start] = True
    while not q.empty():
        val = q.get()
        print(val)
        for neighbour in adj[val]:
            if not visited[neighbour]:
                visited[neighbour] = True   
                q.put(neighbour)

def dfs(start, adj, visited):
    visited[start] = True
    print(start)
    for neighbour in adj[start]:
        if not visited[neighbour]:
            dfs(neighbour, adj, visited)

# def bfs(start, adj, visited):
#     q = queue.Queue()
#     visited[start] = True
#     q.put(start)
#     while not q.empty():
#         x = q.get()
#         print(x)
#         for neighbour in adj[x]:
#             if not visited[neighbour]:
#                 visited[neighbour] = True
#                 q.put(neighbour)

# def dfs(start, adj, visited):
#     visited[start] = True
#     print(start)
#     for neighbour in adj[start]:
#         if not visited[neighbour]:
#             dfs(neighbour, adj, visited)




# def bfs(root, adj, visited):
#     q = queue.Queue()
#     q.put(root)
#     visited[root] = True
#     while not q.empty():
#         val = q.get()
#         print(val)
#         for neighbour in adj[val]:
#             if not visited[neighbour]:
#                 visited[neighbour] = True
#                 q.put(neighbour)

# def dfs(root, adj, visited):
#     visited[root] = True
#     print(root)
#     for neighbour in adj[root]:
#         if not visited[neighbour]: 
#             dfs(neighbour, adj, visited)

            


"""
valobashbo bashbo re
bondhu tomay jotone
amar moner govire 
chander alo
chuiya chuiya pore
pushe rakhbo rakhbo re
bondhu tomay jotone
...
"""

# Sample adjacency list for an undirected graph
adj = {
    0: [1, 2],
    1: [0, 3],
    2: [0],
    3: [1]
}

# Initialize visited list
visited = [False] * len(adj)

# Run BFS starting from node 0
bfs(0, adj, visited)
