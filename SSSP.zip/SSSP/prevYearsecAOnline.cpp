#include <iostream>
#include<algorithm>
#include<vector>
#include<queue>

using namespace std;

const long long INF = 1e18;

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);

    long long K;
    cin >> K;

    int N;
    cin >> N;

    int X;
    cin >> X;

    vector<vector<pair<int, pair<int,int>>>> adj(N + 1);
    // adj[u] = {v, {time, cost}}

    for (int i = 0; i < X; i++) {
        int u, v, t, c;
        cin >> u >> v >> t >> c;
        adj[u].push_back({v, {t, c}});
        adj[v].push_back({u, {t, c}});
    }

    int S, D;
    cin >> S >> D;

    vector<long long> dist(N + 1, INF);
    vector<long long> totalTime(N + 1, INF);
    vector<int> parent(N + 1, -1);

    priority_queue<pair<long long,int>, vector<pair<long long,int>>, greater<>> pq;

    dist[S] = 0;
    totalTime[S] = 0;
    pq.push({0, S});

    while (!pq.empty()) {
        auto [curCost, u] = pq.top();
        pq.pop();

        if (curCost > dist[u]) continue;

        for (auto &edge : adj[u]) {
            int v = edge.first;
            int t = edge.second.first;
            int c = edge.second.second;

            long long newCost = dist[u] + c + K * t + K;
            long long newTime = totalTime[u] + t + 1;

            if (newCost < dist[v]) {
                dist[v] = newCost;
                totalTime[v] = newTime;
                parent[v] = u;
                pq.push({newCost, v});
            }
        }
    }

    if (dist[D] == INF) {
        cout << "Error\n";
        return 0;
    }

    // Remove extra waiting added at start
    long long finalCost = dist[D] - K;
    long long finalTime = totalTime[D] - 1;

    // Reconstruct path
    vector<int> path;
    for (int cur = D; cur != -1; cur = parent[cur])
        path.push_back(cur);
    reverse(path.begin(), path.end());

    // Print path
    for (int i = 0; i < path.size(); i++) {
        if (i) cout << "->";
        cout << path[i];
    }
    cout << " " << finalTime << " " << finalCost << "\n";

    return 0;
}
