#include <iostream>
#include <vector>
using namespace std;

// Adjacency List Implementation
void transposeAdjacencyList(vector<vector<int>>& G, vector<vector<int>>& G2) {
    int V = G.size();
    G2.resize(V); // Initialize G2 with V empty vectors
    
    // Add direct edges (length 1 paths)
    for (int u = 0; u < V; u++) {
        for (int v : G[u]) {
            bool exists = false;
            for (int w : G2[u]) if (w == v) exists = true;
            if (!exists) G2[u].push_back(v);
        }
    }
    
    // Add second-hop edges (length 2 paths)
    for (int u = 0; u < V; u++) {
        for (int v : G[u]) {
            for (int w : G[v]) {
                bool exists = false;
                for (int x : G2[u]) if (x == w) exists = true;
                if (!exists && w != u) G2[u].push_back(w); // Avoid self-loops unless needed
            }
        }
    }
}

// Adjacency Matrix Implementation
void transposeAdjacencyMatrix(vector<vector<int>>& G, vector<vector<int>>& G2) {
    int V = G.size();
    G2.resize(V, vector<int>(V, 0));
    
    // Compute G^2 using matrix multiplication logic
    vector<vector<int>> A2(V, vector<int>(V, 0));
    for (int i = 0; i < V; i++) {
        for (int j = 0; j < V; j++) {
            for (int k = 0; k < V; k++) {
                if (G[i][k] && G[k][j]) {
                    A2[i][j] = 1;
                    break; // Once found, no need to check further
                }
            }
        }
    }
    
    // Combine original edges and A2
    for (int i = 0; i < V; i++) {
        for (int j = 0; j < V; j++) {
            G2[i][j] = G[i][j] || A2[i][j];
        }
    }
}


// Utility to print graph (for testing)
void printGraph(const vector<vector<int>>& G) {
    int V = G.size();
    for (int u = 0; u < V; u++) {
        cout << u << ": ";
        for (int v : G[u]) cout << v << " ";
        cout << endl;
    }
}

int main() {
    // Example: G with 4 vertices
    vector<vector<int>> G = {{1}, {2}, {3}, {0}}; // Simple cycle
    vector<vector<int>> G2_list(G.size());
    vector<vector<int>> G2_matrix(G.size(), vector<int>(G.size(), 0));
    
    transposeAdjacencyList(G, G2_list);
    cout << "G^2 (Adjacency List):" << endl;
    printGraph(G2_list);
    
    transposeAdjacencyMatrix(G, G2_matrix);
    cout << "G^2 (Adjacency Matrix):" << endl;
    for (int i = 0; i < G.size(); i++) {
        for (int j = 0; j < G.size(); j++) {
            cout << G2_matrix[i][j] << " ";
        }
        cout << endl;
    }
    
    return 0;
}

